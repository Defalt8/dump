#include <ds/all>
#include "benchmark"
#include <algorithm>

ds::string_stream<> sst(1024);

struct S 
{ 
	int i = 0; S(int i = 0) : i {i} {} DS_constexpr14 bool operator<(S const & rhs) const noexcept { return i < rhs.i; } 
};

namespace ds {


template <typename It, typename E = remove_cvref_t<decltype(*decl<It &>())>
		, typename C = less<E>
		, typename = decltype(*decl<It &>())
		, typename = decltype(++decl<It &>())
		, typename = decltype(decl<It &>() + decl<size_t>())
		, typename = decltype(ds::swap(*decl<It &>(), *decl<It &>()))
		, typename = decltype(decl<C>()(decl<E const &>(), decl<E const &>()))
	>
static DS_constexpr14 void
heapify(It begin_, It end_, C && compare = {})
{
	if(begin_ != end_)
	{
		size_t j = 0;
		for(auto it = begin_; it != end_; ++it, ++j)
		{
			for(size_t i = j; i > 0;)
			{
				size_t p = (i - 1) / 2;
				auto & parent = *(begin_ + p);
				auto & child  = *(begin_ + i);
				if(compare(child, parent))
					ds::swap(child, parent);
				i = p;
			}
		}
	}
}

template <typename It, typename C = less<remove_cvref_t<decltype(*decl<It &>())>>>
static DS_constexpr14 void
reverse_heapify(It begin_, It end_, C && compare = {})
{
	if(begin_ != end_)
	{
		size_t size_ = size_t(end_ - begin_);
		for(size_t i = 0; i < size_; ++i)
		{
			for(size_t n = i; n > 0;)
			{
				size_t p = (n - 1) / 2;
				auto & parent = begin_[p];
				auto & child  = begin_[n];
				if(compare(parent, child))
					ds::swap(child, parent);
				n = p;
			}
		}
	}
}

template <typename It, typename C = less<remove_cvref_t<decltype(*decl<It &>())>>, typename E = remove_cvref_t<decltype(*decl<It &>())>>
static DS_constexpr14 void
heap_sort(It begin_, It end_, C && compare = {})
{
	if(begin_ != end_)
	{
		reverse_heapify(begin_, end_, compare);
		auto size_  = size_t(end_ - begin_);
		auto _array = begin_;
		for(size_t j = size_; j > 0; )
		{	
			size_t i = 0;
			for(; i + 1 < j;)
			{
				size_t ch = (i * 2) + 1;
				if(ch + 1 < j)
				{
					auto & object  = _array[i];
					auto & child_0 = _array[ch];
					auto & child_1 = _array[ch + 1];
					if(compare(child_1, child_0))
					{
						ds::swap(object, child_0);
						i = ch;
					}
					else
					{
						ds::swap(object, child_1);
						i = ch + 1;
					}
				}
				else if(ch < j)
				{
					auto & object  = _array[i];
					auto & child_0 = _array[ch];
					ds::swap(object, child_0);
					i = ch;
				}
				else
					break;
			}
			--j;
			if(i != j)
			{
				ds::swap(_array[i], _array[j]);
				for(size_t p = (i - 1) / 2; p > 0; p = (p - 1) / 2)
				{
					auto & object = _array[i];
					auto & parent = _array[p];
					if(compare(parent, object))
					{
						ds::swap(object, parent);
						i = p;
					}
				}
			}
		}
	}
}

} // namespace ds

int main()
{
	// if(0)
	// {
	// 	ds::max_heap<int> heap(16);
	// 	heap.push(5); sst << heap << ds::endl;
	// 	heap.push(4); sst << heap << ds::endl;
	// 	heap.push(3); sst << heap << ds::endl;
	// 	heap.push(2); sst << heap << ds::endl;
	// 	heap.push(1); sst << heap << ds::endl;
	// 	heap.push(1); sst << heap << ds::endl;
	// 	heap.pop(); sst << heap << ds::endl;
	// 	heap.pop(); sst << heap << ds::endl;
	// 	heap.pop(); sst << heap << ds::endl;
	// 	heap.pop(); sst << heap << ds::endl;
	// 	heap.pop(); sst << heap << ds::endl;
	// 	heap.pop(); sst << heap << ds::endl;
	// }
	// if(0)
	{
		auto data = ds::array<int>({5,1,2,1,3,4,2,5,3});
		sst << data << ds::endl;
		ds::heapify(data.begin(), data.end());
		sst << data << ds::endl;
	}
	if(0)
	{
		using t = uint8_t;
		size_t size_ = 9;
		auto seed = 137;//t(time(0));
		// sst << seed << ds::endl;
		auto data_ = ds::array<t>(size_, ds::random_sequence<t>(seed));
		{
			auto data = ds::clone(data_);
			ds::heapify(data.begin(), data.end());
			sst << data << ds::endl;
			// ds::heap_sort(data.begin(), data.end());
			// sst << ds::is_sorted(data) << ds::endl;
			// sst << data << ds::endl;
		}
	}
	if(0)
	{
		using t = int;
		size_t size_ = 32;
		auto data_ = ds::array<t>(size_, ds::random_sequence<t>(t(time(0))));
		benchmark::delay(.1);
		{
			auto data = ds::clone(data_);
			benchmark::rep_test("heap sort", [&]()
			{
				ds::heap_sort(data.begin(), data.end(), ds::less<t>());
			});
			// sst << ds::is_sorted(data) << ds::endl;
		}
		benchmark::delay(.1);
		{
			auto data = ds::clone(data_);
			benchmark::rep_test("sort", [&]()
			{
				ds::sort(data.begin(), data.end());
			});
			// sst << ds::is_sorted(data) << ds::endl;
		}
		benchmark::delay(.1);
		{
			auto data = ds::clone(data_);
			benchmark::rep_test("heap sort", [&]()
			{
				ds::heap_sort(data.begin(), data.end(), ds::less<t>());
			});
			// sst << ds::is_sorted(data) << ds::endl;
		}
	}
	if(0)
	{
		using t = int;
		size_t size_ = 10000000;
		auto data_ = ds::array<t>(size_, ds::random_sequence<t>(t(time(0))));
		benchmark::delay(.1);
		{
			auto data = ds::clone(data_);
			benchmark::rep_test("heap sort", [&]()
			{
				ds::heap_sort(data.begin(), data.end(), ds::less<t>());
			});
		}
		benchmark::delay(.1);
		{
			auto data = ds::clone(data_);
			benchmark::rep_test("sort", [&]()
			{
				ds::sort(data.begin(), data.end());
			});
		}
	}
}
