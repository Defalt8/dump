#include <ds/all>

ds::string_stream<> sst(1024);

template <typename T>
struct memo
{
	T   _saved;
	T & _ref;

	~memo()
	{
		_ref = ds::move(_saved);
	}

	template <typename... Args
			, ds::enable_if_t<ds::is_aggregate_initializable<T,Args...>::value,int> = 0 
		>
	memo(T & object_, Args &&... args)
		: _saved { ds::move(object_) }
		, _ref   { object_ }
	{
		ds::destruct(_ref);
		ds::aggregate_init_at<T>(&_ref, ds::forward<Args>(args)...);
	}

};

template <typename T, typename... Args> 
static DS_constexpr14 memo<T> 
memorize(T & object_, Args &&... args) 
{ return { object_, ds::forward<Args>(args)... }; }

template <typename T, typename... Args> 
static DS_constexpr14 memo<T> 
memorize(T const & object_, Args &&... args) = delete;

int main()
{
	auto sep_mem = memorize(ds::stream_separator, "  ");
	{
		ds::stack<int> stack;
		ds::inserter<ds::stack<int>,int> ins{stack};
		ins.init(32);
		for(int i = 0; i < 32 && ins.insert(i); ++i);
		sst << stack.size() << " " << stack.capacity() << " : " << stack << ds::endl;
	}
	if(0)
	{
		// ds::Stack<int>::min_capacity = 1;
		// ds::Stack<int>::capacity_scale_nominator = 0;
		// ds::Stack<int>::capacity_scale_denominator = 2;
		// ds::stack<int> stack(0);
		ds::stack<int> stack(16);
		sst << stack.size() << " " << stack.capacity() << " : " << stack << ds::endl;
		for(int i = 0; i < 32; ++i)
			stack.push(i);
		sst << stack.size() << " " << stack.capacity() << " : " << stack << ds::endl;
		// sst << stack.size() << " " << stack.capacity() << " : " << stack << ds::endl;
		// stack.gpush(1);
		// sst << stack.size() << " " << stack.capacity() << " : " << stack << ds::endl;
		// stack.gpush(2);
		// sst << stack.size() << " " << stack.capacity() << " : " << stack << ds::endl;
		// stack.gpush(3);
		// sst << stack.size() << " " << stack.capacity() << " : " << stack << ds::endl;
		// stack.gpush(4);
		// sst << stack.size() << " " << stack.capacity() << " : " << stack << ds::endl;
		// stack.gpush(5);
		// // stack.top() = 5;
		// sst << stack.size() << " " << stack.capacity() << " : " << stack << ds::endl;
		// while(stack.size() > 1)
		// {
		// 	sst << stack.top();
		// 	stack.pop();
		// 	sst << " -- " << stack << " -- " << stack.top() << ds::endl;
		// }
		// for(auto it = ds::begin(stack); it != ds::end(stack); ++it)
		// 	sst << *it << " ";
		// sst << ds::endl;
		// for(auto it = ds::rbegin(stack); it != ds::rend(stack); --it)
		// 	sst << *it << " ";
		// sst << ds::endl;
	}
	// if(0)
	// {
	// 	// ds::list<1,int> data({1,2,3,4,5});
	// 	ds::stack<S> stack({1,2,3,4,5}, 7);
	// 	// ds::stack<int> stack = { data.begin(), data.end(), data.size() };
	// 	sst << stack.size() << " " << stack.capacity() << " : " << stack << ds::endl;
	// 	// stack = { ds::move(stack), 3 };
	// 	// stack = { &stack[0], &stack[3], 2 };
	// 	// sst << stack.size() << " " << stack.capacity() << " : " << stack << ds::endl;
	// }
	// if(0)
	// {
	// 	ds::stack<S> stack(10);
	// 	for(int i = 1; i <= 5; ++i)
	// 		stack.push(i);
	// 	sst << stack << ds::endl;
	// 	// while(stack.pop())
	// 	// 	sst << stack << ds::endl;
	// }
}
