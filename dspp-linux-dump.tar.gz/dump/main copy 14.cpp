#include <ds/all>

ds::string_stream<> sst(1024);

struct iprintable
{
	virtual ~iprintable() = default;
	virtual void print() const = 0;
};

struct A : iprintable
{
	void print() const override { sst << "A says hi." << ds::endl; }
};

struct B : iprintable
{
	void print() const override { sst << "B says hi." << ds::endl; }
};

struct C : iprintable
{
	void print() const override { sst << "C says hi." << ds::endl; }
};

template <class UID>
struct S
{
	static thread_local iprintable * _ip;

	static void 
	print()
	{
		if(_ip)
			_ip->print();
	}
};

template <class UID>
thread_local iprintable * S<UID>::_ip = nullptr;

template <class A = S<void>>
struct Person
{
	Person()
	{
		A::print();
	}
};

int main()
{
	{
		A a;
		auto smemo = ds::memorize(S<void>::_ip, &a);
		Person<> p;
		{
			B b;
			auto smemo = ds::memorize(S<void>::_ip, &b);
			Person<> p;
			{
				C c;
				auto smemo = ds::memorize(S<void>::_ip, &c);
				Person<> p;
			}
		}
	}
	if(0)
	{
		A a;
		iprintable * ip = &a;
		ip->print();
		{
			B b;
			auto ipmemo = ds::memorize(ip, &b);
			ip->print();
		}
		ip->print();
	}
	// auto sep_mem = memorize(ds::stream_separator, "  ");
	if(0)
	{
		ds::stack<int> stack;
		ds::inserter<ds::stack<int>,int> ins{stack};
		ins.init(32);
		for(int i = 0; i < 32 && ins.insert(i); ++i);
		sst << stack.size() << " " << stack.capacity() << " : " << stack << ds::endl;
	}
}
