#include <ds/all>

ds::string_stream<> sst(1024);

// template <size_t sz_, size_t al_ = alignof(ds::max_align_t)>
// struct LocalAlloc : public ds::allocators::Base
// {
// 	using alloc_t = ds::LocalForwardAllocator<sz_,al_>;
// 	alloc_t _allocator;
	
// 	DS_nodiscard void * 
// 	allocate(size_t size_, ds::align_t align_) noexcept(false) override
// 	{
// 		auto * block_ = _allocator.allocate(size_, align_);
// 		sst << "alc < local " << block_ << ds::endl;
// 		return block_;
// 	}

// 	void 
// 	deallocate(void * block_) noexcept override
// 	{
// 		sst << "del > local " << block_ << ds::endl;
// 		_allocator.deallocate(block_);
// 	}

// };

// struct HeapAlloc : public ds::allocators::Base
// {
// 	using alloc_t = ds::DynamicForwardAllocator;
// 	alloc_t _allocator;
	
// 	HeapAlloc(size_t sz_, size_t al_ = alignof(ds::max_align_t))
// 		: _allocator { sz_, al_ }
// 	{}

// 	DS_nodiscard void * 
// 	allocate(size_t size_, ds::align_t align_) noexcept(false) override
// 	{
// 		auto * block_ = _allocator.allocate(size_, align_);
// 		sst << "alc < heap  " << block_ << ds::endl;
// 		return block_;
// 	}

// 	void 
// 	deallocate(void * block_) noexcept override
// 	{
// 		sst << "del > heap  " << block_ << ds::endl;
// 		_allocator.deallocate(block_);
// 	}

// };

// template <typename E>
// using stack = ds::Stack<E,ds::allocators::Memo<void>>;

// template <typename E>
// using nt_stack = ds::Stack<E,ds::allocators::NTMemo<void>>;

int main()
{
	{
		ds::stack<int> _stack({1,2,3,4});
		{
			auto _localloc      = ds::allocators::LocalForward<ds::usage_s<ds::stack<int>,7>::value>();
			auto _localloc_memo = ds::allocators::memo<>(_localloc);
			ds::stack<int> _stack({5,6,7});

			auto _heapalloc      = ds::allocators::HeapForward(ds::usage_s<ds::stack<int>,8>::value);
			auto _heapalloc_memo = ds::allocators::memo<>(_localloc);
			auto __ = ds::allocators::memo<>(_heapalloc);
			ds::stack<int> _stack2({8,9,10,11});
			{
				auto _localalloc_memo = ds::allocators::memo<>(_localloc);
				_stack = _stack2;
			}
		}
	}
}
