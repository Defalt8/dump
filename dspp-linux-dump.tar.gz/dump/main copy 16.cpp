#include <ds/all>

ds::string_stream<> sst(1024);

#include ".dump/helpers"


int main()
{
	if(0)
	{
		ds::queue<int> queue({1,2,3,4});
		for(auto it = queue.end(), prev = queue.end(); it != queue.rend(); it = prev)
		{
			--prev;
			assert(!(prev == it));
			assert(prev != it);
			assert(prev <= it);
			assert(it >= prev);
			assert(prev < it);
			assert(it > prev);
		}
		for(auto it = queue.rend(), next = queue.rend(); it != queue.end(); it = next)
		{
			++next;
			assert(!(it == next));
			assert(it != next);
			assert(it <= next);
			assert(next >= it);
			assert(it < next);
			assert(next > it);
		}
	}
	if(0)
	{
		ds::queue<int> queue({1,2,3,4});
		queue.pop();
		queue.pop();
		queue.push(5);
		queue = { ds::move(queue), 2 };
		sst << queue << ds::endl;
	}
	if(0)
	{
		ds::queue<int> queue({1,2,3,4});
		sst << queue.capacity() << " " << queue.start() << " " << queue.size() << " -- " << queue << ds::endl;
		queue.pop();
		queue.pop();
		queue.pop();
		queue.push(5);
		sst << queue.capacity() << " " << queue.start() << " " << queue.size() << " -- " << queue << ds::endl;
		queue.push(6);
		sst << queue.capacity() << " " << queue.start() << " " << queue.size() << " -- " << queue << ds::endl;
		queue.push(7);
		sst << queue.capacity() << " " << queue.start() << " " << queue.size() << " -- " << queue << ds::endl;
		queue.push_noresize(9); 
		sst << queue.capacity() << " " << queue.start() << " " << queue.size() << " -- " << queue << ds::endl;
		queue.push(8); 
		sst << queue.capacity() << " " << queue.start() << " " << queue.size() << " -- " << queue << ds::endl;
		// for(auto it = queue.begin(); it != queue.end(); ++it)
		// 	sst << *it << ' '; sst << ds::endl;
		// for(auto it = queue.rbegin(); it != queue.rend(); --it)
		// 	sst << *it << ' '; sst << ds::endl;
	}
	// if(0)
	{
		ds::queue<int> queue(3);
		queue.push_noresize(1);
		queue.push_noresize(2);
		queue.push_noresize(3);
		// sst << queue << ds::endl;
		assert(!queue.push_noresize(5));
		// sst << queue << ds::endl;
		queue.pop();
		queue.push_noresize(4);
		// sst << queue << ds::endl;
		assert(!queue.push_noresize(5));
		// sst << queue << ds::endl;
		// for(auto it = queue.begin(); it != queue.end(); ++it)
		// 	sst << *it << ' '; sst << ds::endl;
		// for(auto it = queue.rbegin(); it != queue.rend(); --it)
		// 	sst << *it << ' '; sst << ds::endl;
		// for(auto it = ds::cref(queue).begin(); it != ds::cref(queue).end(); ++it)
		// 	sst << *it << ' '; sst << ds::endl;
		// for(auto it = ds::cref(queue).rbegin(); it != ds::cref(queue).rend(); --it)
		// 	sst << *it << ' '; sst << ds::endl;
		assert(*(queue.begin() + 0)   == 2);
		assert(*(queue.begin() + 1)   == 3);
		assert(*(queue.begin() + 2)   == 4);
		assert(*(queue.begin() + 3)   == 2);
		assert(*(queue.begin() + 4)   == 2);
		assert(*(queue.rbegin() - 0)  == 4);
		assert(*(queue.rbegin() - 1)  == 3);
		assert(*(queue.rbegin() - 2)  == 2);
		assert(*(queue.rbegin() - 3)  == 4);
		assert(*(queue.rbegin() - 4)  == 4);
		assert(*(ds::cref(queue).begin() + 0)   == 2);
		assert(*(ds::cref(queue).begin() + 1)   == 3);
		assert(*(ds::cref(queue).begin() + 2)   == 4);
		assert(*(ds::cref(queue).begin() + 3)   == 2);
		assert(*(ds::cref(queue).begin() + 4)   == 2);
		assert(*(ds::cref(queue).rbegin() - 0)  == 4);
		assert(*(ds::cref(queue).rbegin() - 1)  == 3);
		assert(*(ds::cref(queue).rbegin() - 2)  == 2);
		assert(*(ds::cref(queue).rbegin() - 3)  == 4);
		assert(*(ds::cref(queue).rbegin() - 4)  == 4);
		assert(  queue.end()   !=   queue.rend());
		assert(--queue.end()   ==   queue.rbegin());
		assert(  queue.end()   == ++queue.rbegin());
		assert(--queue.begin() ==   queue.rend());
		assert(  queue.begin() == ++queue.rend());
		assert(  queue.end()   == ++queue.end());
		assert(  queue.rend()  == --queue.rend());
		assert(  ds::cref(queue).end()   !=   ds::cref(queue).rend());
		assert(--ds::cref(queue).end()   ==   ds::cref(queue).rbegin());
		assert(  ds::cref(queue).end()   == ++ds::cref(queue).rbegin());
		assert(--ds::cref(queue).begin() ==   ds::cref(queue).rend());
		assert(  ds::cref(queue).begin() == ++ds::cref(queue).rend());
		assert(  ds::cref(queue).end()   == ++ds::cref(queue).end());
		assert(  ds::cref(queue).rend()  == --ds::cref(queue).rend());

		{ auto it = queue.rend(); assert(it++ == queue.rend()); assert(it == ++queue.rend()); }
		{ auto it = queue.end();  assert(it-- == queue.end());  assert(it == --queue.end()); }
		{ auto it = ds::cref(queue).rend(); assert(it++ == ds::cref(queue).rend()); assert(it == ++queue.rend()); }
		{ auto it = ds::cref(queue).end();  assert(it-- == ds::cref(queue).end());  assert(it == --queue.end()); }
	}
}