#include <ds/all>
#include <ds/heap>

ds::string_stream<> sst(1024);

// #include ".dump/helpers"

template class ds::Stack<ds::unique<int>>;
template class ds::Stack<int>;

struct Int
{
	int i = 0;
};

template <class OST>
static OST &
operator<<(OST & ost, Int const & rhs)
{
	return ost << rhs.i;
}

int main()
{
	// if(0)
	{
		ds::stack<Int> stack({1,2,3});
		sst << stack << ds::endl;
	}
	if(0)
	{
		ds::stack<int> stack(5, ds::sequence<int>());
		sst << stack << ds::endl;
	}
	if(0)
	{
		ds::stack<int> stack(5, ds::sequence<float>());
		sst << stack << ds::endl;
	}
	if(0)
	{
		ds::stack<int> stack(5, [i=0]() mutable { return ++i; });
		sst << stack << ds::endl;
	}
	if(0)
	{
		ds::stack<int> stack(5, [i=0.f]() mutable { return ++i; });
		sst << stack << ds::endl;
	}
	if(0)
	{
		int values[] { 1,2,3 };
		// stack = { ds::begin(values), ds::end(values) };
		ds::stack<ds::unique<int>> stack(ds::begin(values), ds::end(values));
		sst << stack << ds::endl;
	}
	if(0)
	{
		ds::stack<ds::unique<int>> stack;
		stack.push(5);
		stack.push(6);
		stack.push(7);
		sst << stack << ds::endl;
		// auto stack2 = stack;
	}
	if(0)
	{
		ds::heap<-1,int> min_heap(16);
		min_heap.push(2);
		min_heap.push(3);
		min_heap.push(1);
		min_heap.push(5);
		sst << min_heap << ds::endl;
		while(min_heap.size() > 0)
			sst << min_heap.pop() << ds::endl;
	}
	if(0)
	{
		ds::heap<1,int> max_heap(16);
		max_heap.push(2);
		max_heap.push(3);
		max_heap.push(1);
		max_heap.push(5);
		sst << max_heap << ds::endl;
		while(max_heap.size() > 0)
			sst << max_heap.pop() << ds::endl;
	}
}
