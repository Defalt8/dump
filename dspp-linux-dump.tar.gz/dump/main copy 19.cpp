#include <ds/all>
#include <ds/heap>

ds::string_stream<> sst(1024);

#include ".dump/helpers"

template class ds::Queue<ds::unique<int>>;
template class ds::Queue<int>;

struct Int
{
	int i = 0;
};

template <class OST>
static OST &
operator<<(OST & ost, Int const & rhs)
{
	return ost << rhs.i;
}

int main()
{
	if(0)
	{
		ds::queue<Int> queue({1,2,3,4});
		sst << queue << ds::endl;
	}
	// if(0)
	{
		ds::queue<int> queue(5, ds::sequence<int>(1));
		sst << queue << ds::endl;
	}
	// if(0)
	{
		ds::queue<int> queue(5, ds::sequence<float>(1));
		sst << queue << ds::endl;
	}
	// if(0)
	{
		ds::queue<int> queue(5, [i=0]() mutable { return ++i; });
		sst << queue << ds::endl;
	}
	// if(0)
	{
		ds::queue<int> queue(5, [i=0.f]() mutable { return ++i; });
		sst << queue << ds::endl;
	}
	// if(0)
	{
		int values[] { 1,2,3 };
		// queue = { ds::begin(values), ds::end(values) };
		ds::queue<ds::unique<int>> queue(ds::begin(values), ds::end(values));
		sst << queue << ds::endl;
	}
	// if(0)
	{
		ds::queue<ds::unique<S>> queue(3);
		queue.push(5);
		queue.push(6);
		queue.push(7);
		queue.pop();
		sst << queue << ds::endl;
		queue.push(8);
		sst << queue << ds::endl;
		queue.pop();
		sst << queue << ds::endl;
		queue.push(9);
		queue.pop();
		queue.pop();
		queue.pop();
		sst << queue << ds::endl;
		// auto queue2 = queue;
	}
}
