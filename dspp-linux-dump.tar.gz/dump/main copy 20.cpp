#include <ds/all>
#include <ds/heap>

ds::string_stream<> sst(1024);

class App
{
	// ds::aligned_bytes<128> _;
 public:
	void 
	run() const
	{
		sst << "running..." << ds::endl;
	}
	ds::co 
	co_run(ds::co_ _co_)
	{
		if(_co_ == ds::co_::resume)
		{
			sst << "run pass..." << ds::endl;
			return ds::co::_yield;
		}
		sst << "run term..." << ds::endl;
		return ds::co::_return;
	}
};

struct B
{
	int b = 0x01020304;
	B(int i) : b { i } {}
	virtual ~B() = default;
	virtual int get() const = 0;

	inline bool operator==(B const & rhs) const noexcept { return (this->get() == rhs.get()); }
	// inline bool operator!=(B const & rhs) const noexcept { return (this->get() != rhs.get()); }
	// inline bool operator<=(B const & rhs) const noexcept { return (this->get() <= rhs.get()); }
	// inline bool operator>=(B const & rhs) const noexcept { return (this->get() >= rhs.get()); }
	inline bool operator< (B const & rhs) const noexcept { return (this->get() <  rhs.get()); }
	// inline bool operator> (B const & rhs) const noexcept { return (this->get() >  rhs.get()); }

};

template class ds::Unique<B>;
template class ds::Persistent<B>;
template class ds::Shared<B>;

struct A : B
{
	double d = 3.1f;
	int a = 0x0a0b0c0d;
	A(int i) : B{i}, a { i } {}
	int get() const override { return a; }
};

namespace ds {
	template <>
	struct Hasher<B> : Hasher<int>
	{
		static inline size_t hash(B const & rhs) noexcept { return Hasher<int>::hash(rhs.get());}
	};

	template <>
	struct OrderedHasher<B> : OrderedHasher<int>
	{
		static inline size_t hash(B const & rhs) noexcept { return OrderedHasher<int>::hash(rhs.get());}
	};
	template <>
	struct Hasher<A> : Hasher<int>
	{
		static inline size_t hash(A const & rhs) noexcept { return Hasher<int>::hash(rhs.a);}
	};

	template <>
	struct OrderedHasher<A> : OrderedHasher<int>
	{
		static inline size_t hash(A const & rhs) noexcept { return OrderedHasher<int>::hash(rhs.a);}
	};
} // namespace ds

template <class OST>
static OST &
operator<<(OST & ost, B const & rhs)
{
	return ost << rhs.get();
}

template <class OST>
static OST &
operator<<(OST & ost, A const & rhs)
{
	return ost << rhs.a;
}

int main()
{
	if(0)
	{
		constexpr size_t usage = ds::usage_s<ds::ordered_list<8,ds::unique<A>>,5>::value;
		auto _allocmem = ds::allocators::memo_wrapper<ds::allocators::local_forward<usage>>();
		auto ordered_list = ds::ordered_list<8,ds::unique<B>>(ds::make<A>(), {3,2,4,5,1});
		sst << ordered_list << ds::endl;
	}
	if(0)
	{
		constexpr size_t usage = ds::usage_s<ds::unordered_list<8,ds::shared<A>>,5>::value;
		auto _allocmem = ds::allocators::memo_wrapper<ds::allocators::local_forward<usage>>();
		auto unordered_list = ds::unordered_list<8,ds::shared<B>>(ds::make<A>(), {3,2,4,5,1});
		sst << unordered_list << ds::endl;
	}
	if(0)
	{
		constexpr size_t usage = ds::usage_s<ds::list<2,ds::shared<A>>,5>::value;
		auto _allocmem = ds::allocators::memo_wrapper<ds::allocators::local_forward<usage>>();
		auto list = ds::list<2,ds::shared<B>>(ds::make<A>(), {1,2,3,4,5});
		sst << list << ds::endl;
	}
	if(0)
	{
		constexpr size_t usage = ds::usage_s<ds::queue<ds::persistent<A>>,5>::value;
		auto _allocmem = ds::allocators::memo_wrapper<ds::allocators::local_forward<usage>>();
		auto queue = ds::queue<ds::persistent<B>>(ds::make<A>(), {1,2,3,4,5});
		sst << queue << ds::endl;
	}
	if(0)
	{
		constexpr size_t usage = ds::usage_s<ds::queue<ds::unique<A>>,5>::value;
		auto _allocmem = ds::allocators::memo_wrapper<ds::allocators::local_forward<usage>>();
		auto queue = ds::queue<ds::unique<B>>(ds::make<A>(), {1,2,3,4,5});
		sst << queue << ds::endl;
	}
	if(0)
	{
		constexpr size_t usage = ds::usage_s<ds::stack<ds::unique<A>>,5>::value;
		auto _allocmem = ds::allocators::memo_wrapper<ds::allocators::local_forward<usage>>();
		auto stack = ds::stack<ds::unique<B>>(ds::make<A>(), {1,2,3,4,5});
		sst << stack << ds::endl;
	}
	if(0)
	{
		constexpr size_t usage = ds::usage_s<ds::array<ds::unique<A>>,5>::value;
		auto _allocmem = ds::allocators::memo_wrapper<ds::allocators::local_forward<usage>>();
		auto array = ds::array<ds::unique<B>>({{ds::make<A>(), 1},{ds::make<A>(), 2},{ds::make<A>(), 3},{ds::make<A>(), 4},{ds::make<A>(), 5}});
		sst << array << ds::endl;
	}
	if(0)
	{
		constexpr size_t usage = ds::usage_s<ds::array<ds::unique<int>>,5>::value;
		auto _allocmem = ds::allocators::memo_wrapper<ds::allocators::local_forward<usage>>(ds::noinit);
		auto array = ds::array<ds::unique<int>>({1,2,3,4,5});
		sst << array << ds::endl;
	}
	if(0)
	{
		constexpr size_t usage = ds::usage_s<ds::array<int>,5>::value;
		auto _allocmem = ds::allocators::memo_wrapper<ds::allocators::local_forward<usage>>();
		auto array = ds::array<int>({1,2,3,4,5});
		sst << array << ds::endl;
	}
	if(0)
	{
		using R = void;
		constexpr size_t _usage     = ds::usage<ds::coroutine_impl<R(App::*)() const>>::value;
		constexpr size_t _callable  = ds::usage<ds::callable_impl<R(App::*)() const>>::value;
		constexpr size_t _coroutine = ds::usage<ds::coroutine_impl<R(App::*)() const>>::value;
		constexpr size_t _data      = ds::usage<ds::coroutine<R()>::data_t>::value;
		auto _allocmem = ds::allocators::memo_wrapper<ds::allocators::local_forward<_usage>>();
		// ds::coroutine<void()> cor(App(), &App::co_run);
		App app;
		ds::coroutine<R()> cor(app, &App::co_run);
		cor.resume();
	}
	if(0)
	{
		constexpr size_t _usage = ds::usage<ds::callable_impl<void(App::* const)() const,App>>::value;
		auto _allocmem = ds::allocators::memo_wrapper<ds::allocators::local_forward<_usage>>();
		ds::callable<void()> run(App(), &App::run);
		run();
	}
	if(0)
	{
		auto lamb = [&,i=0]() mutable { sst << "lambda" << ds::endl; };
		sizeof(decltype(lamb));
		constexpr size_t _usage = ds::usage<ds::callable_impl<void(),decltype(lamb)>>::value;
		auto _allocmem = ds::allocators::memo_wrapper<ds::allocators::local_forward<_usage>>();
		ds::callable<void()> clamb(lamb);
		clamb();
	}
	if(0)
	{
		constexpr size_t usage_l = ds::usage_s<ds::list<2,int>,5>::value;
		auto _allocmem = ds::allocators::memo_wrapper<ds::allocators::local_forward<usage_l>>();
		auto l = ds::list<2,int>({1,2,3,4,5});
		sst << l << ds::endl;
	}
	if(0)
	{
		constexpr size_t usage_ol = ds::usage_s<ds::ordered_list<8,int>,5>::value;
		auto _allocmem = ds::allocators::memo_wrapper<ds::allocators::local_forward<usage_ol>>();
		auto ol = ds::ordered_list<8,int>({1,2,3,4,5});
		sst << ol << ds::endl;
	}
	{
		constexpr size_t usage_u = ds::usage<ds::unique<int>>::value;
		constexpr size_t usage_s = ds::usage<ds::shared<int>>::value;
		constexpr size_t usage_p = ds::usage<ds::persistent<int>>::value;
	}
	// App app;
	// auto _allocmem = ds::allocators::memo_wrapper<ds::allocators::local_forward<
	// 		ds::usage<ds::coroutine_impl<void(App::*)(),App>>::value
	// 	>>();
	// auto app_run = ds::coroutine<void()>(App(), &App::co_run);
	// app_run.resume();
}
