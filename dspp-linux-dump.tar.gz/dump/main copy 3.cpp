#include <ds/all>
#include <experimental/coroutine>

ds::string_stream<> sst(1024);

template <typename T> struct task;

template <typename T>
struct coroutine : std::experimental::coroutine_handle<task<T>>
{
	using promise_type = struct task<T>; 
};

template <typename T = void>
struct task
{
	coroutine<T>
	get_return_object()
	{
		return { coroutine<T>::from_promise(*this) }; 
	}
	std::experimental::suspend_always initial_suspend() noexcept { return {}; }
	std::experimental::suspend_always final_suspend() noexcept   { return {}; }
	template <typename T_>
	T 
	return_value(T_ && object_) 
	{
		return ds::forward<T_>(object_);
	}
	void unhandled_exception() {}
};

template <>
struct task<void>
{
	coroutine<void>
	get_return_object()
	{
		return { coroutine<void>::from_promise(*this) }; 
	}
	std::experimental::suspend_always initial_suspend() noexcept { return {}; }
	std::experimental::suspend_always final_suspend() noexcept   { return {}; }
	void return_void()         {}
	void unhandled_exception() {}
};


// template <typename T> struct awaitable;

struct resumable;

struct resumable : std::experimental::coroutine_handle<resumable>
{
	using promise_type = resumable;
	bool await_ready() { return false; }
	void await_suspend(std::experimental::coroutine_handle<resumable> h)
	{
	}
	void await_resume() {}
	resumable
	get_return_object()
	{
		return { from_promise(*this) }; 
	}
	std::experimental::suspend_always initial_suspend() noexcept { return {}; }
	std::experimental::suspend_always final_suspend() noexcept   { return {}; }
	void return_void()         {}
	void unhandled_exception() {}
};

// template <typename T>
// struct coroutine : std::experimental::coroutine_handle<task<T>>
// {
// 	using promise_type = struct task<T>; 
// };

resumable
async_sleep(unsigned int usec)
{
	usleep(usec);
	co_await std::experimental::suspend_always();
}

// awaitable<ds::nt_string<>>
// async_read() noexcept
// {
// 	usleep(1000);
// 	auto data = ds::nt_string<>("hello coroutines!");
// 	co_return ds::move(data);
// } 

coroutine<void>
foo()
{
	async_sleep(1000);
	sst << "*" << ds::endl;
	co_return;
}

int main()
{
	auto f = foo();
	f.resume();
	// auto data = co_await async_read();
	// sst << "*" << ds::endl;
	// sst << DS_Cxx_Version << ds::endl;
	// auto choices = ds::make_fixed<ds::string_view>("eat", "sleep", "do something else", "work a little", "read something");
	// auto i = ds::random<int>(int(time(0))).next_range(0, choices.size());
	// sst << choices[i] << ds::endl;
}
