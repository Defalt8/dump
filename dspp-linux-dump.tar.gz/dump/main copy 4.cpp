#include <ds/all>
// #include <experimental/coroutine>

ds::string_stream<> sst(1024);


ds::nt_string<>
async_read(ds::File const & file)
{
	auto file_size     = file.size();
	auto file_position = file.position();
	auto available     = file_position < file_size ? size_t(file_size - file_position) : 0;
	if(available == 0)
	{
		if(file_size < file_position)
			file.set_position(file_size);
		return {};
	}
	else
	{
		auto data = ds::nt_string<>(available);
		if(data.size() == available)
			file.read(&data[0], data.size());
		return data;
	}
}


int main()
{
	ds::file input(WORKING_DIR"input.txt", "rb");
	while(true)
	{
		auto data = async_read(input);
		if(data.size() > 0)
		{
			sst << data << ds::endl;
			if(0 == data.partial_compare("exit"))
				break;
		}
		usleep(100000);
	}
}
