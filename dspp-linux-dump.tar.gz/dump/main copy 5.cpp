#include <ds/all>
// #include <experimental/coroutine>

ds::string_stream<> sst(1024);

enum class cor_e
{
	init,
	cont,
	halt
};

cor_e 
foo(cor_e ct, int & i)
{
	switch(ct)
	{
		case cor_e::init:
		{
			i = 0;
			sst << "foo init." << ds::endl;
			return cor_e::cont;
		}
		case cor_e::cont:
		{
			if(i < 3)
			{
				sst << "foo " << i << ds::endl;
				++i;
				return ct;
			}
			return cor_e::halt;
		}
		case cor_e::halt:
		{
			sst << "foo halted." << ds::endl;
			return ct;
		}
	}
	return cor_e::halt;
}


cor_e 
bar(cor_e ct, int & i)
{
	switch(ct)
	{
		case cor_e::init:
		{
			i = 0;
			sst << "bar init." << ds::endl;
			return cor_e::cont;
		}
		case cor_e::cont:
		{
			if(i < 3)
			{
				sst << "bar " << i << ds::endl;
				++i;
				return ct;
			}
			return cor_e::halt;
		}
		case cor_e::halt:
		{
			sst << "bar halted." << ds::endl;
			return ct;
		}
	}
	return cor_e::halt;
}

template <typename...>
class coroutine;

template <typename T>
class coroutine<void(T)>
{
 public:
	using callable_t = ds::callable<cor_e(cor_e,T &)>;
	using data_t     = ds::unique<T>;

	enum state { suspended, done };

 private:
	callable_t _callable;
	data_t     _data;
	state      _state = state::done;

	coroutine(coroutine const &) = delete;

	void 
	_init()
	{
		if(_callable)
		{
			_data = {};
			if(_data)
			{
				auto ret_ = _callable(cor_e::init, *_data);
				if(ret_ == cor_e::halt)
				{
					_state = state::done;
					_data.destroy();
				}
			}
		}
	}

 public:
	~coroutine()
	{
		if(_state != done && _callable && _data)
		{
			_callable(cor_e::halt, *_data);
		}
	}

	coroutine(callable_t callable_)
		: _callable { ds::move(callable_) }
		, _data     { ds::noinit }
		, _state    { state::suspended }
	{
		this->_init();
	}

	coroutine(coroutine && rhs)
		: _callable { ds::move(rhs._callable) }
		, _data     { ds::move(rhs._data) } 
		, _state    { rhs._state }
	{
		rhs._state = state::done;
	}

	bool 
	resume()
	{
		if(_state != state::done && _callable && _data)
		{
			auto ret_ = _callable(cor_e::cont, *_data);
			if(ret_ == cor_e::halt)
			{
				_state = state::done;
				_data.destroy();
			}
			return true;
		}
		return false;
	}

	bool 
	is_done() const noexcept
	{
		return _state == state::done;
	}

};


int main()
{
	{
		coroutine<void(int)> cor1(foo);
		coroutine<void(int)> cor2(bar);
		// while(!cor1.is_done() || !cor2.is_done())
		{
			cor1.resume();
			cor2.resume();
		}
	}
}
