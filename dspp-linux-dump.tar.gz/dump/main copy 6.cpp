#include <ds/all>

ds::string_stream<> sst(1024);

DS_noreturn void terminate() { exit(0); }
DS_carries_dependency void carry_dep() {}
DS_deprecated void deprecated() {}
DS_deprecated_x("dont") void deprecated_x() {}
void fallthrough(int i) { switch(i){ case 0: DS_fallthrough; case 1: DS_fallthrough; default: break; } }
DS_nodiscard void * nodiscard() { return nullptr; }
DS_nodiscard_x("dont") void * nodiscard_x() { return nullptr; }
DS_maybe_unused void maybe_unused() {}
DS_likely void likely() {}
DS_unlikely void unlikely() {}
DS_optimize_for_synchronized void optimize_for_synchronized() {}
struct no_unique_address
{
	int i;
	DS_no_unique_address struct empty {} empty;
};

struct S
{
	~S() { sst << "~S();" << ds::endl; }
	S() { sst << "S();" << ds::endl; }
	S(S&&) { sst << "S(S&&);" << ds::endl; }
	S(S const &) { sst << "S(S const &);" << ds::endl; }
};

ds::coroutine_state 
foo(ds::coroutine_state cor_state, int & i, S & s)
{
	if(cor_state == ds::coroutine_state::resume)
	{
		sst << "foo " << i << ds::endl;
		++i;
		return i < 3 ? ds::coroutine_state::suspend : ds::coroutine_state::halt;
	}
	else if(cor_state == ds::coroutine_state::init)
	{
		i = 0; 
		return ds::coroutine_state::suspend;
	}
	return cor_state;
};

int main()
{
	ds::coroutine<void(int,S)> cor1 = foo;
	ds::coroutine<void(int,float)> cor2 = [](ds::coroutine_state cor_state, int & i, float & f)
	{
		if(cor_state == ds::coroutine_state::resume)
		{
			sst << "lambda " << i << " " << f << ds::endl;
			++i;
			f += .1f;
			return ds::coroutine_state::suspend;
		}
		else if(cor_state == ds::coroutine_state::init)
		{
			i = 5; 
			f = 3.4f;
			return ds::coroutine_state::suspend;
		}
		return cor_state;
	};
	cor1.resume();
	cor2.resume();
	cor1.resume();
	cor2.resume();
	cor1.resume();
	cor2.resume();
	cor1.resume();
	cor2.resume();

}
