#include <ds/all>

ds::string_stream<> sst(1024);

using ds::co_;
using ds::co;

int main()
{
	ds::coroutine<void()> cor([i=5](co_ _co_) mutable
	{
		if(_co_ == co_::resume)
		{
			sst << "coroutine  " << i << ds::endl;
			return ++i < 8 ? co::_yield : co::_return;
		}
		return co::_return;
	});
	while(cor.resume());
}




int _main2()
{
	ds::coroutine<int(int)> cor(5, ds::init, [](co_ _co_, int & ret, int & i)
	{
		if(_co_ == co_::resume)
		{
			ret = i * 3;
			return ++i < 8 ? co::_yield : co::_return;
		}
		return co::_return;
	});
	for(int * y = cor.resume(); y != nullptr; y = cor.resume())
		sst << *y << "  or  " << *cor.get_yield() << ds::endl;
	return 0;
}






int _main()
{
	ds::coroutine<void(int)> cor1 = [](co_ _co_, int & i)
	{
		if(_co_ == co_::resume)
		{
			sst << "coroutine-1  " << i++ << ds::endl;
			return i < 3 ? co::_yield : co::_return;
		}
		return co::_return;
	};
	ds::coroutine<void()> cor2 = [](co_ _co_)
	{
		if(_co_ == co_::resume)
		{
			sst << "coroutine-2" << ds::endl;
			return co::_yield;
		}
		sst << "coroutine-2 halt" << ds::endl;
		return co::_return;
	};
	while(cor1.resume())
		cor2.resume();

	return 0;
}

