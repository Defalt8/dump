#include <ds/all>

ds::string_stream<> sst(1024);

using ds::co_; using ds::co;

int main()
{
	auto seed = uint8_t(time(0));
	// auto seed = 199;
	sst << seed << ds::endl;
	{
		ds::list<2,uint8_t> data(10, ds::random_sequence<uint8_t>(seed));
		sst << data << ds::endl;
		// ds::sort(ds::begin(data), ds::end(data), data.size());
		ds::sort(data);
		// sst << data << ds::endl;
		assert(ds::is_sorted(data));
	}
	{
		ds::array<uint8_t>  data(10, ds::random_sequence<uint8_t>(seed));
		sst << data << ds::endl;
		// ds::sort(ds::begin(data), ds::end(data), data.size());
		ds::sort(data);
		// sst << data << ds::endl;
		assert(ds::is_sorted(data));
	}
}
