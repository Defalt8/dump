#include <ds/all>
#include "benchmark"
#include <algorithm>

ds::string_stream<> sst(1024);

struct S 
{ 
	int i = 0; S(int i = 0) : i {i} {} DS_constexpr14 bool operator<(S const & rhs) const noexcept { return i < rhs.i; } 
};

namespace ds {

template <typename It, typename C = less<remove_cvref_t<decltype(*decl<It &>())>>>
static DS_constexpr14 void
heapify(It begin_, It end_, C && compare = {})
{
	if(begin_ != end_)
	{
		size_t size_ = size_t(end_ - begin_);
		for(size_t i = 0; i < size_; ++i)
		{
			size_t p = (n - 1) / 2;
			auto & parent = begin_[p];
			auto & child  = begin_[i];
			if(compare(child, parent))
				ds::swap(child, parent);
		}
	}
}

template <typename It, typename C = less<remove_cvref_t<decltype(*decl<It &>())>>>
static DS_constexpr14 void
heap_sort(It begin_, It end_, C && compare = {})
{}

} // namespace ds

int main()
{
	// {
	// 	size_t n  = 3;
	// 	size_t np = ds::factorial<size_t>(n);
	// 	for(size_t i = 0; i < np; ++i)
	// 	{
	// 		ds::array<int> data({1,2,3});
	// 		ds::permutate(i, data);
	// 		ds::_::_sort3(data[0], data[1], data[2], ds::less<int>());
	// 		assert(ds::is_sorted(data));
	// 	}
	// }
	// {
	// 	size_t n  = 4;
	// 	size_t np = ds::factorial<size_t>(n);
	// 	for(size_t i = 0; i < np; ++i)
	// 	{
	// 		ds::array<int> data({1,2,3,4});
	// 		ds::permutate(i, data);
	// 		ds::_::_sort4(data[0], data[1], data[2], data[3], ds::less<int>());
	// 		assert(ds::is_sorted(data));
	// 	}
	// }
	// {
	// 	size_t n  = 5;
	// 	size_t np = ds::factorial<size_t>(n);
	// 	for(size_t i = 0; i < np; ++i)
	// 	{
	// 		ds::array<int> data({1,2,3,4,5});
	// 		ds::permutate(i, data);
	// 		// ds::_::_sort5(data[0], data[1], data[2], data[3], data[4], ds::less<int>());
	// 		ds::linear_sort(data.begin(), data.end());
	// 		assert(ds::is_sorted(data));
	// 	}
	// }
	// return 0;
	using T = int64_t;
	auto   seed  = T(time(0));
	size_t size_ = 10000000, count = 1, warmup = 1;
	sst << size_ << ds::endl;
	auto data_ = ds::array<T>(size_, ds::random_sequence<T>(seed));

	// auto std_sort_array = [&,data=ds::array<T>(size_, ds::random_sequence<T>(seed))]() mutable
	// {
	// 	std::sort(ds::begin(data), ds::end(data), ds::less<T>());
	// 	// assert(ds::is_sorted(data));
	// };

	// auto sort_array = [&,data=ds::array<T>(size_, ds::random_sequence<T>(seed))]() mutable
	// {
	// 	ds::sort(ds::begin(data), ds::end(data), ds::less<T>());
	// 	// ds::sort(data);
	// 	assert(ds::is_sorted(data));
	// };
	
	// auto sort_list = [&,data=ds::list<2,T>(size_, ds::random_sequence<T>(seed))]() mutable
	// {
	// 	ds::sortl(ds::begin(data), ds::end(data), ds::size(data), ds::less<T>());
	// 	// ds::sort(data);
	// 	assert(ds::is_sorted(data));
	// };
	
	// auto sort_list_ref = [&,data=ds::list<2,T>(size_, ds::random_sequence<T>(seed))]() mutable
	// {
	// 	ds::array<T &> list_ref(data);
	// 	ds::sort(ds::begin(list_ref), ds::end(list_ref), ds::less<T>());
	// 	// ds::sort(list_ref);
	// 	assert(ds::is_sorted(data));
	// };
	
	// {
	// 	auto data = ds::clone(data_);
	// 	auto sorted = false;
	// 	benchmark::delay(.1);
	// 	benchmark::rep_test("ds::sort array", [&]()
	// 	{
	// 		ds::sort(data);
	// 		sorted = ds::is_sorted(data);
	// 	});
	// 	sst << sorted << ds::endl;
	// }
	{
		auto data = ds::clone(data_);
		auto sorted = false;
		benchmark::delay(.1);
		benchmark::rep_test("ds::sort array", [&]()
		{
			ds::sort(ds::begin(data), ds::end(data), ds::less<T>());
			// ds::sort(data);
			// assert(ds::is_sorted(data));
			// sorted = ds::is_sorted(data);
		});
		// sst << sorted << ds::endl;
	}
	{
		auto data = ds::clone(data_);
		auto sorted = false;
		benchmark::delay(.1);
		benchmark::rep_test("ds::sort array", [&]()
		{
			ds::sort(ds::begin(data), ds::end(data), ds::less<T>());
			// ds::sort(data);
			// assert(ds::is_sorted(data));
			// sorted = ds::is_sorted(data);
		});
		// sst << sorted << ds::endl;
	}
	{
		auto data = ds::clone(data_);
		auto sorted = false;
		benchmark::delay(.1);
		benchmark::rep_test("std::sort array", [&]()
		{
			std::sort(ds::begin(data), ds::end(data), ds::less<T>());
			// ds::sort(data);
			// assert(ds::is_sorted(data));
			// sorted = ds::is_sorted(data);
		});
		// sst << sorted << ds::endl;
	}
	{
		auto data = ds::clone(data_);
		auto sorted = false;
		benchmark::delay(.1);
		benchmark::rep_test("std::sort array", [&]()
		{
			std::sort(ds::begin(data), ds::end(data), ds::less<T>());
			// ds::sort(data);
			// assert(ds::is_sorted(data));
			// sorted = ds::is_sorted(data);
		});
		// sst << sorted << ds::endl;
	}
	{
		auto data = ds::clone(data_);
		auto sorted = false;
		benchmark::delay(.1);
		benchmark::rep_test("ds::sort array", [&]()
		{
			ds::sort(ds::begin(data), ds::end(data), ds::less<T>());
			// ds::sort(data);
			// assert(ds::is_sorted(data));
			// sorted = ds::is_sorted(data);
		});
		// sst << sorted << ds::endl;
	}
	{
		auto data = ds::clone(data_);
		auto sorted = false;
		benchmark::delay(.1);
		benchmark::rep_test("ds::sort array", [&]()
		{
			ds::sort(ds::begin(data), ds::end(data), ds::less<T>());
			// ds::sort(data);
			// assert(ds::is_sorted(data));
			// sorted = ds::is_sorted(data);
		});
		// sst << sorted << ds::endl;
	}
	// benchmark::rep_test("std::sort array", std_sort_array, count);
	// benchmark::rep_test("ds::sort array", sort_array, count);
	// benchmark::rep_test("ds::sort list", sort_list, count);
	// benchmark::rep_test("ds::sort list ref", sort_list_ref, count);
	
}
