#include <ds/all>

ds::string_stream<> sst(1024);

bool enumerate(ds::string_view const & current, ds::string_view const & entry)
{
	sst << entry << ds::endl;
	auto full_path = ds::string<>(current, entry);
	if(ds::sys::is_dir(full_path))
		ds::sys::ls(full_path, enumerate);
	return true;
};

int main()
{
	ds::sys::mkdirs(WORKING_DIR"test/a/b/c");
	ds::sys::mkfile(WORKING_DIR"test/t");
	ds::sys::mkfile(WORKING_DIR"test/a/u");
	// ds::sys::rmdirs(WORKING_DIR"test");
	ds::sys::remove(WORKING_DIR"test");
	// ds::sys::ls(WORKING_DIR"test", enumerate);
	return 0;
	auto choices = ds::make_fixed<ds::string_view>("sleep", "do something else", "work a little", "read something");
	auto i = ds::random<size_t>(size_t(time(0))).next_range(0, choices.size());
	sst << choices[i] << ds::endl;
}
