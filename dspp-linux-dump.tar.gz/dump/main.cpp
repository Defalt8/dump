#include <ds/all>

ds::string_stream<> sst(1024);

int main()
{
	{
		sst << ds::sys::get_cwd() << ds::endl;
		ds::sys::set_cwd("..");
		sst << ds::sys::get_cwd() << ds::endl;
	}
	if(0)
	{
		auto entries = ds::list<2,ds::string<>>();
		auto sls = ds::sys::ls(".", entries);
		// auto sls = ds::sys::ls(WORKING_DIR, entries);
		// auto sls = ds::sys::ls(WORKING_DIR"_test_file.txt", entries);
		// auto sls = ds::sys::ls(WORKING_DIR"_test_fil", entries);
		ds::stream_separator = "\n";
		sst << entries << ds::endl;
	}
	// auto choices = ds::make_fixed<ds::string_view>("sleep", "do something else", "work a little", "read something");
	// auto choices = ds::make_fixed<ds::string_view>("dir", "directory", "dirent");
	// auto i = ds::random<size_t>(size_t(time(0))).next_range(0, choices.size());
	// sst << choices[i] << ds::endl;
}
