#include <ds/all>
#include <ds/mutex>
#include <ds/semaphore>
#include <ds/thread>


ds::string_stream<> sst(1024); 
ds::mutex           sst_mutex;

struct task
{
	int                   priority = 0;
	ds::coroutine<void()> coroutine;
	int                   assigned = 0;
	bool                  parallel = true;
	ds::mutex             mutex;
	// ds::persistent<ds::thread_info> thread_info { ds::noinit };

	task() = default;
	task(task &&) = default;
	task(task const &) = delete;
	template <typename... Args>
	task(int priority_, Args &&... args)
		: priority  { priority_ }
		, coroutine { ds::forward<Args>(args)... }
	{}

	void
	swap(task & rhs) noexcept
	{
		mutex.release();
		mutex.lock();
		rhs.mutex.release();
		rhs.mutex.lock();
		ds::swap(priority, rhs.priority);
		ds::swap(coroutine, rhs.coroutine);
		ds::swap(assigned, rhs.assigned);
		ds::swap(parallel, rhs.parallel);
		rhs.mutex.release();
		mutex.release();
	}

	inline bool operator<(task const & rhs) const noexcept { return priority < rhs.priority; }
	inline bool operator>(task const & rhs) const noexcept { return priority > rhs.priority; }
};

#include "../.dump/benchmark"

int main()
{
	auto task_queue    = ds::queue<ds::unique<task>>(32);
	auto task_mutex    = ds::mutex();
	auto task_update   = ds::semaphore();
	auto task_init_seq = int(0);
	auto task_runs     = ds::queue<size_t>(8);
	auto workers       = ds::stack<ds::thread>(ds::sys::nprocessors(), 
		[&]() 
		{
			return ds::thread(ds::thread_params(
				(ds::thread_params::affinity_t(1) << task_init_seq), 
				[&]()
				{ 
					auto bsst = ds::nt_string_stream<>(32);
					bsst << "thread " << (++task_init_seq);
					return ds::nt_string<>(bsst.view());
				}()
			)
			, [&]()
			{
				auto & current_thread = ds::thread::current;
				// {
				// 	auto lock = ds::mutex_lock(sst_mutex);
				// 	sst << "- worker thread '" << current_thread->name() << "' started!" << ds::endl;
				// }
				task_update.await();
				while(!current_thread->is_terminating())
				{
					// {
					// 	bool all_done = true;
					// 	for(auto it = task_queue.begin(); 
					// 		   !current_thread->is_terminating()
					// 		&& it != task_queue.end()
					// 		&& (*it)->mutex.try_lock();
					// 		++it)
					// 	{
					// 		auto & task = **it;
					// 		if(task.coroutine.is_not_done())
					// 		{
					// 			all_done = false;
					// 			task.coroutine.resume();
					// 		}
					// 		task.mutex.release();
					// 	}
					// 	if(all_done)
					// 		break;
					// }
					task * my_task = nullptr;
					// pick high priority tasks
					{
						auto lock = ds::mutex_lock(task_mutex);
						if(task_queue.size() == 0)
							break;
						for(auto & task : task_queue)
						{
							bool pick = task->assigned == 0;
							if(pick)
							{
								my_task = task.ptr();
								++task->assigned;
								break;
							}
						}
					}
					if(my_task != nullptr)
					{
						{
							auto lock = ds::mutex_lock(my_task->mutex);
							while(!current_thread->is_terminating() && my_task->coroutine.is_not_done())
								my_task->coroutine.resume();
						}
						if(my_task->coroutine.is_done())
						{
							auto lock = ds::mutex_lock(task_mutex);
							auto it   = task_queue.begin();
							for(; it != task_queue.end() && (*it).ptr() != my_task; ++it);
							if(it != task_queue.end())
							{
								if(it != task_queue.begin())
									ds::swap(task_queue.bottom(), *it);
								task_queue.pop();
							}
						}
					}
				}
			});
	});
	// {
	// 	for(auto & worker : workers)
	// 		worker.info().sem().await();
	// }
	// {
	// 	auto lock = ds::mutex_lock(sst_mutex);
	// 	sst << workers.size() << ds::endl;
	// }
	for(int i = 0; i < 7; ++i)
	{
		task_runs.push(0);
		task_queue.push(i, ds::coroutine<void()>(ds::coroutine<void(int)>([&,i](ds::co_ _co_, int & j)
		{  
			if(_co_ == ds::co_::resume)
			{
				++task_runs[i];
				// {
				// 	auto lock = ds::mutex_lock(sst_mutex);
				// 	sst << j << " -- task " << i << " on " << ds::thread::current->name() << ds::endl;
				// }
				// ds::sys::msleep(500);
				// return ds::co::_yield;
				return ++j < 10000000 ? ds::co::_yield : ds::co::_return;
			}
			return ds::co::_return;
		})));
	}
	ds::sort(task_queue);
	benchmark::rep_test("multi-threaded", [&]()
	{
		task_update.signal(int(task_queue.size()));
		for(auto & worker : workers)
			worker.join();
	});
	// benchmark::rep_test("single-threaded", [&]()
	// {
	// 	for(auto & task : task_queue)
	// 	{
	// 		while(task->coroutine.is_not_done())
	// 			task->coroutine.resume();
	// 	}
	// });
	for(auto & task_run : task_runs)
		sst << task_run << ds::endl;
}