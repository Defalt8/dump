#include <ds/all>

ds::string_stream<> sst(1024); 

namespace ds {

template <class C
		, typename It = decltype(begin(decl<C>()))
		, typename E  = decltype(*decl<It &>())
		, class    P  = less<remove_cvref_t<E>>
		, typename    = decltype(decl<It &>() + decl<size_t>())
		, typename    = decltype(decl<E &>() = decl<E &>())
	>
static DS_constexpr14 It
bubble_to_top(C && idx_iterable, P && compare = {})
{
	auto size_ = size(idx_iterable);
	if(size_ <= 1)
		return begin(idx_iterable);
	It   begin_ = begin(idx_iterable);
	It   it_    = begin_;
	auto size_1 = size_ - 1;
	for(size_t c, i = 0; i < size_1; it_ = (begin_ + i))
	{
		c = 2 * i + 1;
		if(c > size_1)
		{
			auto rbegin_ = begin_ + size_1;
			if(it_ != rbegin_)
			{
				ds::swap(*it_, *rbegin_);
				size_t p = (i + 1) / 2;
				It parent_ = begin_ + p;
				assert(!compare(*it_, *parent_));
				return ds::move(rbegin_);
			}
		}
		else if(c < size_1)
		{
			auto & parent  = *(begin_ + i);
			auto & child_1 = *(begin_ + c);
			auto & child_2 = *(begin_ + c + 1);
			if(compare(child_1, child_2))
			{
				if(compare(parent, child_1))
					ds::swap(parent, child_1);
				i = c;
			}
			else
			{
				if(compare(parent, child_2))
					ds::swap(parent, child_2);
				i = c + 1;
			}
		}
		else
		{
			auto & parent  = *(begin_ + i);
			auto & child_1 = *(begin_ + c);
			if(compare(parent, child_1))
				ds::swap(parent, child_1);
			i = c;
		}
	}
	return ds::move(it_);
}

template <class C
		, typename It = decltype(begin(decl<C>()))
		, typename E  = decltype(*decl<It &>())
		, class    P  = less<remove_cvref_t<E>>
		, typename    = decltype(decl<It &>() + decl<size_t>())
		, typename    = decltype(decl<E &>() = decl<E &>())
	>
static DS_constexpr14 It
bubble_down(C && idx_iterable, P && compare = {})
{
	auto size_ = size(idx_iterable);
	if(size_ <= 1)
		return begin(idx_iterable);
	It begin_ = begin(idx_iterable);
	It it_    = begin_ + (size_ - 1);
	for(size_t p, i = size_ - 1; i > 0; i = p, it_ = (begin_ + i))
	{
		p = (i - 1) / 2;
		auto & parent = *(begin_ + p);
		auto & child  = *it_;
		if(compare(child, parent))
			ds::swap(child, parent);
	}
	return ds::move(it_);
}

} // namespace ds

// #include "../.dump/helpers"


int main()
{
	if(0)
	{
		constexpr auto P = ds::factorial<uint64_t>(11);
		for(uint64_t n = 0; n < P; ++n)
		{
			constexpr size_t usage_ = ds::usage_s<ds::stack<int>,8>::value;
			ds::allocators::memo_wrapper<ds::allocators::LocalForward<usage_>>(ds::noinit);
			ds::stack<int> max_heap({3,7,1,4,3,7,5,10,11,20,0});
			ds::heapify(max_heap, ds::greater<int>());
			// sst << max_heap << ds::endl;
			while(max_heap.size() > 0)
			{
				auto it = ds::bubble_to_top(max_heap, ds::greater<int>());
				assert(it == ds::rbegin(max_heap));
				// sst << max_heap << ds::endl;
				max_heap.pop();
				// sst << max_heap << ds::endl;
			}
		}
	}
}
