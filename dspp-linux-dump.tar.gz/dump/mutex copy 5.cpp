#include <ds/all>

ds::string_stream<> sst(1024); 

// #include "../.dump/helpers"

#define massert(...) if(!(__VA_ARGS__)) { throw __LINE__; abort(); }

int main()
{
	// if(0)
	{
		constexpr auto P = ds::factorial<uint64_t>(10);
		for(uint64_t n = 0; n < P; ++n)
		{
			constexpr size_t usage_ = ds::usage_s<ds::stack<int>,8>::value;
			ds::allocators::memo_wrapper<ds::allocators::LocalForward<usage_>>(ds::noinit);
			ds::stack<int> max_heap({30,43,72,43,37,73,5,10,11,20});
			ds::heapify(max_heap, ds::greater<int>());
			// sst << max_heap << ds::endl;
			massert(ds::validate_heap(max_heap, ds::greater<int>()));
			while(max_heap.size() > 0)
			{
				auto it = ds::bubble_to_top(max_heap, ds::greater<int>());
				massert(it == ds::rbegin(max_heap));
				// sst << max_heap << ds::endl;
				max_heap.pop();
				massert(ds::validate_heap(max_heap, ds::greater<int>()));
				// sst << max_heap << ds::endl;
			}
		}
	}
}
