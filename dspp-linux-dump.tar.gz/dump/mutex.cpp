#include <ds/all>
#include <ds/mutex>
#include <ds/semaphore>
#include <ds/thread>

ds::string_stream<> sst(1024); 

class Semaphore
{
	ds::Mutex _mutex;
	size_t    _count   = 0;
	size_t    _waiting = 0;

 public:
	Semaphore()
	{}

	bool 
	await()
	{
		_mutex.lock();
		++_waiting;
		while(_mutex.release() && _count == 0)
			_mutex.lock();
		--_count;
		_mutex.release();
		return true;
	}

	bool
	signal(size_t count_ = 1)
	{
		_mutex.lock();
		++_count;
		_mutex.release();
		return true;
	}

};

int main()
{
	{
		sst << "start!" << ds::endl;
		// ds::semaphore sync1, sync2;
		Semaphore sync1, sync2;
		// Semaphore sync;
		// ds::semaphore sync;
		ds::thread thread_0({0b1, "thread 0"}, [&](ds::persistent<ds::thread *> thread)
		{
			if(!thread || thread->is_terminating())
			{
				sst << "halt thread!" << ds::endl;
				return; 
			}
			auto params = ds::thread::current->params();
			auto id     = ds::thread::current->id();
			for(size_t i = 0; i < 5; ++i)
			{
				// sync.await();
				sync1.await();
				sst << "inside thread! : " << params.name << "  " << id << ds::endl;
				// sync.signal();
				sync2.signal();
			}
		});
		ds::thread thread_1({0b10, "thread 1"}, [&](ds::persistent<ds::thread *> thread)
		{
			if(!thread || thread->is_terminating())
			{
				sst << "halt thread!" << ds::endl;
				return; 
			}
			auto params = ds::thread::current->params();
			auto id     = ds::thread::current->id();
			for(size_t i = 0; i < 5; ++i)
			{
				// sync.await();
				sync2.await();
				sst << "inside thread! : " << params.name << "  " << id << ds::endl;
				// sync.signal();
				sync1.signal();
			}
		});
		ds::sys::sleep_millis(200);
		// sync.signal();
		sync1.signal();
		thread_0.join();
		thread_1.join();
		sst << "done!" << ds::endl;
	}
	// if(0)
	// {
	// 	sst << "start!" << ds::endl;
	// 	// ds::semaphore sync1, sync2;
	// 	Semaphore sync1, sync2;
	// 	ds::thread thread_0({0b1, "thread 0"}, [&](ds::persistent<ds::thread *> thread)
	// 	{
	// 		if(!thread || thread->is_terminating())
	// 		{
	// 			sst << "halt thread!" << ds::endl;
	// 			return; 
	// 		}
	// 		auto params = thread->params();
	// 		for(size_t i = 0; i < 5; ++i)
	// 		{
	// 			sync1.await();
	// 			// msync1.lock();
	// 			sst << "inside thread! : " << params.name << ds::endl;
	// 			sync2.signal();
	// 			// msync2.release();
	// 		}
	// 	});
	// 	ds::thread thread_1({0b10, "thread 1"}, [&](ds::persistent<ds::thread *> thread)
	// 	{
	// 		if(!thread || thread->is_terminating())
	// 		{
	// 			sst << "halt thread!" << ds::endl;
	// 			return; 
	// 		}
	// 		auto params = thread->params();
	// 		for(size_t i = 0; i < 5; ++i)
	// 		{
	// 			sync2.await();
	// 			// msync2.lock();
	// 			sst << "inside thread! : " << params.name << ds::endl;
	// 			sync1.signal();
	// 			// msync1.release();
	// 		}
	// 	});
	// 	sync1.signal();
	// 	// msync1.release();
	// 	thread_0.join();
	// 	thread_1.join();
	// 	// msync1.release();
	// 	// msync2.release();
	// 	sst << "done!" << ds::endl;
	// }
}