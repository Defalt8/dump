
	template <typename E, class C>
	static DS_constexpr14 void
	_sort3(E & a, E & b, E & c, C && compare)
	{
		if(compare(a, b))
		{
			if(compare(c, b))
			{
				if(compare(a, c))
				{
					ds::swap(b, c);
				}
				else
				{
					ds::swap(b, c);
					ds::swap(a, b);
				}
			}
		}
		else if(compare(a, c))
		{
			ds::swap(a, b);
		}
		else if(compare(c, b))
		{
			ds::swap(a, c);
		}
		else 
		{
			ds::swap(a, c);
			ds::swap(a, b);
		}
	}
