
	template <typename E, class C>
	static DS_constexpr14 void
	_sort4(E & a, E & b, E & c, E & d, C && compare)
	{
		if(compare(a, b))
		{
			if(compare(b, c))
			{
				if(compare(d, c))
				{
					if(compare(b, d))
					{
						ds::swap(c, d);
					}
					else if(compare(a, d))
					{
						E tmp = ds::move(d);
						d = ds::move(c);
						c = ds::move(b);
						b = ds::move(tmp);
					}
					else
					{
						E tmp = ds::move(d);
						d = ds::move(c);
						c = ds::move(b);
						b = ds::move(a);
						a = ds::move(tmp);
					}
				}
				// else
				// // sorted
			}
			else if(compare(a, c))
			{
				if(compare(b, d))
				{
					ds::swap(b, c);
				}
				else if(compare(c, d))
				{
					E tmp = ds::move(b);
					b = ds::move(c);
					c = ds::move(d);
					d = ds::move(tmp);
				}
				else if(compare(a, d))
				{
					ds::swap(b, d);
				}
				else
				{
					E tmp = ds::move(d);
					d = ds::move(b);
					b = ds::move(a);
					a = ds::move(tmp);
				}
			}
			else if(compare(b, d))
			{
				E tmp = ds::move(c);
				c = ds::move(b);
				b = ds::move(a);
				a = ds::move(tmp);
			}
			else if(compare(a, d))
			{
				E tmp = ds::move(d);
				d = ds::move(b);
				b = ds::move(a);
				a = ds::move(c);
				c = ds::move(tmp);
			}
			else if(compare(c, d))
			{
				ds::swap(a, c);
				ds::swap(b, d);
			}
			else
			{
				E tmp = ds::move(d);
				d = ds::move(b);
				b = ds::move(c);
				c = ds::move(a);
				a = ds::move(tmp);
			}
		}
		else
		{
			if(compare(a, c))
			{
				if(compare(c, d))
				{
					ds::swap(a, b);
				}
				else if(compare(d, a))
				{
					if(compare(d, b))
					{
						E tmp = ds::move(d);
						d = ds::move(c);
						c = ds::move(a);
						a = ds::move(tmp);
					}
					else 
					{
						E tmp = ds::move(d);
						d = ds::move(c);
						c = ds::move(a);
						a = ds::move(b);
						b = ds::move(tmp);
					}
				}
				else
				{
					ds::swap(a, b);
					ds::swap(c, d);
				}
			}
			else if(compare(b, c))
			{
				if(compare(a, d))
				{
					E tmp = ds::move(a);
					a = ds::move(b);
					b = ds::move(c);
					c = ds::move(tmp);
				}
				else if(compare(c, d))
				{
					E tmp = ds::move(a);
					a = ds::move(b);
					b = ds::move(c);
					c = ds::move(d);
					d = ds::move(tmp);
				}
				else if(compare(b, d))
				{
					E tmp = ds::move(a);
					a = ds::move(b);
					b = ds::move(d);
					d = ds::move(tmp);
				}
				else
				{
					ds::swap(a, d);
				}
			}
			else if(compare(a, d))
			{
				ds::swap(a, c);
			}
			else if(compare(b, d))
			{
				E tmp = ds::move(a);
				a = ds::move(c);
				c = ds::move(d);
				d = ds::move(tmp);
			}
			else if(compare(c, d))
			{
				E tmp = ds::move(a);
				a = ds::move(c);
				c = ds::move(b);
				b = ds::move(d);
				d = ds::move(tmp);
			}
			else
			{
				ds::swap(a, d);
				ds::swap(b, c);
			}
		}
	}
