
	template <typename E, class C>
	static DS_constexpr14 void
	_sort5(E & a, E & b, E & c, E & d, E & e, C && compare)
	{
		if(compare(a, b))
		{
			if(compare(a, c))
			{
				if(compare(a, d))
				{
					if(compare(e, a))
						ds::swap(a, e);
				}
				else if(compare(e, d))
				{
					ds::swap(a, e);
				}
				else
				{
					ds::swap(a, d);
				}
			}
			else if(compare(c, d))
			{
				if(compare(c, e))
				{
					ds::swap(a, c);
				}
				else 
				{
					ds::swap(a, e);
				}
			}
			else if(compare(d, e))
			{
				ds::swap(a, d);
			}
			else
			{
				ds::swap(a, e);
			}
		}
		else if(compare(b, c))
		{
			if(compare(b, d))
			{
				if(compare(b, e))
				{
					ds::swap(a, b);
				}
				else
				{
					ds::swap(a, e);
				}
			}
			else if(compare(d, e))
			{
				ds::swap(a, d);
			}
			else
			{
				ds::swap(a, e);
			}
		}
		else if(compare(c, d))
		{
			if(compare(c, e))
			{
				ds::swap(a, c);
			}
			else
			{
				ds::swap(a, e);
			}
		}
		else if(compare(d, e))
		{
			ds::swap(a, d);
		}
		else
		{
			ds::swap(a, e);
		}
		_sort4(b, c, d, e, ds::forward<C>(compare));
	}
