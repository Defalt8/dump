#include <pptest>
#include <colored_printer>
#include <ds/common>
#include <ds/allocator>

Test(allocator_interface_test)
{
	TestInit(allocator_interface_test);

	Testcase(test_allocate_requirements)
	{
	// 	AssertTrue(ds::is_same<decltype(ds::allocator_interface::allocate(size_t(0), ds::align_t(0))), void *>::value);
	} TestcaseEnd(test_allocate_requirements);

};

TestRegistry(allocator_interface_test)
{
	Register(test_allocate_requirements)
};

template <class C> using reporter_t = pptest::colored_printer<C>;

#include <ds/all>

class MyAllocator : public ds::AllocatorBase
{
 public:
	DS_nodiscard void *
	allocate(size_t size_, ds::align_t align_ = alignof(ds::max_align_t)) override
	{
		return ds::NewDeleteAllocator::allocate(size_, align_);
	}

	void
	deallocate(void * block_) noexcept override
	{
		ds::NewDeleteAllocator::deallocate(block_);
	}
};

class Base
{
	alignas(64) ds::byte_t bytes[16] {};
 public:
	Base() { ds::string_stream<>(64) << "Base::Base()" << ds::endl; }
	virtual ~Base() { ds::string_stream<>(64) << "Base::~Base()" << ds::endl; }
	virtual void foo() { ds::string_stream<>(64) << "Base::foo" << ds::endl; }
};

class Derived : public Base
{
	alignas(8) ds::byte_t bytes[16] {};

 public:
	Derived()  { ds::string_stream<>() << "Derived::Derived("<< alignof(Derived) <<":" << (size_t(this) % alignof(Derived)) << ")" << ds::endl; }
	~Derived() { ds::string_stream<>() << "Derived::~Derived(" << sizeof(Derived) << ")" << ds::endl; }
	void foo() { ds::string_stream<>() << "Derived::foo" << ds::endl; }
};

#include <ds/all>

namespace _ {

	template <typename T>
	static constexpr T cxmin(T l, T r) noexcept { return l < r ? l : r; }

	template <typename T, size_t m_ = 0, size_t i_ = 0, T... values_>
	struct min_value_index : ds::integral_constant<size_t,m_>
	{};

	template <typename T,size_t m_, size_t i_, T value_0, T value_1, T... values_>
	struct min_value_index<T,m_,i_,value_0,value_1,values_...> 
		: ds::integral_constant<T,min_value_index<T
				, (value_0 < value_1 ? m_ : (i_ + 1)) 
				, (i_ + 1)
				, cxmin<T>(value_0, value_1)
				, values_...>::value>
	{};

} // namespace _

template <typename T, T... values_>
struct min_value_index : ds::integral_constant<size_t,_::min_value_index<T,0,0,values_...>::value>
{};

namespace _ {

	template <typename T, size_t m_ = 0, size_t i_ = 0, T... values_>
	struct min_value_indices : ds::integral_constant<size_t,m_>
	{};

	template <typename T,size_t m_, size_t i_, T value_0, T value_1, T... values_>
	struct min_value_indices<T,m_,i_,value_0,value_1,values_...> 
		: ds::integral_constant<T,min_value_index<T
				, (value_0 < value_1 ? m_ : (i_ + 1)) 
				, (i_ + 1)
				, cxmin<T>(value_0, value_1)
				, values_...>::value>
	{};

} // namespace _

template <typename T, T... values_>
struct min_value_index : ds::integral_constant<size_t,_::min_value_index<T,0,0,values_...>::value>
{};

template <typename T, typename... Ts>
struct min_type
{};

template <typename T, typename... Ts>
struct min_type
{
	using type = ds::type_at_index_t<min_value_index<size_t,sizeof(T),sizeof(Ts)...>::value,T,Ts...>;
};

template <typename T, typename... Ts>
using minimal_tuple_t = ds::Tuple<T,Ts...>;

int main()
{
	{
		ds::string_stream<>() << min_value_index<int>::value << ds::endl;
		ds::string_stream<>() << min_value_index<int,1>::value << ds::endl;
		ds::string_stream<>() << min_value_index<int,1,2>::value << ds::endl;
		ds::string_stream<>() << min_value_index<int,2,1>::value << ds::endl;
		ds::string_stream<>() << min_value_index<int,2,1,3>::value << ds::endl;
		ds::string_stream<>() << min_value_index<int,2,3,1>::value << ds::endl;
		ds::string_stream<>() << min_value_index<int,2,4,3,1>::value << ds::endl;
	}
	return 0;
	// {
	// 	{ using T = ds::Tuple<int32_t,int64_t>; ds::string_stream<>() << alignof(T) << " -- " << sizeof(T) << ds::endl; }
	// 	{ using T = ds::Tuple<int64_t,int32_t>; ds::string_stream<>() << alignof(T) << " -- " << sizeof(T) << ds::endl; }
	// }
	{
		using T       = Base;
		using count_t = size_t;
		using Storage = ds::Tuple<T *,count_t,T>;
		{ using TP = ds::Tuple<T *,count_t,T>; ds::string_stream<>() << alignof(TP) << " -- " << sizeof(TP) << ds::endl; }
		{ using TP = ds::Tuple<T *,T,count_t>; ds::string_stream<>() << alignof(TP) << " -- " << sizeof(TP) << ds::endl; }
		{ using TP = ds::Tuple<T,T *,count_t>; ds::string_stream<>() << alignof(TP) << " -- " << sizeof(TP) << ds::endl; }
		// ds::string_stream<>() << alignof(Base)    << " -- " << sizeof(Base)    << ds::endl;
		// ds::string_stream<>() << alignof(Derived) << " -- " << sizeof(Derived) << ds::endl;
		// ds::string_stream<>() << alignof(Storage) << " -- " << sizeof(Storage) << ds::endl;
	}
	return 0;
	{
		ds::string_stream<>() << sizeof(Base) << ds::endl;
		ds::string_stream<>() << sizeof(Derived) << ds::endl;
		ds::string_stream<>() << sizeof(ds::persistent<Base>::Storage) << ds::endl;
	}
	return 0;
	{
		ds::persistent<Base> base{ ds::make<Derived>() };
		base->foo();
	}
	return 0;
	{
		ds::Shared<Base> base{ ds::make<Derived>() };
		base->foo();
	}
	return 0;
	{
		using uid = struct {};
		auto lfa = ds::allocator_wrapper<uid,ds::local_forward_allocator<512>>();
		ds::Shared<Base,decltype(lfa)::Interface> base{ ds::make<Derived>() };
		base->foo();
	}
	return 0;
	{
		auto sst = ds::string_stream<>(64);
		sst << "hello world!" << ds::endl;
	}
	try
	{
		auto lalloc0 = ds::local_forward_allocator<ds::usage_s<ds::string_stream<>,12>::value>();
		auto sali0   = ds::default_allocator_interface(lalloc0);
		
		auto sst = ds::string_stream<>(10);
		sst << "hello world!" << ds::endl;

		{
			auto lalloc1 = ds::local_forward_allocator<ds::usage_s<ds::list<1,int>,5>::value>();
			auto sali1   = ds::default_allocator_interface(lalloc1);
			
			auto list = ds::list<1,int>{{1,2,3,4,5}};
			sst << list << ds::endl;
		}

	}
	catch(ds::exception const & ex)
	{
		using LID  = struct {};
		auto alloc = ds::nt_allocator_wrapper<LID,ds::local_forward_nt_allocator<512>>();
		auto esst  = ds::string_stream<decltype(alloc)::Interface>(511);
		esst << "--- exception thrown: " << ex.what() << ds::Endl{stderr};
	}

	if(0)
	{
		using LID = struct {};
		using SALI = ds::stacked_allocator_interface<LID,3,ds::allocator_base>;

		ds::AllocatorBase new_delete;
		SALI ialloc(new_delete);

		{
			auto localloc1 = ds::local_forward_allocator<512>();
			SALI ialloc1 = localloc1;
			assert(ialloc1 == localloc1);
			assert(ialloc  == ialloc1);

			auto map = ds::ordered_map<16,ds::string_view,int,SALI>({{"C",1},{"A",2},{"B",3}});

			{
				auto localloc2 = ds::local_forward_allocator<512>();
				SALI ialloc2 = localloc2;
				assert(ialloc2 == localloc2);
				assert(ialloc2 == ialloc1);
				assert(ialloc2 == ialloc);

				auto sst = ds::string_stream<SALI>(511);
				sst << map << ds::endl;
			}
			assert(ialloc == localloc1);

		}

	}
    // return 0;
	// try
	// {
	// 	using LID = struct {};
	// 	using ALI = ds::allocator_interface<LID,ds::allocator_base>;

	// 	ds::dynamic_forward_allocator dynalloc(512);
	// 	auto alloci = ALI(dynalloc);
	// 	{
	// 		auto map = ds::ordered_map<16,ds::string_view,int,ALI>(
	// 			{ {"C",1}, {"A",2}, {"B",3} }
	// 		);
	// 		auto sst = ds::string_stream<ALI>(511);
	// 		sst << map << ds::endl;
	// 	}
	// 	ds::local_forward_allocator<512> localloc;
	// 	alloci = localloc;
	// 	auto sst = ds::string_stream<ALI>(511);
	// 	sst << "hello Earth" << ds::endl;
	// }
	// catch(ds::exception const & ex)
	// {
	// 	using LID = struct {};
	// 	auto alloc = ds::nt_allocator_wrapper<LID,ds::local_forward_nt_allocator<64>>();
	// 	auto esst = ds::string_stream<decltype(alloc)::Interface>(63);
	// 	esst << "--- exception thrown: " << ex.what() << ds::Endl{stderr};
	// }

}




	// return allocator_interface_test().run_all(reporter_t<allocator_interface_test>(pptest::normal));
	