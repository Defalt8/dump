#include <pptest>
#include <colored_printer>
#include <ds/common>
#include <ds/allocator>

Test(allocator_interface_test)
{
	TestInit(allocator_interface_test);

	Testcase(test_allocate_requirements)
	{
	// 	AssertTrue(ds::is_same<decltype(ds::allocator_interface::allocate(size_t(0), ds::align_t(0))), void *>::value);
	} TestcaseEnd(test_allocate_requirements);

	// Testcase(test_deallocate_requirements)
	// {
	// 	AssertTrue(ds::is_same<decltype(ds::allocator_interface::deallocate((void *)nullptr)), void>::value);
	// } TestcaseEnd(test_deallocate_requirements);

	// Testcase(test_passing_allocation)
	// {
	// 	constexpr size_t size_ = 32;
	// 	auto block_ = ds::allocator_interface::allocate(size_);
	// 	AssertNotNull(block_);
	// 	ds::allocator_interface::deallocate(block_);
	// } TestcaseEnd(test_passing_allocation);

	// Testcase(test_failing_allocation)
	// {
	// 	constexpr size_t size_ = -1;
	// 	void * block_ = nullptr;
	// 	ExpectThrow(ds::allocator_interface::allocation_failure const &, block_ = ds::allocator_interface::allocate(size_));
	// 	ExpectNull(block_);
	// 	ds::allocator_interface::deallocate(block_);
	// 	ExpectThrow(std::bad_alloc const &, block_ = ds::allocator_interface::allocate(size_));
	// 	ExpectNull(block_);
	// 	ds::allocator_interface::deallocate(block_);
	// } TestcaseEnd(test_failing_allocation);

	// Testcase(test_zero_size_allocation)
	// {
	// 	constexpr size_t size_ = 0;
	// 	auto block_ = ds::allocator_interface_nt::allocate(size_);
	// 	AssertNotNull(block_);
	// 	ds::allocator_interface_nt::deallocate(block_);
	// } TestcaseEnd(test_zero_size_allocation);

};

TestRegistry(allocator_interface_test)
{
	Register(test_allocate_requirements)
	// Register(test_deallocate_requirements)
	// Register(test_passing_allocation)
	// Register(test_failing_allocation)
	// Register(test_zero_size_allocation)
};

template <class C> using reporter_t = pptest::colored_printer<C>;

#include <ds/all>

class MyAllocator : public ds::AllocatorBase
{
 public:
	DS_nodiscard void *
	allocate(size_t size_, ds::align_t align_ = alignof(ds::max_align_t)) override
	{
		return ds::NewDeleteAllocator::allocate(size_, align_);
	}

	void
	deallocate(void * block_) noexcept override
	{
		ds::NewDeleteAllocator::deallocate(block_);
	}
};

int main()
{
	try
	{
		using LID = struct {};
		auto alloc = ds::allocator_wrapper<LID,ds::dynamic_forward_allocator>(1024);
		
		ds::array<int,decltype(alloc)::Interface> array {{ 1,2,3,4,5 }};

		ds::string_stream<decltype(alloc)::Interface> sst;
		sst << array << ds::endl;
	}
	catch(ds::exception const & ex)
	{
		using LID = struct {};
		auto alloc = ds::allocator_wrapper_nt<LID,ds::local_forward_allocator_nt<128>>();
		ds::string_stream<decltype(alloc)::Interface> esst { 64 };
		esst << "--- exception thrown: " << ex.what() << ds::Endl{stderr};
	}

	// return allocator_interface_test().run_all(reporter_t<allocator_interface_test>(pptest::normal));
	
}
