#include <pptest>
#include <colored_printer>
#include <ds/array>
#include <ds/traits/iterable>
#include "../counter"
#include "../nocopy"
#include "../nomove"

template class ds::Array<int>;
template class ds::Array<NoMove>;
template class ds::Array<NoCopy>;

Test(array_test)
{
	 
	TestInit(array_test);

	template <typename T>
	struct Sequence 
	{
		T cur; 
		constexpr Sequence(T start_ = {}) : cur { start_ } {}
		constexpr operator T() { return cur++; }
	};

	template <class C, typename E, size_t size_>
	static bool
	compare_eq(C const & iterable, E const (& rhs)[size_])
	{
		if(ds::size(iterable) != size_)
			return false;
		auto it = ds::begin(iterable);
		for(size_t i = 0; i < size_; ++i, ++it)
			if(*it != rhs[i])
				return false;
		return true;
	}

	PreRun()
	{
		Counter::reset();
	}

	Testcase(test_default_constructor)
	{
		{
			AssertThrowNone(ds::Array<Counter> {});
			ds::Array<Counter> array {};
			AssertNull(array);
			AssertEQ(Counter::count(), 0);
			AssertEQ(Counter::active(), 0);
			AssertEQ(Counter::moves(), 0);
			AssertEQ(Counter::copies(), 0);
		}
		AssertEQ(Counter::count(), 0);
		AssertEQ(Counter::active(), 0);
		AssertEQ(Counter::moves(), 0);
		AssertEQ(Counter::copies(), 0);
	} TestcaseEnd(test_default_constructor);

	Testcase(test_size_constructor_with_zero_size)
	{
		{
			constexpr size_t size_ = 0;
			AssertThrowNone(ds::Array<Counter> {size_});
			ds::Array<Counter> array {size_};
			AssertNotNull(array);
			AssertEQ(Counter::count(), 0);
			AssertEQ(Counter::active(), 0);
			AssertEQ(Counter::moves(), 0);
			AssertEQ(Counter::copies(), 0);
		}
		AssertEQ(Counter::count(), 0);
		AssertEQ(Counter::active(), 0);
		AssertEQ(Counter::moves(), 0);
		AssertEQ(Counter::copies(), 0);
	} TestcaseEnd(test_size_constructor_with_zero_size);

	Testcase(test_size_constructor_with_non_zero_size)
	{ 
		AssertThrowNone(
		{
			ds::Array<Counter> array {5};
			AssertNotNull(array);
			AssertEQ(Counter::count(), 5);
			AssertEQ(Counter::active(), 5);
			AssertEQ(Counter::moves(), 0);
			AssertEQ(Counter::copies(), 0);
		});
		AssertEQ(Counter::count(), 5);
		AssertEQ(Counter::active(), 0);
		AssertEQ(Counter::moves(), 0);
		AssertEQ(Counter::copies(), 0);
	} TestcaseEnd(test_size_constructor_with_non_zero_size);

	Testcase(test_size_constructor_with_failing_size)
	{ 
		AssertThrow(ds::DefaultAllocator::allocation_failure const &, ds::Array<Counter>(size_t(-1)));
		AssertThrow(std::bad_alloc const &, ds::Array<Counter>(size_t(-1)));
		AssertEQ(Counter::count(), 0);  
		AssertEQ(Counter::active(), 0);
		AssertEQ(Counter::moves(), 0);
		AssertEQ(Counter::copies(), 0);
	} TestcaseEnd(test_size_constructor_with_failing_size);

	Testcase(test_array_constructor)
	{
		{
			ds::Array<Counter> array {{1,2,3,4,5}};
			AssertNotNull(array);
			AssertEQ(Counter::count(), 5);
			AssertEQ(Counter::active(), 5);
			AssertEQ(Counter::moves(), 0);
			AssertEQ(Counter::copies(), 0);
			AssertTrue(compare_eq(array, {1,2,3,4,5}));
		}
		AssertEQ(Counter::count(), 5);
		AssertEQ(Counter::active(), 0);
		AssertEQ(Counter::moves(), 0);
		AssertEQ(Counter::copies(), 0);
	} TestcaseEnd(test_array_constructor);

	Testcase(test_initializer_list_constructor)
	{
		{
			ds::Array<Counter> array = {1,2,3,4,5};
			AssertNotNull(array);
			AssertEQ(Counter::count(), 5);
			AssertEQ(Counter::active(), 5); 
			AssertEQ(Counter::moves(), 0);
			AssertEQ(Counter::copies(), 0);
			AssertTrue(compare_eq(array, {1,2,3,4,5}));
		}
		AssertEQ(Counter::count(), 5);
		AssertEQ(Counter::active(), 0);
		AssertEQ(Counter::moves(), 0);
		AssertEQ(Counter::copies(), 0);
	} TestcaseEnd(test_initializer_list_constructor);

	Testcase(test_move_constructor)
	{
		{
			ds::Array<Counter> array {{1,2,3,4,5}};
			AssertNotNull(array);
			AssertEQ(Counter::count(), 5);
			AssertEQ(Counter::active(), 5);
			AssertEQ(Counter::moves(), 0);
			AssertEQ(Counter::copies(), 0);
			ds::Array<Counter> moved_array = ds::move(array);
			AssertNotNull(moved_array);
			AssertNull(array);
			AssertEQ(Counter::count(), 5);
			AssertEQ(Counter::active(), 5);
			AssertEQ(Counter::moves(), 0);
			AssertEQ(Counter::copies(), 0);
			AssertTrue(compare_eq(moved_array, {1,2,3,4,5}));
		}
		AssertEQ(Counter::count(), 5);
		AssertEQ(Counter::active(), 0);
		AssertEQ(Counter::moves(), 0);
		AssertEQ(Counter::copies(), 0);
	} TestcaseEnd(test_move_constructor);

	Testcase(test_copy_constructor)
	{
		{
			ds::Array<Counter> array {{1,2,3,4,5}};
			AssertNotNull(array);
			AssertEQ(Counter::count(), 5);
			AssertEQ(Counter::active(), 5);
			AssertEQ(Counter::moves(), 0);
			AssertEQ(Counter::copies(), 0);
			auto begin_ = array.begin();
			ds::Array<Counter> copied_array = array;
			AssertNotNull(copied_array);
			AssertNotNull(array);
			AssertEQ(begin_, array.begin());
			AssertNEQ(begin_, copied_array.begin());
			AssertEQ(Counter::count(), 10);
			AssertEQ(Counter::active(), 10);
			AssertEQ(Counter::moves(), 0);
			AssertEQ(Counter::copies(), 5);
			AssertTrue(compare_eq(array, {1,2,3,4,5}));
			AssertTrue(compare_eq(copied_array, {1,2,3,4,5}));
		}
		AssertEQ(Counter::count(), 10);
		AssertEQ(Counter::active(), 0);
		AssertEQ(Counter::moves(), 0);
		AssertEQ(Counter::copies(), 5);
	} TestcaseEnd(test_copy_constructor);

	Testcase(test_nomove_passing_constructor)
	{
		ds::Array<NoMove> array {{1,2}};
		AssertEQ(sizeof(array), sizeof(ds::Array<int>));
		AssertNotNull(array);
		AssertFalse(ds::is_move_constructible<NoMove>::value);
		AssertTrue(ds::is_move_constructible<ds::Array<NoMove>>::value);
		auto copied_array = array;
		auto moved_array = ds::move(array);
	} TestcaseEnd(test_nomove_passing_constructor);

	Testcase(test_nocopy_failing_constructor)
	{
		ds::Array<NoCopy> array {{1,2}};
		AssertEQ(sizeof(array), sizeof(ds::Array<int>)); 
		AssertNotNull(array);
		AssertFalse(ds::is_copy_constructible<NoCopy>::value);
		AssertFalse(ds::is_copy_constructible<ds::Array<NoCopy>>::value);
		// auto copied_array = array;
		auto moved_array = ds::move(array);
	} TestcaseEnd(test_nocopy_failing_constructor);

	template <typename T
		, typename E   = ds::enabled_iterable_element_t<T>
		, typename CIt = ds::enabled_iterable_const_forward_iterator_t<T>>
	static E
	accumulate(T const & const_forward_iterable)
	{
		E total_ = {};
		CIt begin_ = ds::begin(const_forward_iterable);
		CIt end_   = ds::end(const_forward_iterable);
		for(auto it = begin_; it != end_; ++it)
			total_ += *it;
		return total_;
	}

	Testcase(test_iterable_traits_in_function_template_test)
	{
		constexpr size_t size_ = 5;
		ds::Array<int> array_ = {{1,2,3,4,5}};
		auto total_ = accumulate(array_);
		AssertTrue(ds::is_same<decltype(total_),int>::value);
		AssertEQ(total_, 15);
	} TestcaseEnd(test_iterable_traits_in_function_template_test);

};

TestRegistry(array_test)
{
	Register(test_default_constructor)
	Register(test_size_constructor_with_zero_size)
	Register(test_size_constructor_with_non_zero_size)
	Register(test_size_constructor_with_failing_size)
	Register(test_array_constructor)
	Register(test_initializer_list_constructor)
	Register(test_move_constructor)
	Register(test_copy_constructor)
	Register(test_nomove_passing_constructor)
	Register(test_nocopy_failing_constructor)
	Register(test_iterable_traits_in_function_template_test)
};

template <class C> using reporter_t = pptest::colored_printer<C>; 

#include <ds/list>
#include <ds/hash_list>
#include <ds/hash_map>

#include <cstdlib>
#include <algorithm>
#include <vector>
#include <list>

#include <iostream>

template <typename T
	, typename = ds::enabled_iterable_const_forward_iterator_t<T>
	>
static constexpr void
println(T && forward_iterable)
{
	auto end_   = ds::end(ds::cref(forward_iterable));
	for(auto it = ds::begin(ds::cref(forward_iterable)); it != end_; ++it)
		std::cout << *it << " ";
	std::cout << std::endl;
}

template class ds::Array<int &>;

int main()
{
	srand(uint32_t(time(0)));
	{
		std::vector<int> vector;
		for(int i = 0; i < 10; ++i)
			vector.push_back(rand() % 10);
		println(vector);
		ds::sort(vector.begin(), vector.end());
		println(vector);
	}
	println("------------------------");
	{
		ds::list<2,int> list(10, []() -> int { return rand() % 10; } );
		println(list);
		ds::array<int &> list_ref(list.size(), [&,it = list.begin()]() mutable -> int & { return *(it++); } );
		ds::sort(list_ref.begin(), list_ref.end());
		println(list);
	}
	println("------------------------");
	{
		std::list<int> list;
		for(int i = 0; i < 10; ++i)
			list.push_back(rand() % 10);
		println(list);
		// ds::array<int &> list_ref(list.size(), [&,it = list.begin()]() mutable -> int & { return *(it++); } );
		ds::array<int &> list_ref(list);
		ds::sort(list_ref.begin(), list_ref.end());
		println(list);
	}
	println("------------------------");
	// if(0)
	{
		ds::array<int> array1(10, []() -> int { return rand() % 10; } );
		println(array1);
		ds::sort(array1.begin(), array1.end());
		println(array1);
	}
	return 0;
	using LFA = ds::LocalForwardAllocator<2048>;
	using uid1_ = struct {};
	using ALI1 = ds::AllocatorInterface<uid1_,LFA>;
	using uid2_ = struct {};
	using ALI2 = ds::AllocatorInterface<uid2_,LFA>;
	LFA lalloc1 (ds::noinit);
	ALI1 ali1(lalloc1);
	ALI2 ali2(lalloc1);
	{
		ds::array<uint8_t,ALI1> array1 {{1,2,3,4,5}};
		ds::array<uint8_t,ALI2> array2 {{6,7,8,9}};
		array1[0] = 9;
		array2[0] = 10;
		array1 = {{10,20}};
		array2 = {{30,40,50}};
		array1[0] = 9;
		array2[0] = 10;
	}
	printf("%d - %d\n", ALI1::allocations, ALI1::deallocations);
	{
		ds::list<1,uint8_t,ALI1> list {{1,2,3,4,5}};
		// array[0] = 9;
	}
	printf("%d - %d\n", ALI1::allocations, ALI1::deallocations);
	{
		ds::list<2,uint8_t,ALI1> list {{1,2,3,4,5}};
		// array[0] = 9;
	}
	printf("%d - %d\n", ALI1::allocations, ALI1::deallocations);
	{
		ds::hash_list<16,uint8_t,ALI1> hash_list {{1,2,3,4,5}};
		// array[0] = 9;
	}
	printf("%d - %d\n", ALI1::allocations, ALI1::deallocations);
	{
		ds::hash_map<16,uint8_t,uint8_t,ALI1> hash_map {{
			{uint8_t(1),uint8_t(10)},
			{uint8_t(2),uint8_t(20)},
			{uint8_t(3),uint8_t(30)},
			{uint8_t(4),uint8_t(40)},
			{uint8_t(5),uint8_t(50)}
		}};
		// array[0] = 9;
	}
	printf("%d - %d\n", ALI1::allocations, ALI1::deallocations);
	// return array_test().run_all(reporter_t<array_test>(pptest::normal));
}