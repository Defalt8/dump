#include <type_traits>
#include <pptest>
#include <colored_printer>
#include <ds/array>
#include <ds/traits/iterable>
#include "../counter"
#include "../nocopy"
#include "../nomove"

template class ds::Array<int>;
template class ds::Array<NoMove>;
template class ds::Array<NoCopy>;

Test(array_test)
{

	template <typename T>
	struct Sequence 
	{
		T cur; 
		constexpr Sequence(T start_ = {}) : cur { start_ } {}
		constexpr operator T() { return cur++; }
	};

	template <class C, typename E, size_t size_>
	static bool
	compare_eq(C const & iterable, E const (& rhs)[size_])
	{
		if(ds::size(iterable) != size_)
			return false;
		auto it = ds::begin(iterable);
		for(size_t i = 0; i < size_; ++i, ++it)
			if(*it != rhs[i])
				return false;
		return true;
	}

	PreRun(array_test)
	{
		Counter::reset();
	}

	Testcase(array_test, test_default_constructor)
	{
		{
			AssertThrowNone(ds::Array<Counter> {});
			ds::Array<Counter> array {};
			AssertNull(array);
			AssertEQ(Counter::count(), 0);
			AssertEQ(Counter::active(), 0);
			AssertEQ(Counter::moves(), 0);
			AssertEQ(Counter::copies(), 0);
		}
		AssertEQ(Counter::count(), 0);
		AssertEQ(Counter::active(), 0);
		AssertEQ(Counter::moves(), 0);
		AssertEQ(Counter::copies(), 0);
	} TestcaseEnd(array_test, test_default_constructor);

	Testcase(array_test, test_size_constructor_with_zero_size)
	{
		{
			constexpr size_t size_ = 0;
			AssertThrowNone(ds::Array<Counter> {size_});
			ds::Array<Counter> array {size_};
			AssertNotNull(array);
			AssertEQ(Counter::count(), 0);
			AssertEQ(Counter::active(), 0);
			AssertEQ(Counter::moves(), 0);
			AssertEQ(Counter::copies(), 0);
		}
		AssertEQ(Counter::count(), 0);
		AssertEQ(Counter::active(), 0);
		AssertEQ(Counter::moves(), 0);
		AssertEQ(Counter::copies(), 0);
	} TestcaseEnd(array_test, test_size_constructor_with_zero_size);

	Testcase(array_test, test_size_constructor_with_non_zero_size)
	{ 
		AssertThrowNone(
		{
			ds::Array<Counter> array {5};
			AssertNotNull(array);
			AssertEQ(Counter::count(), 5);
			AssertEQ(Counter::active(), 5);
			AssertEQ(Counter::moves(), 0);
			AssertEQ(Counter::copies(), 0);
		});
		AssertEQ(Counter::count(), 5);
		AssertEQ(Counter::active(), 0);
		AssertEQ(Counter::moves(), 0);
		AssertEQ(Counter::copies(), 0);
	} TestcaseEnd(array_test, test_size_constructor_with_non_zero_size);

	Testcase(array_test, test_size_constructor_with_failing_size)
	{ 
		AssertThrow(ds::Allocator::allocation_failure const &, ds::Array<Counter>(-1));
		AssertThrow(std::bad_alloc const &, ds::Array<Counter>(-1));
		AssertEQ(Counter::count(), 0); 
		AssertEQ(Counter::active(), 0);
		AssertEQ(Counter::moves(), 0);
		AssertEQ(Counter::copies(), 0);
	} TestcaseEnd(array_test, test_size_constructor_with_failing_size);

	Testcase(array_test, test_array_constructor)
	{
		{
			ds::Array<Counter> array {{1,2,3,4,5}};
			AssertNotNull(array);
			AssertEQ(Counter::count(), 5);
			AssertEQ(Counter::active(), 5);
			AssertEQ(Counter::moves(), 0);
			AssertEQ(Counter::copies(), 0);
			AssertTrue(compare_eq(array, {1,2,3,4,5}));
		}
		AssertEQ(Counter::count(), 5);
		AssertEQ(Counter::active(), 0);
		AssertEQ(Counter::moves(), 0);
		AssertEQ(Counter::copies(), 0);
	} TestcaseEnd(array_test, test_array_constructor);

	Testcase(array_test, test_initializer_list_constructor)
	{
		{
			ds::Array<Counter> array = {1,2,3,4,5};
			AssertNotNull(array);
			AssertEQ(Counter::count(), 5);
			AssertEQ(Counter::active(), 5); 
			AssertEQ(Counter::moves(), 0);
			AssertEQ(Counter::copies(), 0);
			AssertTrue(compare_eq(array, {1,2,3,4,5}));
		}
		AssertEQ(Counter::count(), 5);
		AssertEQ(Counter::active(), 0);
		AssertEQ(Counter::moves(), 0);
		AssertEQ(Counter::copies(), 0);
	} TestcaseEnd(array_test, test_initializer_list_constructor);

	Testcase(array_test, test_move_constructor)
	{
		{
			ds::Array<Counter> array {{1,2,3,4,5}};
			AssertNotNull(array);
			AssertEQ(Counter::count(), 5);
			AssertEQ(Counter::active(), 5);
			AssertEQ(Counter::moves(), 0);
			AssertEQ(Counter::copies(), 0);
			ds::Array<Counter> moved_array = ds::move(array);
			AssertNotNull(moved_array);
			AssertNull(array);
			AssertEQ(Counter::count(), 5);
			AssertEQ(Counter::active(), 5);
			AssertEQ(Counter::moves(), 0);
			AssertEQ(Counter::copies(), 0);
			AssertTrue(compare_eq(moved_array, {1,2,3,4,5}));
		}
		AssertEQ(Counter::count(), 5);
		AssertEQ(Counter::active(), 0);
		AssertEQ(Counter::moves(), 0);
		AssertEQ(Counter::copies(), 0);
	} TestcaseEnd(array_test, test_move_constructor);

	Testcase(array_test, test_copy_constructor)
	{
		{
			ds::Array<Counter> array {{1,2,3,4,5}};
			AssertNotNull(array);
			AssertEQ(Counter::count(), 5);
			AssertEQ(Counter::active(), 5);
			AssertEQ(Counter::moves(), 0);
			AssertEQ(Counter::copies(), 0);
			auto begin_ = array.begin();
			ds::Array<Counter> copied_array = array;
			AssertNotNull(copied_array);
			AssertNotNull(array);
			AssertEQ(begin_, array.begin());
			AssertNEQ(begin_, copied_array.begin());
			AssertEQ(Counter::count(), 10);
			AssertEQ(Counter::active(), 10);
			AssertEQ(Counter::moves(), 0);
			AssertEQ(Counter::copies(), 5);
			AssertTrue(compare_eq(array, {1,2,3,4,5}));
			AssertTrue(compare_eq(copied_array, {1,2,3,4,5}));
		}
		AssertEQ(Counter::count(), 10);
		AssertEQ(Counter::active(), 0);
		AssertEQ(Counter::moves(), 0);
		AssertEQ(Counter::copies(), 5);
	} TestcaseEnd(array_test, test_copy_constructor);

	Testcase(array_test, test_nomove_passing_constructor)
	{
		ds::Array<NoMove> array {{1,2}};
		AssertEQ(sizeof(array), sizeof(ds::Array<int>));
		AssertNotNull(array);
		AssertFalse(ds::is_move_constructible<NoMove>::value);
		AssertTrue(ds::is_move_constructible<ds::Array<NoMove>>::value);
		auto copied_array = array;
		auto moved_array = ds::move(array);
	} TestcaseEnd(array_test, test_nomove_passing_constructor);

	Testcase(array_test, test_nocopy_failing_constructor)
	{
		ds::Array<NoCopy> array {{1,2}};
		AssertEQ(sizeof(array), sizeof(ds::Array<int>)); 
		AssertNotNull(array);
		AssertFalse(ds::is_copy_constructible<NoCopy>::value);
		AssertFalse(ds::is_copy_constructible<ds::Array<NoCopy>>::value);
		// auto copied_array = array;
		auto moved_array = ds::move(array);
	} TestcaseEnd(array_test, test_nocopy_failing_constructor);

	template <typename T
		, typename E   = ds::enabled_iterable_element_t<T>
		, typename CIt = ds::enabled_iterable_const_forward_iterator_t<T>>
	static E
	accumulate(T const & const_forward_iterable)
	{
		E total_ = {};
		CIt begin_ = ds::begin(const_forward_iterable);
		CIt end_   = ds::end(const_forward_iterable);
		for(auto it = begin_; it != end_; ++it)
			total_ += *it;
		return total_;
	}

	Testcase(array_test, test_iterable_traits_in_function_template_test)
	{
		constexpr size_t size_ = 5;
		ds::Array<int> array_ = {{1,2,3,4,5}};
		auto total_ = accumulate(array_);
		AssertTrue(std::is_same<decltype(total_),int>::value);
		AssertEQ(total_, 15);
	} TestcaseEnd(array_test, test_iterable_traits_in_function_template_test);

	Registry(array_test)
	{
		Register(array_test, test_default_constructor)
		Register(array_test, test_size_constructor_with_zero_size)
		Register(array_test, test_size_constructor_with_non_zero_size)
		Register(array_test, test_size_constructor_with_failing_size)
		Register(array_test, test_array_constructor)
		Register(array_test, test_initializer_list_constructor)
		Register(array_test, test_move_constructor)
		Register(array_test, test_copy_constructor)
		Register(array_test, test_nomove_passing_constructor)
		Register(array_test, test_nocopy_failing_constructor)
		Register(array_test, test_iterable_traits_in_function_template_test)
	};

} TestEnd(array_test);


template <class C> using reporter_t = pptest::colored_printer<C>; 

namespace ds {

	/// AlignedBytes ///
	template <size_t size_, size_t align_ = alignof(max_align_t)>
	struct AlignedBytes
	{
		alignas(align_) byte_t bytes[size_]{};
		size_t      size()  const noexcept { return size_; }
		byte_ptr_t  begin()       noexcept { return &bytes[0]; }
		byte_ptr_t  end()         noexcept { return &bytes[size_]; }
		byte_cptr_t begin() const noexcept { return &bytes[0]; }
		byte_cptr_t end()   const noexcept { return &bytes[size_]; }
	};

	/// RawAlignedBytes ///
	template <size_t size_, size_t align_ = alignof(max_align_t)>
	struct RawAlignedBytes
	{
		alignas(align_) byte_t bytes[size_];
		size_t      size()  const noexcept { return size_; }
		byte_ptr_t  begin()       noexcept { return &bytes[0]; }
		byte_ptr_t  end()         noexcept { return &bytes[size_]; }
		byte_cptr_t begin() const noexcept { return &bytes[0]; }
		byte_cptr_t end()   const noexcept { return &bytes[size_]; }
	};

	/// StackAlloc ///
	template <size_t sz_, size_t al_ = alignof(max_align_t)>
	class StackAlloc
	{
		RawAlignedBytes<sz_,al_>  mem {};
		byte_ptr_t                head = &mem.bytes[0];

	 public:
		struct allocation_failure : public std::bad_alloc
		{
			char const * what() const noexcept override { return "failed to allocate the requested amount of memory"; }
		};

		void * 
		allocate(size_t size_, align_t align_ = alignof(max_align_t)) noexcept(false)
		{
			byte_ptr_t head_ = head;
			byte_ptr_t block_ = byte_ptr_t(size_t(head_ + align_ - 1) & ~(align_ - 1));
			if(block_ + size_ > mem.end())
			{
				ds_throw(allocation_failure());
				ds_throw_alt(return nullptr);
			}
			head += size_;
			return block_;
		}

		void 
		deallocate(void * block_) noexcept
		{}

	};

	/// StackAllocNT ///
	template <size_t sz_, size_t al_ = alignof(max_align_t)>
	class StackAllocNT
	{
		RawAlignedBytes<sz_,al_>  mem {};
		byte_ptr_t                head = &mem.bytes[0];

	 public:
		struct allocation_failure : public std::bad_alloc
		{
			char const * what() const noexcept override { return "failed to allocate the requested amount of memory"; }
		};

		void * 
		allocate(size_t size_, align_t align_ = alignof(max_align_t)) noexcept
		{
			byte_ptr_t head_ = head;
			byte_ptr_t block_ = byte_ptr_t(size_t(head_ + align_ - 1) & ~(align_ - 1));
			if(block_ + size_ > mem.end())
				return nullptr;
			head += size_;
			return block_;
		}

		void 
		deallocate(void * block_) noexcept
		{}

	};

// equal to
template <typename L, typename R = L>
struct EQ
{ constexpr bool operator() (L const & lhs, R const & rhs) const noexcept { return lhs == rhs; } };

// less than
template <typename L, typename R = L>
struct LT
{ constexpr bool operator() (L const & lhs, R const & rhs) const noexcept { return lhs < rhs; } };

// greater than
template <typename L, typename R = L>
struct GT
{ constexpr bool operator() (L const & lhs, R const & rhs) const noexcept { return lhs > rhs; } };

// less than or equal to
template <typename T>
struct LTEQ
{ constexpr bool operator() (T const & lhs, T const & rhs) const noexcept { return lhs <= rhs; } };

// greater than or equal to
template <typename L, typename R = L>
struct GTEQ
{ constexpr bool operator() (L const & lhs, R const & rhs) const noexcept { return lhs >= rhs; } };


// template<typename T, class C = ds::LT<T>> 
// bool 
// is_sorted(T const * begin_, T const * end_, C && compare = {}) axl_noexcept
// {
// 	if(!begin_ || begin_ >= end_) 
// 		return false;
// 	T const * const last = end_ - 1;
// 	if(begin_ == last) 
// 		return true;
// 	for(T const * it = begin_; it < last; ++it)
// 		if(compare(it[1], *it))
// 			return false;;
// 	return true;
// }



template<typename E, class C = ds::LT<E>> 
void 
sort(E * begin_, E * end_, C && compare = {}) noexcept
{
	if(!begin_ || begin_ >= end_)
		return;
	while(begin_ < end_)
	{
		E * const last_ = end_ - 1;
		size_t const size_ = (end_ - begin_);
		if(size_ == 1)
			break;
		if(size_ == 2)
		{
			auto & a = begin_[0], & b = begin_[1];
			if(compare(b, a))
				ds::swap(b, a);
			break;
		}
		else if(size_ == 3)
		{
			auto & a = begin_[0], & b = begin_[1], & c = begin_[2];
			if(compare(b, a))
			{
				if(compare(c, b))
					ds::swap(c, a);
				else if(compare(c, a))
				{
					auto ta = a;
					a = b;
					b = c;
					c = ta;
				}
				else
					ds::swap(b, a);
			}
			else if(compare(c, a))
			{
				auto ta = a;
				a = c;
				c = b;
				b = ta;
			}
			else
			{
				if(compare(c, b))
					ds::swap(c, b);
			}
			break;
		}
		else
		{
			{
				bool sorted = true;
				bool reverse_sorted = true;
				for(E const * it = begin_; it < last_; ++it)
				{
					if(sorted)
					{
						if(compare(it[1], *it))
						{
							sorted = false;
							if(!reverse_sorted)
								break;
						}
					}
					if(reverse_sorted)
					{
						if(compare(*it, it[1]))
						{
							reverse_sorted = false;
							if(!sorted)
								break;
						}
					}
				}
				if(sorted)
					break;
				else if(reverse_sorted)
				{
					for(E * it = begin_, * rit = last_; it < rit; ++it, --rit)
						ds::swap(*it, *rit);
					break;
				}
			}
			{
				E * pivot = begin_;
				E * left  = begin_ + 1;
				E * right = last_;
				while(left < right)
				{
					while(left < right && compare(*left, *pivot))
						++left;
					while(left <= right && !compare(*right, *pivot))
						--right;
					if(left < right)
						ds::swap(*left, *right);
				}
				if(right > pivot)
					ds::swap(*right, *pivot);
				if((end_ - left) > 1)
					sort(left, end_, compare);
				end_ = left;
			}
		}
	}
}

} // namespace ds

#include <iostream>

template <typename T
	, typename = ds::enabled_iterable_const_forward_iterator_t<T>
	>
static constexpr void
print(T && forward_iterable)
{
	auto end_   = ds::end(ds::cref(forward_iterable));
	for(auto it = ds::begin(ds::cref(forward_iterable)); it != end_; ++it)
		std::cout << *it << " ";
	std::cout << std::endl;
}

template <typename T
	, typename E  = ds::enabled_iterable_element_t<T>
	, typename    = ds::enabled_iterable_size_t<T>
	, typename    = ds::enabled_iterable_const_forward_iterator_t<T>
	>
static constexpr E
mean(T && forward_iterable)
{
	ds::remove_cv_t<E> total_ = {};
	auto count_ = ds::size(forward_iterable);
	if(count_ == 0)
		return total_;
	auto end_   = ds::end(ds::cref(forward_iterable));
	for(auto it = ds::begin(ds::cref(forward_iterable)); it != end_; ++it)
		total_ += *it;
	return total_ / count_;
}

template <typename T
	, typename = ds::enabled_iterable_size_t<T>
	, typename = ds::enabled_iterable_forward_iterator_t<T>
	, typename = ds::enabled_iterable_reverse_iterator_t<T>
	>
static constexpr void
reverse(T && forward_and_reverse_iterable)
{
	auto size_ = ds::size(forward_and_reverse_iterable);
	auto it    = ds::begin(forward_and_reverse_iterable);
	auto rit   = ds::rbegin(forward_and_reverse_iterable);
	if(size_ <= 1)
		return;
	size_ /= 2;
	for(; size_-- > 0; ++it, --rit)
		ds::swap(*it, *rit);
}

int main()
{
	{
		// struct uid {};
		// using SA = ds::StackAllocNT<sizeof(int) * 100>;
		// using AI = ds::AllocatorInterface<uid,SA>;
		// SA stack_alloc;
		// AI alloc_interface { stack_alloc };
		// ds::Array<int,AI> data {{1,2,3}};
		float data[] {5,1,9,5,6,0,1,2,5,3,4,3};
		print(data);
		// reverse(data);
		ds::sort(ds::begin(data), ds::end(data));
		print(data);
	}
	// {
	// 	ds::Array<float const> data {{1,2,3,4,5,6,7,8,9}};
	// 	// float const data[] {1,2,3,4,5,6,7,8,9};
	// 	printf("%f\n", mean(data));
	// }
	// return array_test().run_all(reporter_t<array_test>(pptest::normal));
}