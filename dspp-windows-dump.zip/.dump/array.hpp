#pragma once
#ifndef DS_ARRAY_HPP
#define DS_ARRAY_HPP

#include <cstddef>
#include <type_traits>
#include <initializer_list>
#include <exception>

namespace ds {

template <class C
		, typename _size_t   = decltype(std::declval<C>().size())
		, typename _begin_rt = decltype(&*std::declval<C>().begin())
		, typename _end_rt_  = decltype(&*std::declval<C>().end())>
struct array_basic_requirements
{};

template <typename E, template <typename> class C>
struct array_basic_requirements<C<E>,size_t,E *, E *>
{
	using type = void;
};

template <class C>
using array_basic_requirements_t = typename array_basic_requirements<C>::type;

template <typename E>
class array
{
	using array_t = E[];

	union {
		void    * m_block = nullptr;
		array_t * m_array;        };
	size_t        m_size  = 0;

	template <bool = (std::is_destructible<E>::value && !std::is_scalar<E>::value)>
	struct _destructor
	{
		static inline void
		destruct(E (& array_)[], size_t size_) noexcept
		{
			while(size_-- > 0)
				array_[size_].~T();
		}
	};

	template <>
	struct _destructor<false>
	{
		static inline void
		destruct(E (& array_)[], size_t size_) noexcept
		{}
	};

	struct index_out_of_bounds : public std::exception
	{
		char const * 
		what() const noexcept override
		{
			return "index out of bounds";
		}
	};

	static inline void 
	_deallocate(void * block)
	{
		::operator delete(block);
	}

	static void *
	_allocate(size_t size_)
	{
		return ::operator new(size_ * sizeof(E));
	}

	inline void
	_check_index(size_t index) noexcept(false)
	{
		if(index >= m_size)
			throw index_out_of_bounds();
	}

 public:
	~array() noexcept
	{
		this->destroy();
	}

	array() noexcept = default;

	array(size_t size_)
		: m_block { _allocate(size_) }
		, m_size  { m_block ? size_ : 0 }
	{
		if(m_block)
		{
			auto end_ = this->end();
			for(E * it = this->begin(); it != end_; ++it)
				new (it) E();
		}
	}

	template <typename Arg>
	array(size_t size_, Arg && arg)
		: m_block { _allocate(size_) }
		, m_size  { m_block ? size_ : 0 }
	{
		if(m_block)
		{
			auto end_ = this->end();
			for(E * it = this->begin(); it != end_; ++it)
				new (it) E(arg);
		}
	}

	array(array && rhs) noexcept
		: m_block { rhs.m_block }
		, m_size  { rhs.m_size }
	{
		rhs.m_block = nullptr;
		rhs.m_size  = 0;
	}
	
	template <typename T = E>
	array(array<T> const & rhs)
		: m_block { _allocate(rhs.m_size) }
		, m_size  { m_block ? rhs.m_size : 0 }
	{
		if(m_block)
		{
			auto end_ = this->end();
			auto cit  = rhs.begin();
			for(E * it = this->begin(); it != end_; ++it, ++cit)
				new (it) E(*cit);
		}
	}

	template <typename T = E, size_t size_>
	array(T (&& array_)[size_])
		: m_block { _allocate(size_) }
		, m_size  { m_block ? size_ : 0 }
	{
		if(m_block)
		{
			auto end_ = this->end();
			auto cit  = &array_[0];
			for(E * it = this->begin(); it != end_; ++it, ++cit)
				new (it) E(std::move(*cit));
		}
	}

	template <typename T = E, size_t size_>
	array(T const (& array_)[size_])
		: m_block { _allocate(size_) }
		, m_size  { m_block ? size_ : 0 }
	{
		if(m_block)
		{
			auto end_ = this->end();
			auto cit  = &array_[0];
			for(E * it = this->begin(); it != end_; ++it, ++cit)
				new (it) E(*cit);
		}
	}

	template <typename T = E>
	array(std::initializer_list<T> && ilist)
		: m_block { _allocate(ilist.size()) }
		, m_size  { m_block ? ilist.size() : 0 }
	{
		if(m_block)
		{
			auto end_ = this->end();
			auto cit  = ilist.begin();
			for(E * it = this->begin(); it != end_; ++it, ++cit)
				new (it) E(*cit);
		}
	}

	// generic constructor
	// template <class C, typename = decltype(std::declval<C>().size())
	// 	, typename = decltype(std::declval<C>().begin())
	// 	, typename = decltype(std::declval<C>().end())>
	template <class C, typename = array_basic_requirements_t<C>>
	array(C const & rhs)
		: m_block { _allocate(rhs.size()) }
		, m_size  { m_block ? rhs.size() : 0 }
	{
		if(m_block)
		{
			auto end_ = this->end();
			auto cit  = rhs.begin();
			for(E * it = this->begin(); it != end_; ++it, ++cit)
				new (it) E(*cit);
		}
	}

	// concatenating constructor
	template <class C1, class C2
		, typename = decltype(std::declval<C1>().size())
		, typename = decltype(std::declval<C1>().begin())
		, typename = decltype(std::declval<C1>().end())
		, typename = decltype(std::declval<C2>().size())
		, typename = decltype(std::declval<C2>().begin())
		, typename = decltype(std::declval<C2>().end())>
	array(C1 && lhs, C2 && rhs, size_t _size_ = 0)
		: m_block { _allocate((_size_ = lhs.size() + rhs.size()))}
		, m_size  { m_block ? _size_ : 0 }
	{
		if(m_block)
		{
			auto it = this->begin();
			{
				auto lhs_size = lhs.size();
				auto lend_    = lhs.end();
				for(auto lit = lhs.begin(); lit < lend_; ++lit, ++it)
					new ((void*)it) E(*lit);
			}
			{
				auto rhs_size = rhs.size();
				auto rend_    = rhs.end();
				for(auto rit = rhs.begin(); rit < rend_; ++rit, ++it)
					new ((void*)it) E(*rit);
			}
		}
	}

	array &
	operator=(array && rhs) noexcept
	{
		if(&rhs != this)
		{
			this->swap(rhs);
			rhs.destroy();
		}
		return *this;
	}

	array &
	operator=(array const & rhs)
	{
		if(&rhs != this)
		{
			this->~array();
			new ((void*)this) array(rhs);
		}
		return *this;
	}

	void 
	swap(array & rhs) noexcept
	{
		std::swap(m_block, rhs.m_block);
		std::swap(m_size, rhs.m_size);
	}

	void
	destroy() noexcept
	{
		if(m_block)
		{
			_destructor<>::destruct(*m_array, m_size);
			_deallocate(m_block);
			m_block = nullptr;
			m_size  = 0;
		}
	}

	inline E       & operator[](size_t index)       noexcept { return (*m_array)[index]; }
	inline E const & operator[](size_t index) const noexcept { return (*m_array)[index]; }
	
	E & 
	at(size_t index) noexcept(false)
	{
		_check_index(index);
		return (*m_array)[index];
	}

	E const & 
	at(size_t index) const noexcept(false)
	{
		_check_index(index);
		return (*m_array)[index];
	}

	inline array_t const & array_ref() const noexcept { return *m_array; }
	inline array_t       & array_ref()       noexcept { return *m_array; }

	inline size_t size()       noexcept { return m_size; }
	inline size_t size() const noexcept { return m_size; }
	
	inline E       * begin()       noexcept { return &(*m_array)[0]; }
	inline E const * begin() const noexcept { return &(*m_array)[0]; }
	inline E       * end  ()       noexcept { return &(*m_array)[m_size]; }
	inline E const * end  () const noexcept { return &(*m_array)[m_size]; }
	
	inline E       * rbegin()       noexcept { return &(*m_array)[m_size-1]; }
	inline E const * rbegin() const noexcept { return &(*m_array)[m_size-1]; }
	inline E       * rend  ()       noexcept { return &(*m_array)[-1]; }
	inline E const * rend  () const noexcept { return &(*m_array)[-1]; }

	inline bool operator!()       noexcept { return m_block == nullptr; }
	inline bool operator!() const noexcept { return m_block == nullptr; }

	inline explicit operator bool()       noexcept { return m_block != nullptr; }
	inline explicit operator bool() const noexcept { return m_block != nullptr; }

	template <class C, std::enable_if_t<std::is_constructible<C,E *, E *>::value,int> = 0>
	inline explicit operator C() noexcept 
	{
		return { this->begin(), this->end() };
	}
	
	template <class C, std::enable_if_t<std::is_constructible<C,E const *, E const *>::value,int> = 0>
	inline explicit operator C() const noexcept 
	{
		return { this->begin(), this->end() };
	}

	template <class C2
		, typename = decltype(std::declval<C2>().size())
		, typename = decltype(std::declval<C2>().begin())
		, typename = decltype(std::declval<C2>().end())>
	inline array
	operator+(C2 && rhs) const
	{
		return { *this, std::forward<C2>(rhs) };
	}

};


} // namespace ds

#endif // DS_ARRAY_HPP