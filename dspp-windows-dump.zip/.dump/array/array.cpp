#include <iostream>
#include <pptest>
#include <colored_printer>
#include "../counter"
#include <ds/array>
#include <vector>


template class ds::Array<int>; 

Begin_Test(array_test)

	template <typename T>
	struct Sequence 
	{
		T cur; 
		constexpr Sequence(T start_ = {}) : cur { start_ } {}
		constexpr operator T() { return cur++; }
	};

	template <class C, typename T, size_t size_, typename = ds::array_basic_requirements_t<C>>
	static bool
	compare_eq(C const & lhs, T const (& rhs)[size_])
	{
		if(lhs.size() != size_)
			return false;
		for(size_t i = 0; i < size_; ++i)
			if(lhs[i] != rhs[i])
				return false;
		return true;
	}

	Pre_Testcase_Run(array_test)
	{
		Counter::reset();
	}

	Begin_Testcase(array_test, default_constructor_test)
	{
		ds::Array<Counter> array;
		Check_True(!array);
		Check_False(array);
		Check_True(array.size() == 0);
		Check_True(array.begin() == nullptr);
		Check_True(array.end() == nullptr);
	}
	End_Testcase(array_test, default_constructor_test)

	Begin_Testcase(array_test, sized_constructor_test)
	{
		ds::Array<Counter> array(5);
		Check_False(!array);
		Check_True(array.size() == 5);
		Check_True(array.begin() != nullptr);
		Check_True(array.end() != nullptr);
		Check_True(array.rbegin() != nullptr);
		Check_True(array.rend() != nullptr);
		Assert_True(array);
		Check_True(compare_eq(array, {0,0,0,0,0}));
	}
	End_Testcase(array_test, sized_constructor_test)

	Begin_Testcase(array_test, sized_fill_constructor_test)
	{
		ds::Array<Counter> array(5,Sequence<int>());
		Check_True(array);
		Check_False(!array);
		Check_True(array.size() == 5);
		Check_True(array.begin() != nullptr);
		Check_True(array.end() != nullptr);
		Check_True(array.rbegin() != nullptr);
		Check_True(array.rend() != nullptr);
		Check_True(compare_eq(array, {0,1,2,3,4}));
	}
	End_Testcase(array_test, sized_fill_constructor_test)

	Begin_Testcase(array_test, initializer_array_constructor_test)
	{ 
		{
			ds::Array<Counter> array1 { 1, 2, 3, 4 };
			Assert_True(array1);
			Check_True(array1.size() == 4);
			Check_True(Counter::count()  == 4);
			Check_True(Counter::active() == 4);
			Check_True(Counter::no_moves());
			Check_True(Counter::no_copies());
			ds::Array<Counter> array2 = ds::move(array1);
			Check_True(Counter::count()  == 4);
			Check_True(Counter::active() == 4);
			Check_True(Counter::no_moves());
			Check_True(Counter::no_copies());
			Check_True(compare_eq(array2, {1,2,3,4}));
		}
		Check_True(Counter::count() == 4);
		Check_True(Counter::none_active());
		Check_True(Counter::no_moves());
		Check_True(Counter::no_copies());
	}
	End_Testcase(array_test, initializer_array_constructor_test)

	Begin_Testcase(array_test, copy_constructor_test)
	{ 
		{
			ds::Array<Counter> array1 {{ 9,2,3,4 }};
			Assert_True(array1);
			Check_True(array1.size() == 4);
			Check_True(Counter::count()  == 4);
			Check_True(Counter::active() == 4);
			Check_True(Counter::no_moves());
			Check_True(Counter::no_copies());
			Check_True(compare_eq(array1, { 9,2,3,4 }));
			auto begin_ = array1.begin();
			ds::Array<Counter> array2 = array1;
			Assert_True(array1.begin() != array2.begin());
			Assert_True(array1.begin() == begin_);
			Check_True(Counter::count()  == 8);
			Check_True(Counter::active() == 8);
			Check_True(Counter::no_moves());
			Check_True(Counter::copies() == 4);
			Check_True(compare_eq(array1, { 9,2,3,4 }));
			Check_True(compare_eq(array2, { 9,2,3,4 }));
		}
		Check_True(Counter::count() == 8);
		Check_True(Counter::none_active());
		Check_True(Counter::no_moves());
		Check_True(Counter::copies() == 4);
	}
	End_Testcase(array_test, copy_constructor_test)

	Begin_Testcase(array_test, move_constructor_test)
	{ 
		{
			ds::Array<Counter> array1 {{ 1, 2, 3, 4 }};
			Assert_True(array1);
			Check_True(array1.size() == 4);
			Check_True(Counter::count()  == 4);
			Check_True(Counter::active() == 4);
			Check_True(Counter::no_moves());
			Check_True(Counter::no_copies());
			auto begin_ = array1.begin();
			ds::Array<Counter> array2 = ds::move(array1);
			Assert_True(array2.begin()  == begin_);
			Check_True(Counter::count()  == 4);
			Check_True(Counter::active() == 4);
			Check_True(Counter::no_moves());
			Check_True(Counter::no_copies());
		}
		Check_True(Counter::count() == 4);
		Check_True(Counter::none_active());
		Check_True(Counter::no_moves());
		Check_True(Counter::no_copies());
	}
	End_Testcase(array_test, move_constructor_test)

	Begin_Testcase(array_test, vector_int_constructor_test)
	{ 
		{
			using _t = ds::array_basic_requirements_t<std::vector<int>>;
			std::vector<int> vec { 1, 2, 3, 4 };
			ds::Array<Counter> array(vec);
			Assert_True(array);
			Check_True(array.size() == 4);
			Check_True(Counter::count()  == 4);
			Check_True(Counter::active() == 4);
			Check_True(Counter::no_moves());
			Check_True(Counter::no_copies());
		}
		Check_True(Counter::count() == 4);
		Check_True(Counter::none_active());
		Check_True(Counter::no_moves());
		Check_True(Counter::no_copies());
	}
	End_Testcase(array_test, vector_int_constructor_test)

	Begin_Testcase(array_test, vector_tracer_copy_constructor_test)
	{ 
		using _t = ds::array_basic_requirements_t<std::vector<Counter>>;
		std::vector<Counter> vec  = { 1, 2, 3, 4 };
		auto count_  = Counter::count();
		auto active_ = Counter::active();
		auto moves_  = Counter::moves();
		auto copies_ = Counter::copies();
		{
			ds::Array<Counter> array(vec);
			Assert_True(array);
			Check_True(array.size() == 4);
			Check_True(Counter::count()  == 4 + count_);
			Check_True(Counter::active() == 4 + active_);
			Check_True(Counter::moves()  == 0 + moves_);
			Check_True(Counter::copies() == 4 + copies_);
		}
		Check_True(Counter::count()  == 4 + count_);
		Check_True(Counter::active() == 0 + active_);
		Check_True(Counter::moves()  == 0 + moves_);
		Check_True(Counter::copies() == 4 + copies_);
	}
	End_Testcase(array_test, vector_tracer_copy_constructor_test)

	Begin_Testcase(array_test, vector_tracer_move_constructor_test)
	{ 
		using _t = ds::array_basic_requirements_t<std::vector<Counter>>;
		std::vector<Counter> vec  = { 1, 2, 3, 4 };
		auto count_  = Counter::count();
		auto active_ = Counter::active();
		auto moves_  = Counter::moves();
		auto copies_ = Counter::copies();
		{
			ds::Array<Counter> array(ds::move(vec));
			Assert_True(array);
			Check_True(array.size() == 4);
			Check_True(Counter::count()  == 4 + count_);
			Check_True(Counter::active() == 4 + active_);
			Check_True(Counter::moves()  == 4 + moves_);
			Check_True(Counter::copies() == 0 + copies_);
		}
		Check_True(Counter::count()  == 4 + count_);
		Check_True(Counter::active() == 0 + active_);
		Check_True(Counter::moves()  == 4 + moves_);
		Check_True(Counter::copies() == 0 + copies_);
	}
	End_Testcase(array_test, vector_tracer_move_constructor_test)

	Begin_Testcase(array_test, concat_copy_constructor_test)
	{ 
		{
			ds::Array<Counter> const array1 {{ 1, 2, 3, 4 }};
			ds::Array<Counter> const array2 {{ 5, 6, 7 }};
			Assert_True(array1);
			Assert_True(array2);
			Assert_True(compare_eq(array1, { 1, 2, 3, 4 }));
			Assert_True(compare_eq(array2, { 5, 6, 7 }));
			ds::Array<Counter> array3 (array1, array2);
			Assert_True(array3);
			Assert_True(compare_eq(array3, { 1, 2, 3, 4, 5, 6, 7 }));
			Check_True(Counter::count()  == 14);
			Check_True(Counter::active() == 14);
			Check_True(Counter::no_moves());
			Check_True(Counter::copies() == 7);
		}
		Check_True(Counter::count() == 14);
		Check_True(Counter::none_active());
		Check_True(Counter::no_moves());
		Check_True(Counter::copies() == 7);
	}
	End_Testcase(array_test, concat_copy_constructor_test)

	Begin_Testcase(array_test, concat_move_constructor_test)
	{ 
		{
			ds::Array<Counter> array3 (ds::Array<Counter>{{ 1, 2, 3, 4 }}, ds::Array<Counter>{{ 5, 6, 7 }});
			Assert_True(array3);
			Assert_True(compare_eq(array3, { 1, 2, 3, 4, 5, 6, 7 }));
			Check_True(Counter::count()  == 14);
			Check_True(Counter::active() == 7);
			Check_True(Counter::moves() == 7);
			Check_True(Counter::no_copies());
		}
		Check_True(Counter::count() == 14);
		Check_True(Counter::none_active());
		Check_True(Counter::moves()  == 7);
		Check_True(Counter::no_copies());
	}
	End_Testcase(array_test, concat_move_constructor_test)

	Begin_Testcase(array_test, concat_copy_and_move_constructor_test)
	{ 
		{
			ds::Array<Counter> const array1 {{ 1, 2, 3, 4 }};
			ds::Array<Counter> array3 (array1, ds::Array<Counter>{{ 5, 6, 7 }});
			Assert_True(array3);
			Assert_True(compare_eq(array3, { 1, 2, 3, 4, 5, 6, 7 }));
			Check_True(Counter::count()  == 14);
			Check_True(Counter::active() == 11);
			Check_True(Counter::moves()  == 3);
			Check_True(Counter::copies() == 4);
		}
		Check_True(Counter::count()  == 14);
		Check_True(Counter::none_active());
		Check_True(Counter::moves()  == 3);
		Check_True(Counter::copies() == 4);
	}
	End_Testcase(array_test, concat_copy_and_move_constructor_test)

	Begin_Testcase(array_test, concat_move_and_copy_constructor_test)
	{ 
		{
			ds::Array<Counter> const array1 {{ 1, 2, 3, 4 }};
			ds::Array<Counter> array3 (ds::Array<Counter>{{ 5, 6, 7 }}, array1);
			Assert_True(array3);
			Assert_True(compare_eq(array3, { 5, 6, 7, 1, 2, 3, 4 }));
			Check_True(Counter::count()  == 14);
			Check_True(Counter::active() == 11);
			Check_True(Counter::moves()  == 3);
			Check_True(Counter::copies() == 4);
		}
		Check_True(Counter::count()  == 14);
		Check_True(Counter::none_active());
		Check_True(Counter::moves()  == 3);
		Check_True(Counter::copies() == 4);
	}
	End_Testcase(array_test, concat_move_and_copy_constructor_test)

	Begin_Testcase(array_test, move_assignment_operator_test)
	{ 
		{
			ds::Array<Counter> array1 {{ 1, 2, 3, 4 }};
			ds::Array<Counter> array2 {{ 5, 6, 7 }};
			auto begin2_ = array2.begin();
			array1 = ds::move(array2);
			Assert_True(array1);
			Assert_True(array1.begin() == begin2_);
			Assert_True(compare_eq(array1, { 5, 6, 7 }));
			Check_True(Counter::count()  == 7);
			Check_True(Counter::active() == 3);
			Check_True(Counter::no_moves());
			Check_True(Counter::no_copies());
		}
		Check_True(Counter::count()  == 7);
		Check_True(Counter::none_active());
		Check_True(Counter::no_moves());
		Check_True(Counter::no_copies());
	}
	End_Testcase(array_test, move_assignment_operator_test)

	Begin_Testcase(array_test, copy_assignment_operator_test)
	{ 
		{
			ds::Array<Counter> array1 {{ 1, 2, 3, 4 }};
			ds::Array<Counter> array2 {{ 5, 6, 7 }};
			auto begin2_ = array2.begin();
			array1 = array2;
			Assert_True(array1);
			Assert_True(array2.begin() == begin2_);
			Assert_True(compare_eq(array1, { 5, 6, 7 }));
			Check_True(Counter::count()  == 10);
			Check_True(Counter::active() == 6);
			Check_True(Counter::no_moves());
			Check_True(Counter::copies() == 3);
		}
		Check_True(Counter::count()  == 10);
		Check_True(Counter::none_active());
		Check_True(Counter::no_moves());
		Check_True(Counter::copies() == 3);
	}
	End_Testcase(array_test, copy_assignment_operator_test)

	Begin_Testcase(array_test, add_operator_test)
	{ 
		{
			ds::Array<Counter> const array1 {{ 1, 2, 3, 4 }};
			ds::Array<Counter> const array2 {{ 5, 6, 7 }};
			ds::Array<Counter> array3 = array1 + array2;
			Assert_True(array3);
			Assert_True(compare_eq(array3, { 1, 2, 3, 4, 5, 6, 7 }));
			Check_True(Counter::count()  == 14);
			Check_True(Counter::active() == 14);
			Check_True(Counter::no_moves());
			Check_True(Counter::copies() == 7);
		}
		Check_True(Counter::count()  == 14);
		Check_True(Counter::none_active());
		Check_True(Counter::no_moves());
		Check_True(Counter::copies() == 7);
	}
	End_Testcase(array_test, add_operator_test)

	Begin_Testcase(array_test, add_and_assign_operator_test)
	{ 
		{
			ds::Array<Counter> array1 {{ 1, 2, 3, 4 }};
			ds::Array<Counter> array2 {{ 5, 6, 7 }};
			array1 += array2;
			Assert_True(array1);
			Assert_True(compare_eq(array1, { 1, 2, 3, 4, 5, 6, 7 }));
			Check_True(Counter::count()  == 14);
			Check_True(Counter::active() == 10);
			Check_True(Counter::moves()  == 4);
			Check_True(Counter::copies() == 3);
		}
		Check_True(Counter::count()  == 14);
		Check_True(Counter::none_active());
		Check_True(Counter::moves()  == 4);
		Check_True(Counter::copies() == 3);
	}
	End_Testcase(array_test, add_and_assign_operator_test)

	Begin_Testcase(array_test, not_operator_test)
	{ 
		ds::Array<Counter> array;
		Assert_True(!array);
		array = {{ 1, 2, 3, 4 }};
		Assert_False(!array);
	}
	End_Testcase(array_test, not_operator_test)

	Begin_Testcase(array_test, bool_operator_test)
	{ 
		ds::Array<Counter> array;
		Assert_False(array);
		array = {{ 1, 2, 3, 4 }};
		Assert_True(array);
	}
	End_Testcase(array_test, bool_operator_test)

	Begin_Testcase(array_test, type_operator_test)
	{ 
		ds::Array<Counter> array = {{ 1, 2, 3, 4 }};
		Assert_True(array);
		std::vector<Counter> vec = array;
		Assert_False(vec.empty());
		Assert_True(compare_eq(vec, { 1, 2, 3, 4 }));
	}
	End_Testcase(array_test, type_operator_test)

	Begin_Testcase(array_test, array_indexing_empty)
	{
		ds::Array<int> array;
		Assert_Throw(ds::Array<int>::index_out_of_bounds const &, auto v = array.at(0));
	}
	End_Testcase(array_test, array_indexing_empty)

	Begin_Testcase(array_test, array_indexing_out_of_bounds)
	{
		ds::Array<int> array {{ 1, 2, 3 }};
		Assert_Throw(ds::Array<int>::index_out_of_bounds const &, auto v = array.at(4));
	}
	End_Testcase(array_test, array_indexing_out_of_bounds)

	Begin_Testcase_Registration(array_test)
	{
		Register_Testcase(array_test, default_constructor_test)
		Register_Testcase(array_test, sized_constructor_test)
		Register_Testcase(array_test, sized_fill_constructor_test)
		Register_Testcase(array_test, initializer_array_constructor_test)
		Register_Testcase(array_test, copy_constructor_test)
		Register_Testcase(array_test, move_constructor_test)
		Register_Testcase(array_test, vector_int_constructor_test)
		Register_Testcase(array_test, vector_tracer_copy_constructor_test)
		Register_Testcase(array_test, vector_tracer_move_constructor_test)
		Register_Testcase(array_test, concat_copy_constructor_test)
		Register_Testcase(array_test, concat_move_constructor_test)
		Register_Testcase(array_test, concat_copy_and_move_constructor_test)
		Register_Testcase(array_test, concat_move_and_copy_constructor_test)
		Register_Testcase(array_test, move_assignment_operator_test)
		Register_Testcase(array_test, copy_assignment_operator_test)
		Register_Testcase(array_test, add_operator_test)
		Register_Testcase(array_test, add_and_assign_operator_test)
		Register_Testcase(array_test, not_operator_test)
		Register_Testcase(array_test, bool_operator_test)
		Register_Testcase(array_test, type_operator_test)
		Register_Testcase(array_test, array_indexing_empty)
		Register_Testcase(array_test, array_indexing_out_of_bounds)
	}
	End_Testcase_Registration(array_test)
End_Test(array_test)


template <class C> using reporter_t = pptest::colored_printer<C>;

int main()
{
	return array_test().run_all(reporter_t<array_test>(pptest::normal));
}
