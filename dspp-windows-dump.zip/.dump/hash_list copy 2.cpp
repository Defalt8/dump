#include <pptest>
#include <colored_printer>
#include <ds/hash_list>
#include "../counter"

template class ds::HashListIterator<1,Counter>;
template class ds::ConstHashListIterator<1,Counter>;
template class ds::HashList<1,Counter>;

Test(hash_list)
{
	TestInit(hash_list);

	Testcase(test_default_constructible)
	{
		AssertTrue(ds::is_constructible<ds::HashList<1,int>>::value);
	} TestcaseEnd(test_default_constructible);

	Testcase(test_default_construct)
	{
	} TestcaseEnd(test_default_construct);

};

TestRegistry(hash_list)
{
	Register(test_default_constructible)
	Register(test_default_construct)
};

template <class C>
using reporter_t = pptest::colored_printer<C>;

#include <iostream>


#include <ds/list>
#include <ds/array>
#include <ds/hash_map>

template <typename K, typename V>
std::ostream &
operator<<(std::ostream & ost, ds::Entry<K,V> const & entry)
{
	return ost << '(' << entry.key << ": " << entry.value << ')';
}

template <typename T
	, typename = ds::enabled_iterable_const_forward_iterator_t<T>
	>
static constexpr void
print(T && forward_iterable)
{
	auto end_   = ds::end(ds::cref(forward_iterable));
	for(auto it = ds::begin(ds::cref(forward_iterable)); it != end_; ++it)
		std::cout << *it << " ";
	std::cout << std::endl;
}

template <typename T
	, typename E  = ds::enabled_iterable_element_t<T>
	, typename    = ds::enabled_iterable_size_t<T>
	, typename    = ds::enabled_iterable_const_forward_iterator_t<T>
	>
static constexpr E
mean(T && forward_iterable)
{
	ds::remove_cv_t<E> total_ = {};
	auto count_ = ds::size(forward_iterable);
	if(count_ == 0)
		return total_;
	auto end_   = ds::end(ds::cref(forward_iterable));
	for(auto it = ds::begin(ds::cref(forward_iterable)); it != end_; ++it)
		total_ += *it;
	return total_ / count_;
}

template <typename T
	, typename = ds::enabled_iterable_size_t<T>
	, typename = ds::enabled_iterable_forward_iterator_t<T>
	, typename = ds::enabled_iterable_reverse_iterator_t<T>
	>
static constexpr void
reverse(T && forward_and_reverse_iterable)
{
	auto size_ = ds::size(forward_and_reverse_iterable);
	if(size_ > 1)
	{
		auto it  = ds::begin(forward_and_reverse_iterable);
		auto rit = ds::rbegin(forward_and_reverse_iterable);
		size_ /= 2;
		for(; size_-- > 0; ++it, --rit)
			ds::swap(*it, *rit);
	}
}

struct S
{
	static int _si;
	int _i = ++_si;
	int val = _i;
	S(int val_ = 0) : val { val_ } { printf("C%d\n", _i); }
	~S() { printf("D%d\n", _i); }
	S(S && rhs)
		: _i  { rhs._i }
		, val { rhs.val }
	{
		rhs._i = 0;
	}
	S(S const & rhs) = default;

	operator int()       { return val; }
	operator int() const { return val; }
};

int S::_si = 0;

struct C
{
	int i;
	C() = delete;
	C(int i_) : i {i_} {}
	~C() = default;
	operator int()       { return i; }
	operator int() const { return i; }
};

namespace ds {

template <>
struct Hasher<S>
{
	static constexpr size_t hash(S const & s) { return Hasher<int>::hash(s.val); }
	static constexpr size_t hash(int i) { return Hasher<int>::hash(i); }
};

template <>
struct Hasher<C>
{
	static constexpr size_t hash(C const & c) { return Hasher<int>::hash(c.i); }
	static constexpr size_t hash(int i) { return Hasher<int>::hash(i); }
};


} // namespace ds

template class ds::HashList<256,int>;
// template class ds::HashList<256,Entry<char,int>>;

// template <size_t table_size_, typename K, typename V>
// using HashMap = ds::HashList<table_size_,Entry<K,V>>;

// template <size_t table_size_, typename K, typename V>
// using hash_map = ds::HashList<table_size_,Entry<K,V>>;

int main()
{
	// printf("%zu\n", sizeof(ds::list<2,char>));
	// printf("%zu\n", sizeof(HashMap<128,char,int>));
	// if(0)
	// {
	// 	using hash_map = ds::HashMap<128,int,char>;
	// 	hash_map map;
	// 	map[1] = 'a';
	// 	map.set(2, 'b');
	// 	map.set(3, 'c'); 
	// 	map.set(3, 'd'); 
	// 	map.set_noreplace(2, 'e'); 
	// 	map.set_noreplace(4, 'f'); 
	// 	print(map);
	// 	std::cout << *map.get(2) << std::endl;
	// 	std::cout << *map.get(3) << std::endl;
	// 	// printf("%d\n", map.position_of(4)->value.i);
	// }
	// if(0)
	// {
	// 	using hash_map = ds::HashMap<128,int,char>;
	// 	hash_map map;
	// 	map[1] = 'a';
	// 	map[2] = 'b';
	// 	map[3] = 'c';
	// 	print(map);
	// 	std::cout << *map.get(2) << std::endl;
	// 	std::cout << *map.get(3) << std::endl;
	// 	// printf("%d\n", map.position_of(4)->value.i);
	// }
	// if(0)
	// {
	// 	using hash_map = ds::HashMap<128,char,int>;
	// 	char string[] = "hello world!";
	// 	hash_map map(ds::begin(string), ds::end(string), ds::hash_map_param::Replace);
	// 	print(map);
	// }
	// if(0)
	// {
	// 	using hash_map = ds::HashMap<128,char,int>;
	// 	hash_map map;
	// 	map.set('a', 1);
	// 	map.set('b', 2);
	// 	print(map);
	// 	map.set('a', 0);
	// 	print(map);
	// 	map['a'] = 1;
	// 	print(map);
	// 	map.remove({'a', 0});
	// 	print(map);
	// }
	if(0)
	{
		using hash_list = ds::HashList<128,C>;
		hash_list list;
		list.emplace(1);
		list.emplace(2);
		list.emplace(3);
		print(list);
	}
	if(0)
	{
		auto array = ds::array<C>(3, 0);
		// for(auto & e : array)
		// 	ds::construct_at<C>(&e,0);
	}
	if(0)
	{
		using hash_list = ds::HashList<128,char>;
		char string_[] = "hello world!";
		ds::List<2,char> string { ds::begin(string_), ds::end(string_) };
		hash_list list(ds::begin(string), ds::end(string), ds::hash_list_param::Unique);
		print(list);
	}
	if(0)
	{
		using hash_list = ds::HashList<128,char>;
		hash_list list;
		auto string = "hello world!";
		for(auto it = &string[0]; *it != '\0'; ++it)
			list.insert_unique(*it);
		print(list);
		printf("%zu\n", list.size());
	}
	// if(0)
	{
		using hash_list = ds::HashList<4,S>;
		hash_list list ({1,2,3,4});
		print(list);
		list.insert(5);
		print(list);
		list.insert(6);
		list.insert(2);
		// list.insert_unique(2);
		// list.insert_unique_replace(2);
		print(list);
	}
	// if(0)
	// {
	// 	struct LID {};
	// 	constexpr size_t usage_ = ds::usage_s<ds::List<1,int>,5>::value;
	// 	using LFA = ds::LocalForwardAllocator<ds::usage_s<ds::List<1,int>,5>::value>;
	// 	using ALI = ds::AllocatorInterface<LID,LFA>;
	// 	LFA local_alloc;
	// 	ALI alloc_interface { local_alloc };
	// 	ds::List<1,int,ALI> i({1,2,3,4,5});
	// 	int _ = 9;
	// }
	// return hash_list().run_all(reporter_t<hash_list>(pptest::normal));
}
