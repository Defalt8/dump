#include <pptest>
#include <colored_printer>
#include <ds/hash_list>
#include "../counter"

template struct ds::ListNode<1,Counter>;
template class ds::ListIterator<1,Counter>;
template class ds::ConstListIterator<1,Counter>;
template class ds::List<1,Counter>;

Test(hash_list)
{
	TestInit(hash_list);

	Testcase(test_default_constructible)
	{
		AssertTrue(ds::is_constructible<ds::HashList<1,int>>::value);
	} TestcaseEnd(test_default_constructible);

	Testcase(test_default_construct)
	{
	} TestcaseEnd(test_default_construct);

};

TestRegistry(hash_list)
{
	Register(test_default_constructible)
	Register(test_default_construct)
};

template <class C>
using reporter_t = pptest::colored_printer<C>;

#include <iostream>

template <typename T
	, typename = ds::enabled_iterable_const_forward_iterator_t<T>
	>
static constexpr void
print(T && forward_iterable)
{
	auto end_   = ds::end(ds::cref(forward_iterable));
	for(auto it = ds::begin(ds::cref(forward_iterable)); it != end_; ++it)
		std::cout << *it << " ";
	std::cout << std::endl;
}

template <typename T
	, typename E  = ds::enabled_iterable_element_t<T>
	, typename    = ds::enabled_iterable_size_t<T>
	, typename    = ds::enabled_iterable_const_forward_iterator_t<T>
	>
static constexpr E
mean(T && forward_iterable)
{
	ds::remove_cv_t<E> total_ = {};
	auto count_ = ds::size(forward_iterable);
	if(count_ == 0)
		return total_;
	auto end_   = ds::end(ds::cref(forward_iterable));
	for(auto it = ds::begin(ds::cref(forward_iterable)); it != end_; ++it)
		total_ += *it;
	return total_ / count_;
}

template <typename T
	, typename = ds::enabled_iterable_size_t<T>
	, typename = ds::enabled_iterable_forward_iterator_t<T>
	, typename = ds::enabled_iterable_reverse_iterator_t<T>
	>
static constexpr void
reverse(T && forward_and_reverse_iterable)
{
	auto size_ = ds::size(forward_and_reverse_iterable);
	if(size_ > 1)
	{
		auto it  = ds::begin(forward_and_reverse_iterable);
		auto rit = ds::rbegin(forward_and_reverse_iterable);
		size_ /= 2;
		for(; size_-- > 0; ++it, --rit)
			ds::swap(*it, *rit);
	}
}

struct S
{
	static int _si;
	int _i = ++_si;
	int val = _i;
	S(int val_ = 0) : val { val_ } { printf("C%d\n", _i); }
	~S() { printf("D%d\n", _i); }
	S(S && rhs)
		: _i  { rhs._i }
		, val { rhs.val }
	{
		rhs._i = 0;
	}
	S(S const & rhs) = default;

	operator int()       { return val; }
	operator int() const { return val; }
};

int S::_si = 0;

struct C
{
	int i;
	C() = delete;
	C(int i_) : i {i_} {}
	~C() = default;
	operator int()       { return i; }
	operator int() const { return i; }
};

template <typename K, typename V>
struct Entry
{
	K key   {};
	V value {};

	Entry() = default;
	Entry(Entry &&) = default;
	Entry(Entry const &) = default;
	Entry & operator=(Entry &&) = default;
	Entry & operator=(Entry const &) = default;

	template <typename K_ = K, ds::enable_if_t<ds::is_constructible<K,K_>::value,int> = 0>
	Entry(K_ && key_)
		: key   { ds::forward<K_>(key_) }
	{}

	template <typename K_ = K, typename V_ = V
			, ds::enable_if_t<ds::is_constructible<K,K_>::value,int> = 0
			, ds::enable_if_t<ds::is_constructible<V,V_>::value,int> = 0>
	Entry(K_ && key_, V_ && value_)
		: key   { ds::forward<K_>(key_) }
		, value { ds::forward<V_>(value_) }
	{}

	inline bool 
	operator==(Entry const & rhs) const noexcept
	{ return key == rhs.key && value == rhs.value; }

	inline bool 
	operator==(K const & key_) const noexcept
	{ return key == key_; }

};

template <typename K, typename V>
std::ostream &
operator<<(std::ostream & ost, Entry<K,V> const & entry)
{
	return ost << '(' << entry.key << ": " << entry.value << ')';
}

namespace std {

template <>
struct hash<S>
{
	inline size_t operator()(S const & s) { return hash<int>()(s.val); }
	inline size_t operator()(int i) { return hash<int>()(i); }
};

template <>
struct hash<C>
{
	inline size_t operator()(C const & c) { return hash<int>()(c.i); }
	inline size_t operator()(int i) { return hash<int>()(i); }
};

template <typename K, typename V>
struct hash<Entry<K,V>>
{
	inline size_t operator()(Entry<K,V> const & s) { return hash<K>()(s.key); }
	inline size_t operator()(K const & key) { return hash<K>()(key); }
};


} // namespace std

template class ds::HashList<256,int>;
template class ds::HashList<256,Entry<char,int>>;

template <size_t table_size_, typename K, typename V>
using HashMap = ds::HashList<table_size_,Entry<K,V>>;

template <size_t table_size_, typename K, typename V>
using hash_map = ds::HashList<table_size_,Entry<K,V>>;

#include <ds/list>
#include <ds/array>

int main()
{
	// printf("%zu\n", sizeof(ds::list<2,char>));
	// printf("%zu\n", sizeof(HashMap<128,char,int>));
	// if(0)
	{
		using hash_list = ds::HashList<128,C>;
		hash_list list;
		list.emplace();
		list.emplace();
		list.emplace();
		print(list);
	}
	if(0)
	{
		auto array = ds::array<C>(3, 0);
		// for(auto & e : array)
		// 	ds::construct_at<C>(&e,0);
	}
	if(0)
	{
		using hash_list = ds::HashList<128,char>;
		char string_[] = "hello world!";
		ds::List<2,char> string { ds::begin(string_), ds::end(string_) };
		hash_list list(ds::begin(string), ds::end(string), ds::hash_list_param::Unique);
		print(list);
	}
	if(0)
	{
		using hash_list = HashMap<128,char,int>;
		char string[] = "hello world!";
		hash_list list(ds::begin(string), ds::end(string), ds::hash_list_param::Replace);
		print(list);
	}
	if(0)
	{
		using hash_list = HashMap<128,char,int>;
		hash_list list;
		list.insert_unique('a')->value = 1;
		list.insert_unique('b')->value = 2;
		print(list);
		list.insert_unique('a')->value = 0;
		print(list);
		list.insert('a')->value = 1;
		print(list);
		list.remove({'a', 0});
		print(list);
	}
	if(0)
	{
		using hash_list = ds::HashList<128,char>;
		hash_list list;
		auto string = "hello world!";
		for(auto it = &string[0]; *it != '\0'; ++it)
			list.insert_unique(*it);
		print(list);
		printf("%zu\n", list.size());
	}
	if(0)
	{
		using hash_list = ds::HashList<4,S>;
		hash_list list ({1,2,3,4});
		print(list);
		list.insert(5);
		print(list);
		list.insert(6);
		list.insert(2);
		// list.insert_unique(2);
		// list.insert_unique_replace(2);
		print(list);
	}
	// if(0)
	// {
	// 	struct LID {};
	// 	constexpr size_t usage_ = ds::usage_s<ds::List<1,int>,5>::value;
	// 	using LFA = ds::LocalForwardAllocator<ds::usage_s<ds::List<1,int>,5>::value>;
	// 	using ALI = ds::AllocatorInterface<LID,LFA>;
	// 	LFA local_alloc;
	// 	ALI alloc_interface { local_alloc };
	// 	ds::List<1,int,ALI> i({1,2,3,4,5});
	// 	int _ = 9;
	// }
	// return hash_list().run_all(reporter_t<hash_list>(pptest::normal));
}
