
// #include <windows.h>
#include <ds/all>

ds::string_stream<> sst(1024);


struct vec3
{
	union {
		float values[3]{};
		struct {
			float x, y, z;
		};
	};

	constexpr vec3(float x, float y, float z)
		: values { x, y, z }
	{}
};

static_assert(offsetof(vec3, values[0]) == offsetof(vec3, x), "!-_-!");
static_assert(offsetof(vec3, values[1]) == offsetof(vec3, y), "!-_-!");
static_assert(offsetof(vec3, values[2]) == offsetof(vec3, z), "!-_-!");


template <class OST>
static OST &
operator<<(OST & ost, vec3 const & rhs)
{
	return ost << "<" << rhs.values[0] << ", " << rhs.values[1] << ", " << rhs.values[2] << ">";
}


int main()
{
	vec3 vec = {1,2,3};
	vec.x = 5;
	sst << vec << ds::endl;
}
