
// #include <windows.h>
#include <ds/all>

ds::string_stream<> sst(1024);


template <typename T>
struct Vec3
{
	union {
		T values[3]{};
		struct {
			T x, y, z;
		};
	};

	constexpr Vec3() = default;
	constexpr Vec3(Vec3 &&) = default;
	constexpr Vec3(Vec3 const &) = default;
	Vec3 & operator=(Vec3 &&) = default;
	Vec3 & operator=(Vec3 const &) = default;

	constexpr Vec3(T x_, T y_, T z_)
		: values { x_, y_, z_ }
	{}

	template <typename U = T>
	Vec3 &
	operator+=(Vec3<U> const & rhs)
	{
		x += rhs.x;
		y += rhs.y;
		z += rhs.z;
		return *this;
	}

	template <typename U = T>
	Vec3 &
	operator-=(Vec3<U> const & rhs)
	{
		x -= rhs.x;
		y -= rhs.y;
		z -= rhs.z;
		return *this;
	}

	template <typename U = T>
	Vec3 &
	operator*=(Vec3<U> const & rhs)
	{
		x *= rhs.x;
		y *= rhs.y;
		z *= rhs.z;
		return *this;
	}

	template <typename U = T>
	Vec3 &
	operator/=(Vec3<U> const & rhs)
	{
		x /= rhs.x;
		y /= rhs.y;
		z /= rhs.z;
		return *this;
	}

	template <typename U = T>
	Vec3
	operator+(Vec3<U> const & rhs) const
	{
		return { 
			  x + rhs.x
			, y + rhs.y
			, z + rhs.z 
		};
	}

	template <typename U = T>
	Vec3
	operator-(Vec3<U> const & rhs) const
	{
		return { 
			  x - rhs.x
			, y - rhs.y
			, z - rhs.z 
		};
	}

	template <typename U = T>
	Vec3
	operator*(Vec3<U> const & rhs) const
	{
		return { 
			  x * rhs.x
			, y * rhs.y
			, z * rhs.z 
		};
	}

	template <typename U = T>
	Vec3
	operator/(Vec3<U> const & rhs) const
	{
		return { 
			  x / rhs.x
			, y / rhs.y
			, z / rhs.z 
		};
	}

};


template <typename T> using vec3 = Vec3<T>;
using Vec3f = Vec3<float>;
using vec3f = Vec3<float>;
using Vec3d = Vec3<double>;
using vec3d = Vec3<double>;
using Vec3i = Vec3<int>;
using vec3i = Vec3<int>;
using Vec3u = Vec3<unsigned int>;
using vec3u = Vec3<unsigned int>;

static_assert(offsetof(Vec3f, values[0]) == offsetof(Vec3f, x), "!-_-!");
static_assert(offsetof(Vec3f, values[1]) == offsetof(Vec3f, y), "!-_-!");
static_assert(offsetof(Vec3f, values[2]) == offsetof(Vec3f, z), "!-_-!");


template <class OST, typename T>
static OST &
operator<<(OST & ost, Vec3<T> const & rhs)
{
	return ost << "[" << rhs.values[0] << ", " << rhs.values[1] << ", " << rhs.values[2] << "]";
}

struct Foo
{
	int val = 0;
	int const cval = 0;
	void bar(int v)
	{
		sst << "Foo::bar(int): " << v << ds::endl;
	}
	void bar(int v) const
	{
		sst << "Foo::bar(int) const: " << v << ds::endl;
	}

	void cbar(int v) const
	{
		sst << "Foo::cbar(int) const: " << v << ds::endl;
	}
};

int main()
{
	// Foo foo;
	// auto mbar  = ds::callable<void(int)>(foo, &Foo::bar);
	// auto mcbar = ds::callable<void(int)>(ds::cref(foo), &Foo::bar);
	// auto cmbar = ds::callable<void(int)>(foo, &Foo::cbar);
	// auto cmcbar = ds::callable<void(int)>(ds::cref(foo), &Foo::cbar);
	// mbar(1);
	// mcbar(2);
	// cmbar(3);
	// cmcbar(4);
	// sst << ds::is_same<decltype(&Foo::bar),void(Foo::*)(int)>::value << ds::endl;
	// sst << ds::is_same<ds::remove_cv_t<decltype(&Foo::bar)>,void(Foo::*)(int)>::value << ds::endl;
	// sst << ds::is_same<ds::remove_cv_t<decltype(&Foo::bar) const>,void(Foo::*)(int)>::value << ds::endl;
	// sst << ds::is_same<ds::remove_cv_t<decltype(&Foo::cbar)>,void(Foo::*)(int) const>::value << ds::endl;
	// sst << ds::is_same<ds::remove_cv_t<decltype(&Foo::cbar) const>,void(Foo::*)(int) const>::value << ds::endl;
	// sst << ds::is_member_function_pointer<decltype(&Foo::bar)>::value << ds::endl;
	// sst << ds::is_member_function_pointer<decltype(&Foo::bar) const>::value << ds::endl;
	// sst << ds::is_member_function_pointer<decltype(&Foo::cbar)>::value << ds::endl;
	// sst << ds::is_member_function_pointer<decltype(&Foo::cbar) const>::value << ds::endl;
	// sst << ds::is_member_object_pointer<decltype(&Foo::bar)>::value << ds::endl;
	// sst << ds::is_member_object_pointer<decltype(&Foo::bar) const>::value << ds::endl;
	// sst << ds::is_member_object_pointer<decltype(&Foo::cbar)>::value << ds::endl;
	// sst << ds::is_member_object_pointer<decltype(&Foo::cbar) const>::value << ds::endl;

	// sst << ds::is_member_function_pointer<decltype(&Foo::val)>::value << ds::endl;
	// sst << ds::is_member_function_pointer<decltype(&Foo::val) const>::value << ds::endl;
	// sst << ds::is_member_function_pointer<decltype(&Foo::cval)>::value << ds::endl;
	// sst << ds::is_member_function_pointer<decltype(&Foo::cval) const>::value << ds::endl;
	// sst << ds::is_member_object_pointer<decltype(&Foo::val)>::value << ds::endl;
	// sst << ds::is_member_object_pointer<decltype(&Foo::val) const>::value << ds::endl;
	// sst << ds::is_member_object_pointer<decltype(&Foo::cval)>::value << ds::endl;
	// sst << ds::is_member_object_pointer<decltype(&Foo::cval) const>::value << ds::endl;
	// Foo foo;
	// Foo const cfoo;
	// auto cmfoo = ds::_::_callable_s<decltype(&Foo::bar)>(foo, &Foo::bar);
	// auto ccmfoo = ds::_::_callable_s<decltype(&Foo::bar) const>(cfoo, &Foo::bar);
	// cmfoo(1);
	// cmfoo(2);
	// cmfoo(3);
	// ccmfoo(4);
	// ccmfoo(5);
	// ccmfoo(6);

	// vec3f vec = {1,2,3};
	// vec.x = 5;
	// sst << vec << ds::endl;
	// sst << (vec + vec3f{1,2,3}) << ds::endl;
}
