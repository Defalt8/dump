
// #include <windows.h>
#include <ds/all>

ds::string_stream<> sst(1024);


template <typename T>
struct Vec3
{
	union {
		T values[3]{};
		struct {
			T x, y, z;
		};
	};

	constexpr Vec3() = default;
	constexpr Vec3(Vec3 &&) = default;
	constexpr Vec3(Vec3 const &) = default;
	Vec3 & operator=(Vec3 &&) = default;
	Vec3 & operator=(Vec3 const &) = default;

	constexpr Vec3(T x_, T y_, T z_)
		: values { x_, y_, z_ }
	{}

	template <typename U = T>
	Vec3 &
	operator+=(Vec3<U> const & rhs)
	{
		x += rhs.x;
		y += rhs.y;
		z += rhs.z;
		return *this;
	}

	template <typename U = T>
	Vec3 &
	operator-=(Vec3<U> const & rhs)
	{
		x -= rhs.x;
		y -= rhs.y;
		z -= rhs.z;
		return *this;
	}

	template <typename U = T>
	Vec3 &
	operator*=(Vec3<U> const & rhs)
	{
		x *= rhs.x;
		y *= rhs.y;
		z *= rhs.z;
		return *this;
	}

	template <typename U = T>
	Vec3 &
	operator/=(Vec3<U> const & rhs)
	{
		x /= rhs.x;
		y /= rhs.y;
		z /= rhs.z;
		return *this;
	}

	template <typename U = T>
	Vec3
	operator+(Vec3<U> const & rhs) const
	{
		return { 
			  x + rhs.x
			, y + rhs.y
			, z + rhs.z 
		};
	}

	template <typename U = T>
	Vec3
	operator-(Vec3<U> const & rhs) const
	{
		return { 
			  x - rhs.x
			, y - rhs.y
			, z - rhs.z 
		};
	}

	template <typename U = T>
	Vec3
	operator*(Vec3<U> const & rhs) const
	{
		return { 
			  x * rhs.x
			, y * rhs.y
			, z * rhs.z 
		};
	}

	template <typename U = T>
	Vec3
	operator/(Vec3<U> const & rhs) const
	{
		return { 
			  x / rhs.x
			, y / rhs.y
			, z / rhs.z 
		};
	}

};


template <typename T> using vec3 = Vec3<T>;
using Vec3f = Vec3<float>;
using vec3f = Vec3<float>;
using Vec3d = Vec3<double>;
using vec3d = Vec3<double>;
using Vec3i = Vec3<int>;
using vec3i = Vec3<int>;
using Vec3u = Vec3<unsigned int>;
using vec3u = Vec3<unsigned int>;

static_assert(offsetof(Vec3f, values[0]) == offsetof(Vec3f, x), "!-_-!");
static_assert(offsetof(Vec3f, values[1]) == offsetof(Vec3f, y), "!-_-!");
static_assert(offsetof(Vec3f, values[2]) == offsetof(Vec3f, z), "!-_-!");


template <class OST, typename T>
static OST &
operator<<(OST & ost, Vec3<T> const & rhs)
{
	return ost << "[" << rhs.values[0] << ", " << rhs.values[1] << ", " << rhs.values[2] << "]";
}

struct Foo
{
	int val = 0;
	int const cval = 0;
	void bar(int v)
	{
		sst << "Foo::bar(int): " << v << ds::endl;
	}
	void bar(int v) const
	{
		sst << "Foo::bar(int) const: " << v << ds::endl;
	}

	void cbar(int v) const
	{
		sst << "Foo::cbar(int) const: " << v << ds::endl;
	}
};

struct C
{
	int val = 0;
	C(int val_)
		: val { val_ }
	{
		sst << "C(int)" << ds::endl;
	}
	C()
	{
		sst << "C()" << ds::endl;
	}
	C(C &&)
	{
		sst << "C(C&&)" << ds::endl;
	}
	C(C const &)
	{
		sst << "C(C const &)" << ds::endl;
	}
	~C()
	{
		sst << "~C()" << ds::endl;
	}
	
	void operator()(int v)
	{
		sst << "C()(int): " << v << " " << val << ds::endl;
	}

	void operator()(int v) const
	{
		sst << "C()(int) const: " << v << " " << val << ds::endl;
	}
};

void clunk(int v)
{
	sst << "clunk(int): " << v << ds::endl;
}

int main()
{
	// ds::callable<void(int)> f = [&](int v) { sst << "lambda: " << v << ds::endl; };
	// ds::callable<void(int)> f = C();
	ds::callable<void(int)> f = ds::make<C>();
	f(0);
	f = [&](int v) { sst << "lambda2: " << v << ds::endl; };
	f(1);
	f = clunk;
	f(2);
	Foo foo;
	f = { foo, &Foo::bar };
	f(3);
	f = { ds::cref(foo), &Foo::bar };
	f(4);
	f = { foo, &Foo::cbar };
	f(5);
	f = { ds::cref(foo), &Foo::cbar };
	f(6);
	f = { Foo(), &Foo::cbar };
	f(7);
	// auto _f = ds::callable<void(int)>(ds::make<Foo>(), &Foo::bar, 5);
	f = { ds::make<C>(), &C::operator(), 5 };
	// auto c = ds::_::_callable_s<decltype(&C::operator()),C>(&C::operator());
	f(8);
	f = { ds::make<C const>(), &C::operator(), 5 };
	f(9);

}
