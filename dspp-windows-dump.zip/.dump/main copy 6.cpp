#include <ds/all>

ds::string_stream<> sst(4096);

template <typename T>
static void
plot_distribution(ds::array<T> const & data, T min_, T max_)
{
	size_t _size = size_t(max_ - min_) + 1;
	ds::array<size_t> _distribution(_size);
	size_t max_count = 0;
	for(auto const & e : data)
	{
		size_t i = size_t(e - min_);
		++_distribution.at(i);
		if(_distribution[i] > max_count)
			max_count = _distribution[i];
	}
	auto _maxp = size_t(log10(_distribution.size()));
	for(size_t i = 0; i < _distribution.size(); ++i)
	{
		// printf("%3zu ", i);
		auto _p = _maxp - (i == 0 ? 0 : size_t(log10(i)));
		for(size_t k = 0; k < _p; ++k)
			sst << ' ';
		sst << i << ' ';
		size_t max_l = _distribution[i] * 25 / max_count;
		for(size_t j = 0; j < max_l; ++j)
			sst << '*';
		sst << '\n';
	}
	sst << max_count << ds::endl;
}


int main()
{
	// using T = int;
	// auto choices = ds::make_fixed<ds::string_view>("eat", "sleep", "do something else", "work a little", "read something");
	// auto r = ds::random<T>(T(time(0)));
	// for(int k = 0; k < 10; ++k)
	// {
	// 	auto i = r.next_range(0, choices.size());
	// 	sst << choices[i] << ds::endl;
	// }
}
