#include <ds/all>
#include <algorithm>
#include "test/benchmark"

ds::string_stream<> sst(4096);

int main()
{
	// if(0)
	{
		using t = int;
		size_t size_ = 10000000;
		auto data_ = ds::array<t>(size_, ds::random_sequence<t>(t(time(0))));
		benchmark::delay(.1);
		for(int i = 0; i < 2; ++i)
		{
			auto data = ds::clone(data_);
			benchmark::rep_test("std sort", [&]()
			{
				std::sort(data.begin(), data.end(), ds::less<t>());
			});
		}
		benchmark::delay(.1);
		for(int i = 0; i < 2; ++i)
		{
			auto data = ds::clone(data_);
			benchmark::rep_test("ds sort", [&]()
			{
				ds::sort(data.begin(), data.end());
			});
		}
	}
	// using T = int;
	// auto choices = ds::make_fixed<ds::string_view>("eat", "sleep", "do something else", "work a little", "read something");
	// auto r = ds::random<T>(T(time(0)));
	// for(int k = 0; k < 10; ++k)
	// {
	// 	auto i = r.next_range(0, choices.size());
	// 	sst << choices[i] << ds::endl;
	// }
}
