#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <ds/all>

ds::string_stream<> sst(1024);

enum class Direction
{
    Unknown,
    Left,
    Right,
    Up,
    Down,
};
 
constexpr char const *
enum_direction (Direction direction)
{
    switch(direction)
    {
        case Direction::Left:   return "Left";
        case Direction::Right:  return "Right";
        case Direction::Up:     return "Up";
        case Direction::Down:   return "Down";
        case Direction::Unknown:
        default:                return "Unknown";
    }
};
 
class KeyState
{
    int  m_key_code   {};
    bool m_last_state {};
 
 public:
    KeyState (int key_code)
        : m_key_code { key_code }
    {}
 
    bool is_down ()
    {
        return 0x8000 & GetAsyncKeyState(m_key_code);;
    }
 
    bool is_pressed ()
    {
        bool is_down = 0x8000 & GetAsyncKeyState(m_key_code);
        bool pressed = false;
        if(is_down)
        {
            if(!m_last_state)
            {
                pressed = true;
                m_last_state = true;
            }
        }
        else
            m_last_state = false;
        return pressed;
    }
};
 
int main()
{
    Direction direction      = Direction::Unknown;
    Direction last_direction = direction;
    KeyState key_left  { VK_LEFT };
    KeyState key_right { VK_RIGHT };
    KeyState key_up    { VK_UP };
    KeyState key_down  { VK_DOWN };
 
    while(1)
    {
        if(key_left.is_pressed())
            direction = Direction::Left;
        else if(key_right.is_pressed())
            direction = Direction::Right;
        if(key_up.is_pressed())
            direction = Direction::Up;
        else if(key_down.is_pressed())
            direction = Direction::Down;
        
        if(last_direction != direction) // change in direction
        {
            sst << enum_direction(direction) << ds::endl;
            last_direction = direction;
        }
    }
}