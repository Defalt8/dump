
// #include <windows.h>
#include <ds/all>

ds::string_stream<> sst(1024);

template <typename R, typename... Args>
class icallable
{
 public:
	virtual R operator()(Args ... args) = 0;// { return {}; }

};

template <typename...>
class callable_s
{};

template <class F, typename R, typename... Args>
class callable_s<R(Args...),F &> : public icallable<R,Args...>
{
	using callable_t = F;
	callable_t * _callable;

 public:
	callable_s(callable_t & callable_)
		: _callable { *callable_ }
	{}

	R operator()(Args ... args) override { return (*_callable)(args...); }
};

template <typename R, typename... Args>
class callable_s<R(Args...),R(*)(Args...)> : public icallable<R,Args...>
{
	using callable_t = R (*)(Args...);
	callable_t _callable = nullptr;

 public:
	callable_s(callable_t callable_)
		: _callable { callable_ }
	{}
	
	R operator()(Args ... args) override { return _callable(args...); }
};

template <typename F>
class callable
{};

template <typename R, typename... Args>
class callable<R(Args...)> : public icallable<R,Args...>
{
	ds::unique<icallable<R,Args...>> _icallable;

 public:
	// template <class F
	// 		, typename C = ds::conditional_t<ds::is_constructible<callable_s<R(Args..),R(*)(Args...)>,F>::value
	// 			, callable_s<R(Args..),R(*)(Args...)>
	// 			, callable_s<R(Args..),F &>
	// 		>
	// 	>
	// callable(F && callable_)
	// 	: _callable { ds::make<C>(), callable_ }
	// {}
	
	template <typename L>
	callable(L & lambda)
		: _callable { ds::make<callable_s<R(Args..),L &>>(), lambda }
	{}
	
	callable(R(*callable_)(Args...))
		: _callable { ds::make<callable_s<R(Args..),R(*)(Args...)>>(), callable_ }
	{}
	
	R operator()(Args ... args) override { return _icallable(args...); }
};


// template <class F>
// static callable<F>
// make_callable(F && callable)
// {
// 	return { ds::forward<F>(callable) };
// }


// void ffoo(void (*func)(int))
void ffoo(callable<void(int)> icallable_)
{
	icallable_(5);
}

void foo(int v)
{
	sst << v << ds::endl;
}

int main()
{
	using func_t = void(*)(int);
	// func_t f = make_callable(foo);
	// auto f = make_callable(foo);
	// f(5);
	// ffoo(make_callable(foo));
	// ffoo([&](int v){ sst << v << ds::endl; });
	// foo([&](int v){ sst << v << ds::endl; });
}
