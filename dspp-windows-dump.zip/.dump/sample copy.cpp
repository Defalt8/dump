#include <type_traits>
#include <pptest>
#include <colored_printer>
#include <ds/fixed>
#include <ds/traits/iterator>
#include "../counter"

Begin_Test(fixed_test)

	template <typename T>
	struct Sequence 
	{
		T cur; 
		constexpr Sequence(T start_ = {}) : cur { start_ } {}
		constexpr operator T() { return cur++; }
	};

	template <class C, typename E, size_t size_>
	static bool
	compare_eq(C const & iterable, E const (& rhs)[size_])
	{
		if(ds::size(iterable) != size_)
			return false;
		auto it = ds::begin(iterable);
		for(size_t i = 0; i < size_; ++i, ++it)
			if(*it != rhs[i])
				return false;
		return true;
	}

	Pre_Testcase_Run(fixed_test)
	{
		Counter::reset();
	}

	Begin_Testcase(fixed_test, test_default_constructor)
	{
	}
	End_Testcase(fixed_test, test_default_constructor)

	template <typename T
		, typename E   = typename ds::traits::iterator<T>::element_t
		, typename CIt = typename ds::traits::iterator<T>::const_forward_iterator_t>
	static E
	accumulate(T const & const_forward_iterable)
	{
		E total_ = {};
		CIt begin_ = ds::begin(const_forward_iterable);
		CIt end_   = ds::end(const_forward_iterable);
		for(CIt it = begin_; it != end_; ++it)
			total_ += *it;
		return total_;
	}

	Begin_Testcase(fixed_test, test_iterator_traits_in_function_template_test)
	{
		constexpr size_t size_ = 5;
		ds::Fixed<int,size_> fixed_ = {1,2,3,4,5};
		auto total_ = accumulate(fixed_);
		Assert_True(std::is_same<decltype(total_),int>::value);
		Assert_EQ(total_, 15);
	}
	End_Testcase(fixed_test, test_iterator_traits_in_function_template_test)

	Begin_Testcase_Registration(fixed_test)
	{
		Register_Testcase(fixed_test, test_default_constructor)
		Register_Testcase(fixed_test, test_iterator_traits_in_function_template_test)
	}
	End_Testcase_Registration(fixed_test)
End_Test(fixed_test)


template <class C> using reporter_t = pptest::colored_printer<C>; 

int main()
{
	return fixed_test().run_all(reporter_t<fixed_test>(pptest::normal));
}