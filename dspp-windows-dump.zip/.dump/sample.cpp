#include <iostream>
#include "test"
#include "tracer"

using cstring_t = char const *;

struct test_case;

template <class C>
struct test
{
	static std::vector<test_case *> & 
	_test_cases()
	{
		static thread_local std::vector<test_case *> test_cases_;
		return test_cases_;
	}

	static void
	_register_test_case(test_case * test_case_)
	{
		auto & test_cases_ = _test_cases();
		auto it = std::find(test_cases_.begin(), test_cases_.end(), test_case_);
		if(it != test_cases_.end())
			test_cases_.push_back(test_case_);
	}

	int run_all()
	{
		auto & test_cases_ = _test_cases();
		for(auto * e : test_cases_)
		{
			if(e) 
				std::cout << e->_name << std::endl;
		}
		return 0;
	}
};

struct test_case
{
	cstring_t _name = nullptr;

	test_case(cstring_t name_)
		: _name { name_ }
	{}

};

struct assertion_fail
{
	test_case * _test_case = nullptr;
	cstring_t   _file      = nullptr;
	int         _line      = 0;
};

#define TEST(Name) struct Name : test<Name> { \
	static thread_local constexpr cstring_t _test_name = #Name;
#define TEST_(Name) };

#define TEST_CASE(TestName, Name) static thread_local struct test_case_ ## Name : public test_case { \
	static thread_local constexpr cstring_t _test_case_name = #Name; \
	test_case_ ## Name() : test_case { _test_case_name }\
	{ \
		TestName::_register_test_case(this); \
	} \
	void run() 
#define TEST_CASE_(TestName, Name) } _ ## Name;

#define ASSERT_TRUE(...) if(!(__VA_ARGS__)) throw assertion_fail{this, __FILE__, __LINE__};

TEST(array_tests)

	TEST_CASE(array_tests, default_constructor_test)
	{
		int i = 0;
		ASSERT_TRUE(i == 5);
	}
	TEST_CASE_(array_tests, default_constructor_test)

TEST_(array_tests)

int main(int argc, char * argv[])
{
	array_tests array_tests_;
	return array_tests_.run_all();
}
