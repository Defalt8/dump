#include <pptest>
#include <colored_printer>
#include <ds/string>

template class ds::String<ds::DefaultAllocator>;

Test(string)
{
	TestInit(string);

	Testcase(test_default_constructible)
	{
		AssertTrue(ds::is_constructible<ds::String<>>::value);
	} TestcaseEnd(test_default_constructible);

	Testcase(test_default_construct)
	{
	} TestcaseEnd(test_default_construct);

	Testcase(test_comparision_operators_string_view)
	{
		ExpectEQ(""_dstrv, ""_dstrv);
		ExpectLT(""_dstrv, "1"_dstrv);
		ExpectLE(""_dstrv, "1"_dstrv);
		ExpectLT("0"_dstrv, "1"_dstrv);
		ExpectLE("0"_dstrv, "1"_dstrv);
		ExpectGT("1"_dstrv, ""_dstrv);
		ExpectGE("1"_dstrv, ""_dstrv);
		ExpectGT("1"_dstrv, "0"_dstrv);
		ExpectGE("1"_dstrv, "0"_dstrv);
	} TestcaseEnd(test_comparision_operators_string_view);

	Testcase(test_comparision_operators_pstring)
	{
		ExpectEQ(""_dstrv, "");
		ExpectLT(""_dstrv, "1");
		ExpectLE(""_dstrv, "1");
		ExpectLT("0"_dstrv, "1");
		ExpectLE("0"_dstrv, "1");
		ExpectGT("1"_dstrv, "");
		ExpectGE("1"_dstrv, "");
		ExpectGT("1"_dstrv, "0");
		ExpectGE("1"_dstrv, "0");
	} TestcaseEnd(test_comparision_operators_pstring);

	Testcase(test_string_comparision_operators_string)
	{
		ExpectEQ(""_dstr, ""_dstr);
		ExpectLT(""_dstr, "1"_dstr);
		ExpectLE(""_dstr, "1"_dstr);
		ExpectLT("0"_dstr, "1"_dstr);
		ExpectLE("0"_dstr, "1"_dstr);
		ExpectGT("1"_dstr, ""_dstr);
		ExpectGE("1"_dstr, ""_dstr);
		ExpectGT("1"_dstr, "0"_dstr);
		ExpectGE("1"_dstr, "0"_dstr);
	} TestcaseEnd(test_string_comparision_operators_string);

	Testcase(test_string_comparision_operators_string_view)
	{
		ExpectEQ(""_dstr, ""_dstrv);
		ExpectLT(""_dstr, "1"_dstrv);
		ExpectLE(""_dstr, "1"_dstrv);
		ExpectLT("0"_dstr, "1"_dstrv);
		ExpectLE("0"_dstr, "1"_dstrv);
		ExpectGT("1"_dstr, ""_dstrv);
		ExpectGE("1"_dstr, ""_dstrv);
		ExpectGT("1"_dstr, "0"_dstrv);
		ExpectGE("1"_dstr, "0"_dstrv);
	} TestcaseEnd(test_string_comparision_operators_string_view);

	Testcase(test_string_comparision_operators_pstring)
	{
		ExpectEQ(""_dstr, "");
		ExpectLT(""_dstr, "1");
		ExpectLE(""_dstr, "1");
		ExpectLT("0"_dstr, "1");
		ExpectLE("0"_dstr, "1");
		ExpectGT("1"_dstr, "");
		ExpectGE("1"_dstr, "");
		ExpectGT("1"_dstr, "0");
		ExpectGE("1"_dstr, "0");
	} TestcaseEnd(test_string_comparision_operators_pstring);

};

TestRegistry(string)
{
	Register(test_default_constructible)
	Register(test_default_construct)
	Register(test_string_comparision_operators_string)
	Register(test_string_comparision_operators_string_view)
	Register(test_string_comparision_operators_pstring)
};

template <class C>
using reporter_t = pptest::colored_printer<C>;

#include <ds/hash_list>
#include <ds/hash_map>

#include <iostream>

std::ostream &
operator<<(std::ostream & ost, ds::StringView const & string)
{
	return ost << string.begin();
}

template <class A>
std::ostream &
operator<<(std::ostream & ost, ds::String<A> const & string)
{
	return ost << string.begin();
}

template <typename K, typename V>
std::ostream &
operator<<(std::ostream & ost, ds::Entry<K,V> const & entry)
{
	return ost << '(' << entry.key << ": " << entry.value << ')';
}

template <typename T
	, typename = ds::enabled_iterable_const_forward_iterator_t<T>
	>
static constexpr void
print(T && forward_iterable)
{
	auto end_   = ds::end(ds::cref(forward_iterable));
	for(auto it = ds::begin(ds::cref(forward_iterable)); it != end_; ++it)
		std::cout << *it << " ";
	std::cout << std::endl;
}

template <typename T
	, typename = ds::enabled_iterable_size_t<T>
	, typename = ds::enabled_iterable_forward_iterator_t<T>
	, typename = ds::enabled_iterable_reverse_iterator_t<T>
	>
static constexpr void
reverse(T && forward_and_reverse_iterable)
{
	auto size_ = ds::size(forward_and_reverse_iterable);
	if(size_ > 1)
	{
		auto it  = ds::begin(forward_and_reverse_iterable);
		auto rit = ds::rbegin(forward_and_reverse_iterable);
		size_ /= 2;
		for(; size_-- > 0; ++it, --rit)
			ds::swap(*it, *rit);
	}
}

template <size_t... sequence_>
void
print_indices(ds::index_sequence<sequence_...>)
{
	auto fixed_ = ds::fixed<sizeof...(sequence_),int>({sequence_...});
	print(fixed_);
}

int main()
{
	// print_indices(ds::make_index_sequence_t<0,10>());
	// print_indices(ds::make_index_sequence_t<10,0>()); 
	// print_indices(ds::make_reverse_index_sequence_t<0,10>());
	// print_indices(ds::make_reverse_index_sequence_t<10,0>());
	// return 0;
	if(0)
	{
		struct LID {};
		constexpr size_t usage_ = ds::usage_s<ds::String<>,6>::value;
		using LFA = ds::LocalForwardAllocator<ds::usage_s<ds::String<>,6>::value>;
		using ALI = ds::AllocatorInterface<LID,LFA>;
		LFA local_alloc;
		ALI alloc_interface { local_alloc };
		auto string = ds::string<ALI>("hello");
		print(string);
	}
	if(0)
	{
		// using entry_t = ds::Entry<ds::string_view,int>;
		// auto map = ds::hash_list<16,entry_t>({{"hello"_dstr,1}, {"hi"_dstr, 2}});
		// auto map = ds::HashMap<16,ds::string_view,int>({{"hello",1}, {"hi", 2}});
		auto map = ds::HashMap<16,ds::string<>,int>({{"hello",1}, {"hi", 2}});
		print(map);
		// printf("%s\n", ds::string<>().begin());
		// printf("%s\n", ds::string<>(ds::noinit).begin());
	}
	if(0)
	{
		auto const & psq = ds::init_prime_squares<size_t,512>();
		// print(psq);
		{
			auto hash_ = ds::Hasher<char[5]>::hash("hello world!");
			printf("%zu\n", hash_);
		}
		{
			auto hash_ = ds::Hasher<char[]>::hash("hello world!");
			printf("%zu\n", hash_);
		}
	}
	// if(0)
	{
		ds::String<> string = "hello world!"_dstr;
		std::cout << string << std::endl;
		ds::reverse(string);
		std::cout << string << std::endl;
	}
	if(0)
	{
		ds::String<> string = "hello world!";
		std::cout << string << std::endl;
	}
	// if(0)
	// {
	// 	struct LID {};
	// 	constexpr size_t usage_ = ds::usage_s<ds::List<1,int>,5>::value;
	// 	using LFA = ds::LocalForwardAllocator<ds::usage_s<ds::List<1,int>,5>::value>;
	// 	using ALI = ds::AllocatorInterface<LID,LFA>;
	// 	LFA local_alloc;
	// 	ALI alloc_interface { local_alloc };
	// 	ds::List<1,int,ALI> i({1,2,3,4,5});
	// 	int _ = 9;
	// }
	// return string().run_all(reporter_t<string>(pptest::normal));
}
