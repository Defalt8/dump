#include <pptest>
#include <colored_printer>
#include <ds/array>
#include <ds/traits/iterable>
#include "../counter"
#include "../nocopy"
#include "../nomove"

template class ds::Array<int>;
template class ds::Array<NoMove>;
template class ds::Array<NoCopy>;

Test(array_test)
{
	 
	TestInit(array_test);

	template <typename T>
	struct Sequence 
	{
		T cur; 
		constexpr Sequence(T start_ = {}) : cur { start_ } {}
		constexpr operator T() { return cur++; }
	};

	template <class C, typename E, size_t size_>
	static bool
	compare_eq(C const & iterable, E const (& rhs)[size_])
	{
		if(ds::size(iterable) != size_)
			return false;
		auto it = ds::begin(iterable);
		for(size_t i = 0; i < size_; ++i, ++it)
			if(*it != rhs[i])
				return false;
		return true;
	}

	PreRun()
	{
		Counter::reset();
	}

	Testcase(test_default_constructor)
	{
		{
			AssertThrowNone(ds::Array<Counter> {});
			ds::Array<Counter> array {};
			AssertNull(array);
			AssertEQ(Counter::count(), 0);
			AssertEQ(Counter::active(), 0);
			AssertEQ(Counter::moves(), 0);
			AssertEQ(Counter::copies(), 0);
		}
		AssertEQ(Counter::count(), 0);
		AssertEQ(Counter::active(), 0);
		AssertEQ(Counter::moves(), 0);
		AssertEQ(Counter::copies(), 0);
	} TestcaseEnd(test_default_constructor);

	Testcase(test_size_constructor_with_zero_size)
	{
		{
			constexpr size_t size_ = 0;
			AssertThrowNone(ds::Array<Counter> {size_});
			ds::Array<Counter> array {size_};
			AssertNotNull(array);
			AssertEQ(Counter::count(), 0);
			AssertEQ(Counter::active(), 0);
			AssertEQ(Counter::moves(), 0);
			AssertEQ(Counter::copies(), 0);
		}
		AssertEQ(Counter::count(), 0);
		AssertEQ(Counter::active(), 0);
		AssertEQ(Counter::moves(), 0);
		AssertEQ(Counter::copies(), 0);
	} TestcaseEnd(test_size_constructor_with_zero_size);

	Testcase(test_size_constructor_with_non_zero_size)
	{ 
		AssertThrowNone(
		{
			ds::Array<Counter> array {5};
			AssertNotNull(array);
			AssertEQ(Counter::count(), 5);
			AssertEQ(Counter::active(), 5);
			AssertEQ(Counter::moves(), 0);
			AssertEQ(Counter::copies(), 0);
		});
		AssertEQ(Counter::count(), 5);
		AssertEQ(Counter::active(), 0);
		AssertEQ(Counter::moves(), 0);
		AssertEQ(Counter::copies(), 0);
	} TestcaseEnd(test_size_constructor_with_non_zero_size);

	Testcase(test_size_constructor_with_failing_size)
	{ 
		AssertThrow(ds::new_delete_allocator::allocation_failure const &, ds::Array<Counter>(size_t(-1)));
		AssertThrow(ds::bad_alloc const &, ds::Array<Counter>(size_t(-1)));
		AssertEQ(Counter::count(), 0);  
		AssertEQ(Counter::active(), 0);
		AssertEQ(Counter::moves(), 0);
		AssertEQ(Counter::copies(), 0);
	} TestcaseEnd(test_size_constructor_with_failing_size);

	Testcase(test_array_constructor)
	{
		{
			ds::Array<Counter> array {{1,2,3,4,5}};
			AssertNotNull(array);
			AssertEQ(Counter::count(), 5);
			AssertEQ(Counter::active(), 5);
			AssertEQ(Counter::moves(), 0);
			AssertEQ(Counter::copies(), 0);
			AssertTrue(compare_eq(array, {1,2,3,4,5}));
		}
		AssertEQ(Counter::count(), 5);
		AssertEQ(Counter::active(), 0);
		AssertEQ(Counter::moves(), 0);
		AssertEQ(Counter::copies(), 0);
	} TestcaseEnd(test_array_constructor);

	Testcase(test_initializer_list_constructor)
	{
		{
			ds::Array<Counter> array = {1,2,3,4,5};
			AssertNotNull(array);
			AssertEQ(Counter::count(), 5);
			AssertEQ(Counter::active(), 5); 
			AssertEQ(Counter::moves(), 0);
			AssertEQ(Counter::copies(), 0);
			AssertTrue(compare_eq(array, {1,2,3,4,5}));
		}
		AssertEQ(Counter::count(), 5);
		AssertEQ(Counter::active(), 0);
		AssertEQ(Counter::moves(), 0);
		AssertEQ(Counter::copies(), 0);
	} TestcaseEnd(test_initializer_list_constructor);

	Testcase(test_move_constructor)
	{
		{
			ds::Array<Counter> array {{1,2,3,4,5}};
			AssertNotNull(array);
			AssertEQ(Counter::count(), 5);
			AssertEQ(Counter::active(), 5);
			AssertEQ(Counter::moves(), 0);
			AssertEQ(Counter::copies(), 0);
			ds::Array<Counter> moved_array = ds::move(array);
			AssertNotNull(moved_array);
			AssertNull(array);
			AssertEQ(Counter::count(), 5);
			AssertEQ(Counter::active(), 5);
			AssertEQ(Counter::moves(), 0);
			AssertEQ(Counter::copies(), 0);
			AssertTrue(compare_eq(moved_array, {1,2,3,4,5}));
		}
		AssertEQ(Counter::count(), 5);
		AssertEQ(Counter::active(), 0);
		AssertEQ(Counter::moves(), 0);
		AssertEQ(Counter::copies(), 0);
	} TestcaseEnd(test_move_constructor);

	Testcase(test_copy_constructor)
	{
		{
			ds::Array<Counter> array {{1,2,3,4,5}};
			AssertNotNull(array);
			AssertEQ(Counter::count(), 5);
			AssertEQ(Counter::active(), 5);
			AssertEQ(Counter::moves(), 0);
			AssertEQ(Counter::copies(), 0);
			auto begin_ = array.begin();
			ds::Array<Counter> copied_array = array;
			AssertNotNull(copied_array);
			AssertNotNull(array);
			AssertEQ(begin_, array.begin());
			AssertNEQ(begin_, copied_array.begin());
			AssertEQ(Counter::count(), 10);
			AssertEQ(Counter::active(), 10);
			AssertEQ(Counter::moves(), 0);
			AssertEQ(Counter::copies(), 5);
			AssertTrue(compare_eq(array, {1,2,3,4,5}));
			AssertTrue(compare_eq(copied_array, {1,2,3,4,5}));
		}
		AssertEQ(Counter::count(), 10);
		AssertEQ(Counter::active(), 0);
		AssertEQ(Counter::moves(), 0);
		AssertEQ(Counter::copies(), 5);
	} TestcaseEnd(test_copy_constructor);

	Testcase(test_nomove_passing_constructor)
	{
		ds::Array<NoMove> array {{1,2}};
		AssertEQ(sizeof(array), sizeof(ds::Array<int>));
		AssertNotNull(array);
		AssertFalse(ds::is_move_constructible<NoMove>::value);
		AssertTrue(ds::is_move_constructible<ds::Array<NoMove>>::value);
		auto copied_array = array;
		auto moved_array = ds::move(array);
	} TestcaseEnd(test_nomove_passing_constructor);

	Testcase(test_nocopy_failing_constructor)
	{
		ds::Array<NoCopy> array {{1,2}};
		AssertEQ(sizeof(array), sizeof(ds::Array<int>)); 
		AssertNotNull(array);
		AssertFalse(ds::is_copy_constructible<NoCopy>::value);
		AssertFalse(ds::is_copy_constructible<ds::Array<NoCopy>>::value);
		// auto copied_array = array;
		auto moved_array = ds::move(array);
	} TestcaseEnd(test_nocopy_failing_constructor);

	template <typename T
		, typename E   = ds::enabled_iterable_element_t<T>
		, typename CIt = ds::enabled_iterable_const_forward_iterator_t<T>>
	static E
	accumulate(T const & const_forward_iterable)
	{
		E total_ = {};
		CIt begin_ = ds::begin(const_forward_iterable);
		CIt end_   = ds::end(const_forward_iterable);
		for(auto it = begin_; it != end_; ++it)
			total_ += *it;
		return total_;
	}

	Testcase(test_iterable_traits_in_function_template_test)
	{
		constexpr size_t size_ = 5;
		ds::Array<int> array_ = {{1,2,3,4,5}};
		auto total_ = accumulate(array_);
		AssertTrue(ds::is_same<decltype(total_),int>::value);
		AssertEQ(total_, 15);
	} TestcaseEnd(test_iterable_traits_in_function_template_test);

};

TestRegistry(array_test)
{
	Register(test_default_constructor)
	Register(test_size_constructor_with_zero_size)
	Register(test_size_constructor_with_non_zero_size)
	Register(test_size_constructor_with_failing_size)
	Register(test_array_constructor)
	Register(test_initializer_list_constructor)
	Register(test_move_constructor)
	Register(test_copy_constructor)
	Register(test_nomove_passing_constructor)
	Register(test_nocopy_failing_constructor)
	Register(test_iterable_traits_in_function_template_test)
};

template <class C> using reporter_t = pptest::colored_printer<C>; 

int main()
{
	return array_test().run_all(reporter_t<array_test>(pptest::normal));
}