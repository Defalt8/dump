#include <pptest>
#include <colored_printer>
#include <ds/sys>
#include <ds/file>

Test(file_test)
{
	TestInit(file_test);

	Testcase(test_creation)
	{
		constexpr char const * file_name = WORKING_DIR"test_create.txt";
		remove(file_name);
		{
			ds::File file(file_name, "r");
			AssertNull(file);
		}
		{
			ds::File file(file_name, "w");
			AssertNotNull(file);
		}
		{
			ds::File file(file_name, "r");
			AssertNotNull(file);
		}	
	} TestcaseEnd(test_creation);

};

TestRegistry(file_test)
{
	Register(test_creation)
	// Register(test_open_existing)
	// Register(test_open_non_existing)
	// Register(test_read)
	// Register(test_write)
	// Register(test_size)
	// Register(test_position)
	// Register(test_set_position_valid)
	// Register(test_set_position_invalid)
};

template <class C>
using reporter_t = pptest::colored_printer<C>;

int main()
{
	return file_test().run_all(reporter_t<file_test>(pptest::normal));
}
