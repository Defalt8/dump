#include <pptest>
#include <colored_printer>
#include <ds/list>
#include "../counter"

template struct ds::ListNode<1,Counter>;
template class ds::ListIterator<1,Counter>;
template class ds::ConstListIterator<1,Counter>;
template class ds::List<1,Counter>;

Test(list_1_test)
{
	TestInit(list_1_test);

	Testcase(test_default_constructible)
	{
		AssertTrue(ds::is_constructible<ds::List<1,int>>::value);
	} TestcaseEnd(test_default_constructible);

	Testcase(test_default_construct)
	{
	} TestcaseEnd(test_default_construct);

};

TestRegistry(list_1_test)
{
	Register(test_default_constructible)
	Register(test_default_construct)
};

template <class C>
using reporter_t = pptest::colored_printer<C>;

// struct S
// {
// 	static int _si;
// 	int _i = ++_si;
// 	S(int i = 0) { printf("C%d\n", _i); }
// 	~S() { printf("D%d\n", _i); --_si; }

// 	operator int()       { return _i; }
// 	operator int() const { return _i; }
// };

// int S::_si = 0;

#include <iostream>

template <typename T
	, typename = ds::enabled_iterable_const_forward_iterator_t<T>
	>
static constexpr void
print(T && forward_iterable)
{
	auto end_   = ds::end(ds::cref(forward_iterable));
	for(auto it = ds::begin(ds::cref(forward_iterable)); it != end_; ++it)
		std::cout << *it << " ";
	std::cout << std::endl;
}

template <typename T
	, typename E  = ds::enabled_iterable_element_t<T>
	, typename    = ds::enabled_iterable_size_t<T>
	, typename    = ds::enabled_iterable_const_forward_iterator_t<T>
	>
static constexpr E
mean(T && forward_iterable)
{
	ds::remove_cv_t<E> total_ = {};
	auto count_ = ds::size(forward_iterable);
	if(count_ == 0)
		return total_;
	auto end_   = ds::end(ds::cref(forward_iterable));
	for(auto it = ds::begin(ds::cref(forward_iterable)); it != end_; ++it)
		total_ += *it;
	return total_ / count_;
}

template <typename T
	, typename = ds::enabled_iterable_size_t<T>
	, typename = ds::enabled_iterable_forward_iterator_t<T>
	, typename = ds::enabled_iterable_reverse_iterator_t<T>
	>
static constexpr void
reverse(T && forward_and_reverse_iterable)
{
	auto size_ = ds::size(forward_and_reverse_iterable);
	if(size_ > 1)
	{
		auto it  = ds::begin(forward_and_reverse_iterable);
		auto rit = ds::rbegin(forward_and_reverse_iterable);
		size_ /= 2;
		for(; size_-- > 0; ++it, --rit)
			ds::swap(*it, *rit);
	}
}

#include <ds/all>
#include "../helpers"
#include <vector>

struct D { int i; D(int) {} };

int main()
{
	{
		ds::string<> s = "hello";
		ds::string_stream<>() << "hello"_dsstrv.view(1,2) << ds::endl;
	}
	return 0;
	{
		ds::array<int> array1 (3, [i=0]() mutable { return ++i; });
		ds::array<int> array2 (3, [i=3]() mutable { return ++i; });
		// ds::array<S> array (array1, ds::move(array2));
		ds::array<S> array ((array1));
		array += (array2);
		ds::string_stream<>() << array << ds::endl;
	}
	return 0;
	{
		// ds::Fixed<3,int> fixed{1,2,3};
		// ds::Fixed<3,D> fixed2{4,5,6};
		// ds::array<S> array(ds::begin(fixed), ds::end(fixed));
		// ds::list<2,S> list(array);
		// ds::list<2,S> list(ds::move(fixed), fixed2);
		ds::list<2,int> list1 (3, [i=0]() mutable { return ++i; });
		ds::list<2,int> list2 (3, [i=3]() mutable { return ++i; });
		// ds::list<2,S> list (list1, ds::move(list2));
		ds::list<2,S> list (ds::move(list1));
		list += ds::move(list2);
		ds::string_stream<>() << list << ds::endl;
	}
	return 0;
	{
		struct LID {};
		constexpr size_t usage_ = ds::usage_sn<ds::List<2,int>,5,2>::value;
		using LFA = ds::LocalForwardAllocator<ds::usage_sn<ds::List<2,int>,5,2>::value>;
		using ALI = ds::AllocatorInterface<LID,LFA>;
		LFA local_alloc;
		ALI alloc_interface { local_alloc };
		ds::List<2,int,ALI> i({1,2,3,4,5});
		ds::List<2,int,ALI> j({6,7,8,9,1});
		int _ = 9;
	}
	if(0)
	{
		struct LID {};
		constexpr size_t usage_ = ds::usage_s<ds::List<1,int>,5>::value;
		using LFA = ds::LocalForwardAllocator<ds::usage_s<ds::List<1,int>,5>::value>;
		using ALI = ds::AllocatorInterface<LID,LFA>;
		LFA local_alloc;
		ALI alloc_interface { local_alloc };
		ds::List<1,int,ALI> i({1,2,3,4,5});
		int _ = 9;
	}
	// return list_1_test().run_all(reporter_t<list_1_test>(pptest::normal));
}
