#include <pptest>
#include <colored_printer>
#include <ds/string>

template class ds::String<>;

Test(string)
{
	TestInit(string);

	Testcase(test_default_constructible)
	{
		AssertTrue(ds::is_constructible<ds::String<>>::value);
	} TestcaseEnd(test_default_constructible);

	Testcase(test_default_construct)
	{
	} TestcaseEnd(test_default_construct);

	Testcase(test_comparision_operators_string_view)
	{
		ExpectEQ(""_dsstrv, ""_dsstrv);
		ExpectEQ(""_dsstrv, ""_dsstrv);
		ExpectLT(""_dsstrv, "1"_dsstrv);
		ExpectLE(""_dsstrv, "1"_dsstrv);
		ExpectLT("0"_dsstrv, "1"_dsstrv);
		ExpectLE("0"_dsstrv, "1"_dsstrv);
		ExpectGT("1"_dsstrv, ""_dsstrv);
		ExpectGE("1"_dsstrv, ""_dsstrv);
		ExpectGT("1"_dsstrv, "0"_dsstrv);
		ExpectGE("1"_dsstrv, "0"_dsstrv);
	} TestcaseEnd(test_comparision_operators_string_view);

	Testcase(test_comparision_operators_pstring)
	{
		ExpectEQ(""_dsstrv, "");
		ExpectLT(""_dsstrv, "1");
		ExpectLE(""_dsstrv, "1");
		ExpectLT("0"_dsstrv, "1");
		ExpectLE("0"_dsstrv, "1");
		ExpectGT("1"_dsstrv, "");
		ExpectGE("1"_dsstrv, "");
		ExpectGT("1"_dsstrv, "0");
		ExpectGE("1"_dsstrv, "0");
	} TestcaseEnd(test_comparision_operators_pstring);

	Testcase(test_string_comparision_operators_string)
	{
		{
			ds::String<> sv1(ds::noinit), sv2(ds::noinit);
			ExpectFalse(sv1 != sv2);
			ExpectFalse(sv1 == sv2);
			ExpectFalse(sv1 >= sv2);
			ExpectFalse(sv1 <= sv2);
			ExpectFalse(sv1 > sv2);
			ExpectFalse(sv1 < sv2);
		}
		ExpectEQ(""_dsstr, ""_dsstr);
		ExpectLT(""_dsstr, "1"_dsstr);
		ExpectLE(""_dsstr, "1"_dsstr);
		ExpectLT("0"_dsstr, "1"_dsstr);
		ExpectLE("0"_dsstr, "1"_dsstr);
		ExpectGT("1"_dsstr, ""_dsstr);
		ExpectGE("1"_dsstr, ""_dsstr);
		ExpectGT("1"_dsstr, "0"_dsstr);
		ExpectGE("1"_dsstr, "0"_dsstr);
	} TestcaseEnd(test_string_comparision_operators_string);

	Testcase(test_string_comparision_operators_string_view)
	{
		ExpectEQ(""_dsstr, ""_dsstrv);
		ExpectLT(""_dsstr, "1"_dsstrv);
		ExpectLE(""_dsstr, "1"_dsstrv);
		ExpectLT("0"_dsstr, "1"_dsstrv);
		ExpectLE("0"_dsstr, "1"_dsstrv);
		ExpectGT("1"_dsstr, ""_dsstrv);
		ExpectGE("1"_dsstr, ""_dsstrv);
		ExpectGT("1"_dsstr, "0"_dsstrv);
		ExpectGE("1"_dsstr, "0"_dsstrv);
	} TestcaseEnd(test_string_comparision_operators_string_view);

	Testcase(test_string_comparision_operators_pstring)
	{
		ExpectEQ(""_dsstr, "");
		ExpectLT(""_dsstr, "1");
		ExpectLE(""_dsstr, "1");
		ExpectLT("0"_dsstr, "1");
		ExpectLE("0"_dsstr, "1");
		ExpectGT("1"_dsstr, "");
		ExpectGE("1"_dsstr, "");
		ExpectGT("1"_dsstr, "0");
		ExpectGE("1"_dsstr, "0");
	} TestcaseEnd(test_string_comparision_operators_pstring);

};

TestRegistry(string)
{
	Register(test_default_constructible)
	Register(test_default_construct)
	Register(test_string_comparision_operators_string)
	Register(test_string_comparision_operators_string_view)
	Register(test_string_comparision_operators_pstring)
};

template <class C>
using reporter_t = pptest::colored_printer<C>;

int main()
{
	return string().run_all(reporter_t<string>(pptest::normal));
}
