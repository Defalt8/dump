#include <pptest>
#include <colored_printer>
#include <ds/allocator>
#include <ds/traits/iterable>
#include <ds/tuple>

template class ds::Tuple<>;
template class ds::Tuple<int>;
template class ds::Tuple<int,float>;

Test(tuple_test)
{
	TestInit(tuple_test);

	Testcase(test_default_constructible)
	{
		AssertTrue(ds::is_constructible<ds::Tuple<int>>::value);
		AssertTrue(ds::is_constructible<ds::Tuple<int,float>>::value);
	} TestcaseEnd(test_default_constructible);

	Testcase(test_default_construct)
	{
	} TestcaseEnd(test_default_construct);

};

TestRegistry(tuple_test)
{
	Register(test_default_constructible)
	Register(test_default_construct)
};

template <class C>
using reporter_t = pptest::colored_printer<C>;

int main()
{
	return tuple_test().run_all(reporter_t<tuple_test>(pptest::normal));
}
