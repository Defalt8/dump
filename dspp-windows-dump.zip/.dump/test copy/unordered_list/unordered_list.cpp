#include <pptest>
#include <colored_printer>
#include <ds/unordered_list>
#include "../counter"

template class ds::UnorderedListIterator<1,Counter>;
template class ds::ConstUnorderedListIterator<1,Counter>;
template class ds::UnorderedList<1,Counter>;

Test(unordered_list)
{
	TestInit(unordered_list);

	Testcase(test_default_constructible)
	{
		AssertTrue(ds::is_constructible<ds::UnorderedList<1,int>>::value);
	} TestcaseEnd(test_default_constructible);

	Testcase(test_default_construct)
	{
	} TestcaseEnd(test_default_construct);

};

TestRegistry(unordered_list)
{
	Register(test_default_constructible)
	Register(test_default_construct)
};

template <class C>
using reporter_t = pptest::colored_printer<C>;

int main()
{
	return unordered_list().run_all(reporter_t<unordered_list>(pptest::normal));
}
