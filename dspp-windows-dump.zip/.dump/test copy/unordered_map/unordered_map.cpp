#include <pptest>
#include <colored_printer>
#include <ds/unordered_map>
#include "../counter"

template class ds::UnorderedMap<16,Counter,Counter>;

Test(unordered_map)
{
	TestInit(unordered_map);

	Testcase(test_default_constructible)
	{
		AssertTrue(ds::is_constructible<ds::UnorderedMap<16,int,int>>::value);
	} TestcaseEnd(test_default_constructible);

	Testcase(test_default_construct)
	{
	} TestcaseEnd(test_default_construct);

};

TestRegistry(unordered_map)
{
	Register(test_default_constructible)
	Register(test_default_construct)
};

template <class C>
using reporter_t = pptest::colored_printer<C>;

// #include "../helpers"
#include <ds/database>
#include <ds/string>

namespace ds {



} // namespace ds

int main()
{
	// return unordered_map().run_all(reporter_t<unordered_map>(pptest::normal));
	// auto map = ds::OrderedMap<16,ds::string<>,ds::string<>>({{"hi","Hello"}});
	// println(map);
	// if(0)
	// {
	// 	ds::db::Table<ds::string<>,int> table { "name", "age" };
	// 	table.insert(1, "Nati", 24);
	// 	table.insert(2, "Axel", 42);
	// 	table.insert(3, "Natali", 30);
	// 	table.insert(4, "Gabriel", 10000);
	// 	printf(" ID ");
	// 	println(table.headers(), " \t");
	// 	println(table.records(), "\n");
	// 	println(table.columns().at<0>().records(), "\n");
		
	// 	println(ds::db::select_from(table, ds::db::begins_with<0>{"N"}).records(), "\n");
	// 	println(ds::db::select_from(table, ds::db::ends_with<0>{"l"}).records(), "\n");
	// 	println(ds::db::select_from(table, ds::db::contians<0>{"e"}).records(), "\n");
	// 	println(ds::db::select_from(ds::db::select_from(table, ds::db::begins_with<0>{"N"}), ds::db::ends_with<0>{"i"}).records(), "\n");

	// }
}
