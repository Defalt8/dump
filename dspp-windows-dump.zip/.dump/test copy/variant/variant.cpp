
#include <pptest>
#include <colored_printer>
#include <ds/variant>

template class ds::Variant<>;
template class ds::Variant<int>;
template class ds::Variant<int,float>;


int main()
{
	return 0;
}
