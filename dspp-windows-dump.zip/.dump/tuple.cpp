#include <pptest>
#include <colored_printer>
#include <ds/allocator>
#include <ds/traits/iterable>
#include <ds/tuple>

template class ds::Tuple<>;
template class ds::Tuple<int>;
template class ds::Tuple<int,float>;

Test(tuple_test)
{
	TestInit(tuple_test);

	Testcase(test_default_constructible)
	{
		AssertTrue(!ds::is_constructible<ds::Tuple<>>::value);
		AssertTrue(ds::is_constructible<ds::Tuple<int>>::value);
		AssertTrue(ds::is_constructible<ds::Tuple<int,float>>::value);
	} TestcaseEnd(test_default_constructible);

	Testcase(test_default_construct)
	{
	} TestcaseEnd(test_default_construct);

};

TestRegistry(tuple_test)
{
	Register(test_default_constructible)
	Register(test_default_construct)
};

template <class C>
using reporter_t = pptest::colored_printer<C>;

#include <iostream>
#include <ds/string>

std::ostream &
operator<<(std::ostream & ost, ds::StringView const & string)
{
	return ost << string.begin();
}

template <class A>
std::ostream &
operator<<(std::ostream & ost, ds::String<A> const & string)
{
	return ost << string.begin();
}

template <typename T
	, typename = ds::enabled_iterable_const_forward_iterator_t<T>
	>
static constexpr void
print(T && forward_iterable)
{
	auto end_   = ds::end(ds::cref(forward_iterable));
	for(auto it = ds::begin(ds::cref(forward_iterable)); it != end_; ++it)
		std::cout << *it << " ";
	std::cout << std::endl;
}

template <typename T
	, typename = ds::enabled_iterable_size_t<T>
	, typename = ds::enabled_iterable_forward_iterator_t<T>
	, typename = ds::enabled_iterable_reverse_iterator_t<T>
	>
static constexpr void
reverse(T && forward_and_reverse_iterable)
{
	auto size_ = ds::size(forward_and_reverse_iterable);
	if(size_ > 1)
	{
		auto it  = ds::begin(forward_and_reverse_iterable);
		auto rit = ds::rbegin(forward_and_reverse_iterable);
		size_ /= 2;
		for(; size_-- > 0; ++it, --rit)
			ds::swap(*it, *rit);
	}
}

#include <ds/fixed>
#include <ds/string>

template <size_t... sequence_>
void
print_indices(ds::index_sequence<sequence_...>)
{
	auto fixed_ = ds::fixed<sizeof...(sequence_),int>({sequence_...});
	print(fixed_);
}

int main()
{
	{
		// ds::tuple<> empty;
		// ds::tuple<int> tupi = 1;
		// tupi.for_each([](size_t i, auto && object)
		// {
		// 	std::cout << i << ": " << object << std::endl;
		// });
		// printf("%zu\n", sizeof(ds::tuple<int,float>));
		// constexpr ds::tuple<int,float> tupif = { 2, 2.4f };
		// tupif.for_each([](size_t i, auto && object)
		// {
		// 	std::cout << i << ": " << object << std::endl;
		// });
		// printf("%zu\n", sizeof(ds::tuple<int,float,ds::string<>>));
		// ds::tuple<int,float,ds::string<>> tupifs = { 2, 3.4f, "hello" };
		// tupifs.for_each([](size_t i, auto && object)
		// {
		// 	std::cout << i << ": " << object << std::endl;
		// });
		// auto tupifs = ds::make_tuple(2, 3.4f, "hello"_dstrv);
		// printf("%zu\n", sizeof(tupifs));
		// tupifs.reverse_for_each([](size_t i, auto && object)
		// {
		// 	std::cout << i << ": " << object << std::endl;
		// });
	}
	// print_indices(ds::make_index_sequence_t<0,10>());
	// print_indices(ds::make_index_sequence_t<10,0>()); 
	// print_indices(ds::make_reverse_index_sequence_t<0,10>());
	// print_indices(ds::make_reverse_index_sequence_t<10,0>());
	// return tuple_test().run_all(reporter_t<tuple_test>(pptest::normal));
}
