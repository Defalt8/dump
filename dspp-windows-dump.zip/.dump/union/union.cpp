
#include <pptest>
#include <colored_printer>
#include <ds/union>

#include <ds/string>
#include <iostream>

template <typename T>
static void 
println(T && object)
{
	std::cout << object << std::endl;
}

// template class ds::Union<>;
// template class ds::Union<int>;
// template class ds::Union<int,float>;

#define FSIG() printf("[%p] %s\n", this, __FUNCSIG__)
// #define FSIG() printf("[%p] %s\n", this, __PRETTY_FUNCTION__)

struct S
{
	int value = 0;
	~S() { FSIG(); }
	S() { FSIG(); }
	S(S && rhs) : value {rhs.value} { FSIG(); }
	S(S const & rhs) : value {rhs.value} { FSIG(); }
	S(int i) : value {i} { FSIG(); }

	operator int       & ()       { return value; }
	operator int const & () const { return value; }

};

struct DestructorBase
{
	virtual void destruct() { FSIG(); }; 
};

template <typename T>
struct Destructor : public DestructorBase
{
	void 
	destruct() override
	{
		FSIG();
	}
};

#include <variant>
#include <ds/array>
#include "../benchmark"

int main()
{
	using ds::nullptr_t;
	size_t size_ = 10000, count_ = 10, warmup_ = 1;
	using union_t = ds::Union<bool,int8_t,uint8_t,int16_t,uint16_t,uint32_t,float,nullptr_t,S,int>;
	using union2_t = ds::Union<int,int8_t,uint8_t,int16_t,uint16_t,uint32_t,float,nullptr_t,S,bool>;
	using variant_t = std::variant<bool,int8_t,uint8_t,int16_t,uint16_t,uint32_t,float,nullptr_t,S,int>;
	using variant2_t = std::variant<int,int8_t,uint8_t,int16_t,uint16_t,uint32_t,float,nullptr_t,S,bool>;
	// if(0)
	{
		printf("%zu\n", sizeof(union_t));
		printf("%zu\n", alignof(union_t));
		benchmark::delay(.1);
		{
			benchmark::rep_test("destruct near", [&]()
			{
				ds::Array<union2_t> array(size_, int(1));
				// for(auto & e : array)
				// 	ds::construct_at<union_t>(&e, int(1));
			}, count_, warmup_);
		}
		benchmark::delay(.1);
		{
			benchmark::rep_test("destruct far", [&]()
			{
				ds::Array<union_t> array(size_, int(1));
				// for(auto & e : array)
				// 	ds::construct_at<union_t>(&e, int(1));
			}, count_, warmup_);
		}
	}
	// if(0)
	{
		printf("%zu\n", sizeof(union_t));
		printf("%zu\n", alignof(union_t));
		benchmark::delay(.1);
		{
			ds::Array<union2_t> array(size_, ds::noinit);
			benchmark::rep_test("construct near", [&]()
			{
				for(auto & e : array)
					ds::construct_at<union_t>(&e, int(1));
			}, count_, warmup_);
		}
		benchmark::delay(.1);
		{
			ds::Array<union_t> array(size_, ds::noinit);
			benchmark::rep_test("construct far", [&]()
			{
				for(auto & e : array)
					ds::construct_at<union_t>(&e, int(1));
			}, count_, warmup_);
		}
	}
	// if(0)
	{
		printf("%zu\n", sizeof(variant_t));
		printf("%zu\n", alignof(variant_t));
		benchmark::delay(.1);
		{
			ds::Array<variant2_t> array(size_, ds::noinit);
			benchmark::rep_test("construct near", [&]()
			{
				for(auto & e : array)
					ds::construct_at<variant2_t>(&e, std::in_place_type_t<int>{}, 1);
			}, count_, warmup_);
		}
		benchmark::delay(.1);
		{
			ds::Array<variant_t> array(size_, ds::noinit);
			benchmark::rep_test("construct far", [&]()
			{
				for(auto & e : array)
					ds::construct_at<variant_t>(&e, std::in_place_type_t<int>{}, 1);
			}, count_, warmup_);
		}
	}
	// if(0)
	{
		printf("%zu\n", sizeof(union_t));
		benchmark::delay(.1);
		{
			ds::Array<int> array(size_, true);
			ds::Array<int> values(size_);
			benchmark::rep_test("value", [&]()
			{
				int i = 0;
				for(auto & e : values)
					e = array[i++];
			}, count_, warmup_);
		}
		benchmark::delay(.1);
		{
			ds::Array<union2_t> array(size_, int(0));
			ds::Array<int> values(size_);
			benchmark::rep_test("get near", [&]()
			{
				int i = 0;
				for(auto & e : values)
					e = array[i++].get<int>();
			}, count_, warmup_);
		}
		benchmark::delay(.1);
		{
			ds::Array<union_t> array(size_, uint16_t(1));
			ds::Array<uint16_t> values(size_);
			benchmark::rep_test("get mid", [&]()
			{
				int i = 0;
				for(auto & e : values)
					e = array[i++].get<uint16_t>();
			}, count_, warmup_);
		}
		benchmark::delay(.1);
		{
			ds::Array<union_t> array(size_, int(1));
			ds::Array<int> values(size_);
			benchmark::rep_test("get far", [&]()
			{
				int i = 0;
				for(auto & e : values)
					e = array[i++].get<int>();
			}, count_, warmup_);
		}
	}
	// if(0)
	{
		printf("%zu\n", sizeof(variant_t));
		benchmark::delay(.1);
		{
			ds::Array<int> array(size_, true);
			ds::Array<int> values(size_);
			benchmark::rep_test("value", [&]()
			{
				int i = 0;
				for(auto & e : values)
					e = array[i++];
			}, count_, warmup_);
		}
		benchmark::delay(.1);
		{
			ds::Array<variant2_t> array(size_, ds::noinit);
			for(auto & e : array)
				ds::construct_at<variant2_t>(&e, std::in_place_type_t<int>{}, (0));
			ds::Array<int> values(size_);
			benchmark::rep_test("get near", [&]()
			{
				int i = 0;
				for(auto & e : values)
					e = std::get<int>(array[i++]);
			}, count_, warmup_);
		}
		benchmark::delay(.1);
		{
			ds::Array<variant_t> array(size_, ds::noinit);
			for(auto & e : array)
				ds::construct_at<variant_t>(&e, std::in_place_type_t<uint16_t>{}, (1));
			ds::Array<uint16_t> values(size_);
			benchmark::rep_test("get mid", [&]()
			{
				int i = 0;
				for(auto & e : values)
					e = std::get<uint16_t>(array[i++]);
			}, count_, warmup_);
		}
		benchmark::delay(.1);
		{
			ds::Array<variant_t> array(size_, ds::noinit);
			for(auto & e : array)
				ds::construct_at<variant_t>(&e, std::in_place_type_t<int>{}, (1));
			ds::Array<int> values(size_);
			benchmark::rep_test("get far", [&]()
			{
				int i = 0;
				for(auto & e : values)
					e = std::get<int>(array[i++]);
			}, count_, warmup_);
		}
	}
	// if(0)
	// {
	// 	size_t count_ = 1000, warmup_ = 10;
	// 	using union_t = ds::Union<bool,int8_t,uint8_t,int16_t,uint16_t,int32_t,uint32_t,float,nullptr_t,S,int>;
	// 	printf("%zu\n", sizeof(union_t));
	// 	union_t u;
	// 	benchmark::rep_test("construct near", [&]()
	// 	{
	// 		union_t uni = true;
	// 		// u = uni;
	// 	}, count_, warmup_);
	// 	benchmark::rep_test("construct far", [&]()
	// 	{
	// 		union_t uni = int(5);
	// 		// u = uni;
	// 	}, count_, warmup_);
	// 	{
	// 		union_t uni = int(5);
	// 		benchmark::rep_test("get", [&]()
	// 		{
	// 			uni.get<int>();
	// 			// u = uni;
	// 		}, count_, warmup_);
	// 	}
	// 	{
	// 		union_t uni = int(5);
	// 		benchmark::rep_test("index", [&]()
	// 		{
	// 			uni.index();
	// 			// u = uni;
	// 		}, count_, warmup_);
	// 	}
	// }
	// if(0)
	// {
	// 	using d_t = ds::Union<S,float>::handler_t;
	// 	// printf("%zu\n", sizeof(ds::Union<S,float,int>));
	// 	// ds::Union<S,float,int> uni1 = int(5);
	// 	// printf("%d\n", uni1.get<int>());
	// 	// uni1 = 3.14f;
	// 	// printf("%f\n", uni1.get<float>());
	// 	ds::Union<S,float,int> uni1 = ds::carry<S>(5);
	// 	printf("%d\n", uni1.get<S>().value);
	// 	// uni1 = ds::carry<S>(7);
	// 	// printf("%d\n", uni1.get<S>().value);
	// 	// printf("%zu\n", uni1.index());
	// }
	// if(0)
	// {
	// 	// union DU
	// 	// {
	// 	// 	Destructor<int> di;
	// 	// 	Destructor<float> df;
	// 	// };
	// 	using DU = ds::_::CUnion<Destructor<int>,Destructor<float>>;
	// 	DU du { Destructor<int>() };
	// 	reinterpret_cast<DestructorBase &>(du).destruct();
	// 	// static_cast<DestructorBase &>(du).destruct();
	// 	printf("%zu\n", sizeof(DU));
	// 	printf("%zu\n", sizeof(DestructorBase));
	// 	printf("%zu\n", sizeof(Destructor<int>));
	// }
	// if(0)
	// {
	// 	ds::Union<int,float> uni1 = 5;
	// 	ds::Union<int,float> uni2 = 3.14f;
	// 	println(uni1.get<int>());
	// 	println(uni2.get<float>());
	// 	println(uni1.at<0>());
	// 	println(uni2.at<1>());
	// }
}
