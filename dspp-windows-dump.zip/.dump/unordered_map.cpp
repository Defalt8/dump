#include <pptest>
#include <colored_printer>
#include <ds/unordered_map>
#include "../counter"

template class ds::UnorderedMap<16,Counter,Counter>;

Test(unordered_map)
{
	TestInit(unordered_map);

	Testcase(test_default_constructible)
	{
		AssertTrue(ds::is_constructible<ds::UnorderedMap<16,int,int>>::value);
	} TestcaseEnd(test_default_constructible);

	Testcase(test_default_construct)
	{
	} TestcaseEnd(test_default_construct);

};

TestRegistry(unordered_map)
{
	Register(test_default_constructible)
	Register(test_default_construct)
};

template <class C>
using reporter_t = pptest::colored_printer<C>;

#include "../helpers"
#include <ds/string>
#include <ds/unordered_list>

struct Row
{
	ds::String<> first_name;
	ds::String<> last_name;
	int          age    = 0;
	float        height = 0.0f;
	
	Row() = default;

	Row(ds::StringView first_name_, ds::StringView last_name_, int age_, float height_)
		: first_name { first_name_ }
		, last_name  { last_name_ }
		, age        { age_ }
		, height     { height_ }
	{}

};

std::ostream &
operator<<(std::ostream & ost, Row const & row)
{
	return ost << '"' << row.first_name << ' ' << row.last_name << "\" "
			<< row.age << ' ' << row.height;
}

#include <ds/unordered_list>
#include <ds/unordered_map>
#include <ds/ordered_list>
#include <ds/ordered_map>

int main()
{
	// return unordered_map().run_all(reporter_t<unordered_map>(pptest::normal));

	if(0)
	{
		using map_t = ds::unordered_map<64,int,Row>;
		using columns_t = ds::unordered_map<64,ds::String<>,int>;
		using column1_t = ds::ordered_list<64,ds::Entry<ds::String<>,int>>;
		using column2_t = ds::ordered_list<64,ds::Entry<ds::String<>,int>>;

		map_t table;
		columns_t columns({ {"first_name", 0}, {"last_name", 1}, {"age", 2}, {"height", 3} });
		column1_t column1;
		column2_t column2;

		table.set(1, Row{"Natnael", "Eshetu", 24, 1.83f}); 
		column1.emplace("Natnael", 1);
		column2.emplace("Eshetu", 1);

		table.set(2, Row{"Zuko", "Kran", 32, 1.9f});
		column1.emplace("Zuko", 2);
		column2.emplace("Kran", 2);
		
		table.set(3, Row{"Zuko", "Liek", 45, 1.75f});
		column1.emplace("Zuko", 3);
		column2.emplace("Liek", 3);
		
		table.set(4, Row{"Natali", "Khan", 24, 1.83f}); 
		column1.emplace("Natali", 4);
		column2.emplace("Khan", 4);

		table.set(5, Row{"Nadia", "Sobak", 24, 1.83f}); 
		column1.emplace("Nadia", 5);
		column2.emplace("Sobak", 5);

		table.set(6, Row{"Nadeen", "Kurat", 24, 1.83f}); 
		column1.emplace("Nadeen", 6);
		column2.emplace("Kurat", 6);

		println(columns);
		println(table, "\n");
		println(column1, "\n");
		println(column2, "\n");
		// println(table.get(1)->value);

		println();

		for(auto it = column1.nearest_position_of("Nad"); 
				it && it->key.partial_compare("Nata") <= 0; ++it)
			println(table.get(it->value).ref());

		println();

		for(auto it = column1.nearest_position_of("Z"); 
				it && it->key.partial_compare("Z") <= 0; ++it)
			println(table.get(it->value).ref());
		
		// println(table.get(column1.position_of("Zuko")->value).ref());
		// println(table.get(column1.position_of("Zuko",1)->value).ref());
		// println(table.get(column2.position_of("Kran")->value).ref());
		// println(table.get(column1.position_of("Zuko",2)->value).ref());
	}
	// if(0)
	{
		println((int *)ds::OrderedHasher<char[2]>::hash("0"));
		println((int *)ds::OrderedHasher<char[2]>::hash("1"));
		println((int *)ds::OrderedHasher<char[2]>::hash("00"));
		println((int *)ds::OrderedHasher<char[2]>::hash("11"));
	}
	if(0)
	{
		// ds::ordered_list<16,char> list({'1','3','2','1','2','3','1','4','0'}
		// ds::ordered_map<16,char,char> list({'1','3','2','1','2','3','1','4','0'}
		ds::unordered_map<26,char,int> list({{'1',1},{'3',2},{'2',3},{'1',4},{'2',5},{'3',6},{'1',7},{'4',8},{'0',9}}
			, ds::duplicate_rule::Allow);
			// , ds::duplicate_rule::Unique);
			// , ds::duplicate_rule::Replace);
			// );
		println(list);
		list.remove('0'); println(list);
		list.remove('1'); println(list);
		list.remove('2'); println(list);
		list.remove('3'); println(list);
		list.remove('4'); println(list);
		list.remove('0'); println(list);
		list.remove('1'); println(list);
		list.remove('2'); println(list);
		list.remove('3'); println(list);
		list.remove('1'); println(list);
		// println(list.position_of('0').ref());
		// println((int *)list.position_of('0').ptr());
		// println((int *)list.position_of('0',1).ptr());
		// println(list.position_of('1').ref());
		// println((int *)list.position_of('1').ptr());
		// println((int *)list.position_of('1',1).ptr());
		// println((int *)list.position_of('1',2).ptr());
		// println((int *)list.position_of('1',3).ptr());
		// println(list.position_of('2').ref());
		// println((int *)list.position_of('2').ptr());
		// println((int *)list.position_of('2',1).ptr());
		// println((int *)list.position_of('2',2).ptr());
		// println(list.position_of('3').ref());
		// println((int *)list.position_of('3').ptr());
		// println((int *)list.position_of('3',1).ptr());
		// println((int *)list.position_of('3',2).ptr());
		// println(list.position_of('4').ref());
		// println((int *)list.position_of('4').ptr());
		// println((int *)list.position_of('4',1).ptr());
	}
}
