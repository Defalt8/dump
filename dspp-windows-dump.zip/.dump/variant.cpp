
#include <pptest>
#include <colored_printer>
#include <ds/variant>

#include <ds/string>
#include <iostream>

template <typename T>
static void 
println(T && object)
{
	std::cout << object << std::endl;
}

#define try_to(...) \
{ \
	try { __VA_ARGS__; } \
	catch(ds::exception const & ex) \
	{ std::cerr << ex.what() << std::endl; } \
}

#define try_to_w(Wrap, ...) \
{ \
	try { Wrap(__VA_ARGS__); } \
	catch(ds::exception const & ex) \
	{ std::cerr << ex.what() << std::endl; } \
}

// template class ds::Variant<>;
// template class ds::Variant<int>;
// template class ds::Variant<int,float>;

#define FSIG()
// #define FSIG() printf("[%p] %s\n", this, __FUNCSIG__)
// #define FSIG() printf("[%p] %s\n", this, __PRETTY_FUNCTION__)

struct S
{
	int value = 0;
	~S() { FSIG(); }
	S() { FSIG(); }
	S(S && rhs) : value {rhs.value} { FSIG(); }
	S(S const & rhs) : value {rhs.value} { FSIG(); }
	S(int i) : value {i} { FSIG(); }

	operator int       & ()       { return value; }
	operator int const & () const { return value; }

};

#include <variant>
#include <ds/array>
#include <ds/unique>
#include "../benchmark"

int main()
{
	// { 
	// 	ds::Variant<int,float,S> var {ds::in_place_t<S>(), 1};
	// 	println(var.get<S>());
	// }
	// if(0)
	// { 
	// 	std::variant<int,float,S> var {std::in_place_type_t<S>(), 1};
	// 	println(std::get<S>(var));
	// }
	// return 0;
	if(0)
	{
		ds::variant<int,float> var = 5.67f;
		
		// try_to(var.visit([&](float & value_) { println(value_); }));
		// try_to(var.visit([&](float const & value_) { println(value_); }));
		// try_to(var.visit([&](int & value_) { println(value_); }));
		// try_to(var.visit([&](int const & value_) { println(value_); }));

		println(var.get<float>()); 
	}
	if(0)
	{
		ds::variant<int,float> var;
		println(var.get<int>());
		println(var.get<float>());
		println(var.get_nt<int>());
		println(var.get_nt<float>());
	}
	if(0)
	{
		ds::Variant<int,float> var { ds::in_place_t<float>(), 3.5f };
		println(var.get<int>());
		println(var.get<float>());
		println(var.at<0>());
		println(var.at<1>());
		println(var.get_nt<int>());
		println(var.get_nt<float>());
		println(var.at_nt<0>());
		println(var.at_nt<1>());
	}


	using ds::nullptr_t;
	size_t size_ = 10000, count_ = 100, warmup_ = 10;
	using ds_variant_t = ds::Variant<bool,int8_t,uint8_t,int16_t,uint16_t,uint32_t,float,int>;
	using ds_variant2_t = ds::Variant<int,int8_t,uint8_t,int16_t,uint16_t,uint32_t,float,bool>;
	using variant_t = std::variant<bool,int8_t,uint8_t,int16_t,uint16_t,uint32_t,float,int>;
	using variant2_t = std::variant<int,int8_t,uint8_t,int16_t,uint16_t,uint32_t,float,bool>;
	// println((ds::is_trivially_destructible<variant_t>::value));
	int value = 0;
	if(0)
	{
		printf("%zu\n", sizeof(ds_variant_t));
		printf("%zu\n", alignof(ds_variant_t));
		benchmark::delay(.1);
		{
			auto var = ds::Unique<ds_variant2_t>(ds::in_place_t<int>(), 5);
			// int value = 0;
			benchmark::rep_test("visit near", [&]()
			{
				for(size_t i = 0; i < size_; ++i)
					var->visit([&](int const & value_) { value += value_; });
			}, count_, warmup_);
		}
		benchmark::delay(.1);
		{
			auto var = ds::Unique<ds_variant_t>(ds::in_place_t<int>(), 5);
			// int value = 0;
			benchmark::rep_test("visit far", [&]()
			{
				for(size_t i = 0; i < size_; ++i)
					var->visit([&](int const & value_) { value += value_; });
			}, count_, warmup_);
		}
	}
	// if(0)
	{
		printf("%zu\n", sizeof(ds_variant_t));
		printf("%zu\n", alignof(ds_variant_t));
		benchmark::delay(.1);
		{
			auto var = ds::Unique<ds_variant2_t>(ds::in_place_t<int>(), 5);
			// int value = 0;
			benchmark::rep_test("visit_nt near", [&]()
			{
				for(size_t i = 0; i < size_; ++i)
					var->visit_nt([&](int const & value_) { value += value_; });
			}, count_, warmup_);
		}
		benchmark::delay(.1);
		{
			auto var = ds::Unique<ds_variant_t>(ds::in_place_t<int>(), 5);
			// int value = 0;
			benchmark::rep_test("visit_nt far", [&]()
			{
				for(size_t i = 0; i < size_; ++i)
					var->visit_nt([&](int const & value_) { value += value_; });
			}, count_, warmup_);
		}
	}
	// if(0)
	{
		printf("%zu\n", sizeof(variant_t));
		printf("%zu\n", alignof(variant_t));
		benchmark::delay(.1);
		{
			auto var = ds::Unique<variant2_t>(std::in_place_type_t<int>(), 5);
			// int value = 0;
			benchmark::rep_test("visit near", [&]()
			{
				for(size_t i = 0; i < size_; ++i)
					std::visit([&](auto const & value_) { value += value_; }, *var);
			}, count_, warmup_);
		}
		benchmark::delay(.1);
		{
			auto var = ds::Unique<variant_t>(std::in_place_type_t<int>(), 5);
			// int value = 0;
			benchmark::rep_test("visit far", [&]()
			{
				for(size_t i = 0; i < size_; ++i)
					std::visit([&](auto const & value_) { value += value_; }, *var);
			}, count_, warmup_);
		}
	}

	// if(0)
	{
		printf("%zu\n", sizeof(ds_variant_t));
		printf("%zu\n", alignof(ds_variant_t));
		benchmark::delay(.1);
		{
			benchmark::rep_test("destruct near", [&]()
			{
				// ds::Array<ds_variant2_t> array(size_, int(1));
				ds::Array<ds_variant2_t> array(size_, ds::noinit);
				for(auto & e : array)
					ds::construct_at<ds_variant2_t>(&e, ds::in_place_t<int>(), 1);
			}, count_, warmup_);
		}
		benchmark::delay(.1);
		{
			benchmark::rep_test("destruct far", [&]()
			{
				// ds::Array<ds_variant_t> array(size_, int(1));
				ds::Array<ds_variant_t> array(size_, ds::noinit);
				for(auto & e : array)
					ds::construct_at<ds_variant_t>(&e, ds::in_place_t<int>(), 1);
			}, count_, warmup_);
		}
	}
	// if(0)
	{
		printf("%zu\n", sizeof(variant_t));
		printf("%zu\n", alignof(variant_t));
		benchmark::delay(.1);
		{
			benchmark::rep_test("destruct near", [&]()
			{
				// ds::Array<variant2_t> array(size_, int(1));
				ds::Array<variant2_t> array(size_, ds::noinit);
				for(auto & e : array)
					ds::construct_at<variant2_t>(&e, std::in_place_type_t<int>(), 1);
			}, count_, warmup_);
		}
		benchmark::delay(.1);
		{
			benchmark::rep_test("destruct far", [&]()
			{
				// ds::Array<variant_t> array(size_, int(1));
				ds::Array<variant_t> array(size_, ds::noinit);
				for(auto & e : array)
					ds::construct_at<variant_t>(&e, std::in_place_type_t<int>(), 1);
			}, count_, warmup_);
		}
	}

	// if(0)
	{
		printf("%zu\n", sizeof(ds_variant_t));
		printf("%zu\n", alignof(ds_variant_t));
		benchmark::delay(.1);
		{
			ds::Array<ds_variant2_t> array(size_, ds::noinit);
			benchmark::rep_test("construct near", [&]()
			{
				for(auto & e : array)
					ds::construct_at<ds_variant_t>(&e, ds::in_place_t<int>(), 1);
			}, count_, warmup_);
		}
		benchmark::delay(.1);
		{
			ds::Array<ds_variant_t> array(size_, ds::noinit);
			benchmark::rep_test("construct far", [&]()
			{
				for(auto & e : array)
					ds::construct_at<ds_variant_t>(&e, ds::in_place_t<int>(), 1);
			}, count_, warmup_);
		}
	}
	// if(0)
	{
		printf("%zu\n", sizeof(variant_t));
		printf("%zu\n", alignof(variant_t));
		benchmark::delay(.1);
		{
			ds::Array<variant2_t> array(size_, ds::noinit);
			benchmark::rep_test("construct near", [&]()
			{
				for(auto & e : array)
					ds::construct_at<variant2_t>(&e, std::in_place_type_t<int>{}, 1);
			}, count_, warmup_);
		}
		benchmark::delay(.1);
		{
			ds::Array<variant_t> array(size_, ds::noinit);
			benchmark::rep_test("construct far", [&]()
			{
				for(auto & e : array)
					ds::construct_at<variant_t>(&e, std::in_place_type_t<int>{}, 1);
			}, count_, warmup_);
		}
	}
	// if(0)
	{
		printf("%zu\n", sizeof(ds_variant_t));
		benchmark::delay(.1);
		{
			ds::Array<int> array(size_, true);
			ds::Array<int> values(size_);
			benchmark::rep_test("value", [&]()
			{
				int i = 0;
				for(auto & e : values)
					e = array[i++];
			}, count_, warmup_);
		}
		benchmark::delay(.1);
		{
			ds::Array<ds_variant2_t> array(size_, int(0));
			ds::Array<int> values(size_);
			benchmark::rep_test("get_nt near", [&]()
			{
				int i = 0;
				for(auto & e : values)
					e = array[i++].get_nt<int>();
			}, count_, warmup_);
		}
		benchmark::delay(.1);
		{
			ds::Array<ds_variant_t> array(size_, uint16_t(1));
			ds::Array<uint16_t> values(size_);
			benchmark::rep_test("get_nt mid", [&]()
			{
				int i = 0;
				for(auto & e : values)
					e = array[i++].get_nt<uint16_t>();
			}, count_, warmup_);
		}
		benchmark::delay(.1);
		{
			ds::Array<ds_variant_t> array(size_, int(1));
			ds::Array<int> values(size_);
			benchmark::rep_test("get_nt far", [&]()
			{
				int i = 0;
				for(auto & e : values)
					e = array[i++].get_nt<int>();
			}, count_, warmup_);
		}
	}
	// if(0)
	{
		printf("%zu\n", sizeof(ds_variant_t));
		benchmark::delay(.1);
		{
			ds::Array<int> array(size_, true);
			ds::Array<int> values(size_);
			benchmark::rep_test("value", [&]()
			{
				int i = 0;
				for(auto & e : values)
					e = array[i++];
			}, count_, warmup_);
		}
		benchmark::delay(.1);
		{
			ds::Array<ds_variant2_t> array(size_, int(0));
			ds::Array<int> values(size_);
			benchmark::rep_test("get near", [&]()
			{
				int i = 0;
				for(auto & e : values)
					e = array[i++].get<int>();
			}, count_, warmup_);
		}
		benchmark::delay(.1);
		{
			ds::Array<ds_variant_t> array(size_, uint16_t(1));
			ds::Array<uint16_t> values(size_);
			benchmark::rep_test("get mid", [&]()
			{
				int i = 0;
				for(auto & e : values)
					e = array[i++].get<uint16_t>();
			}, count_, warmup_);
		}
		benchmark::delay(.1);
		{
			ds::Array<ds_variant_t> array(size_, int(1));
			ds::Array<int> values(size_);
			benchmark::rep_test("get far", [&]()
			{
				int i = 0;
				for(auto & e : values)
					e = array[i++].get<int>();
			}, count_, warmup_);
		}
	}
	// if(0)
	{
		printf("%zu\n", sizeof(variant_t));
		benchmark::delay(.1);
		{
			ds::Array<int> array(size_, true);
			ds::Array<int> values(size_);
			benchmark::rep_test("value", [&]()
			{
				int i = 0;
				for(auto & e : values)
					e = array[i++];
			}, count_, warmup_);
		}
		benchmark::delay(.1);
		{
			ds::Array<variant2_t> array(size_, ds::noinit);
			for(auto & e : array)
				ds::construct_at<variant2_t>(&e, std::in_place_type_t<int>{}, (0));
			ds::Array<int> values(size_);
			benchmark::rep_test("get near", [&]()
			{
				int i = 0;
				for(auto & e : values)
					e = std::get<int>(array[i++]);
			}, count_, warmup_);
		}
		benchmark::delay(.1);
		{
			ds::Array<variant_t> array(size_, ds::noinit);
			for(auto & e : array)
				ds::construct_at<variant_t>(&e, std::in_place_type_t<uint16_t>{}, (1));
			ds::Array<uint16_t> values(size_);
			benchmark::rep_test("get mid", [&]()
			{
				int i = 0;
				for(auto & e : values)
					e = std::get<uint16_t>(array[i++]);
			}, count_, warmup_);
		}
		benchmark::delay(.1);
		{
			ds::Array<variant_t> array(size_, ds::noinit);
			for(auto & e : array)
				ds::construct_at<variant_t>(&e, std::in_place_type_t<int>{}, (1));
			ds::Array<int> values(size_);
			benchmark::rep_test("get far", [&]()
			{ 
				int i = 0;
				for(auto & e : values)
					e = std::get<int>(array[i++]);
			}, count_, warmup_);
		}
	}
}
